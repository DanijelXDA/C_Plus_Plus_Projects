// casovnik.C - Metode klase casovnika.

#include "casovnik.h"

Casovnik::~Casovnik() {                    // Destruktor.
  while (prvi) { Elem* stari = prvi; prvi = prvi->sled; delete stari; }
  posl = nullptr;
}
Casovnik& Casovnik::operator-=(Akter* akt) {  // Odjavljivanje aktera.
  Elem *tek = prvi, *pret = nullptr;
  while (tek && tek->akter!=akt) { pret = tek; tek = tek -> sled; }
  if (tek) {
    (!pret ? prvi : pret->sled) = tek->sled;
    delete tek;
    if (tek == posl) posl = pret;
  }
  return *this;
}

void Casovnik::radi(double dt, double maxT) { // Rad casovnika.
  for (double t=0; t<=maxT; t+=dt) {
    cout << "Vreme: " << t << endl;
    for (Elem* tek=prvi; tek; tek=tek->sled) tek->akter->proteklo(dt);
  }
}

