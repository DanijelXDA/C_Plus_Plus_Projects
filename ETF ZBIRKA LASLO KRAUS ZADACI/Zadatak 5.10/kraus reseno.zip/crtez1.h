// crtez1.h - Klasa obojenih crte�a.

#ifndef _crtez1_h_
#define _crtez1_h_

#include "pravoug3.h"
#include "niz4.h"
#include <utility>
using namespace std;

namespace Figure {
  class Crtez: public Pravoug {
    Niz<Figura*> figure;                 // Figure u crte�u.
    void kopiraj(const Crtez& crt);      // Kopiranje crte�a.
    void brisi();                        // Uni�tavanje crte�a.
  public:                                // Konstruktori.
    Crtez(const Tacka& T,
      double sir, double vis, Boja bb=Boja()):
      Pravoug(T, sir, vis, bb) {}
    Crtez(const Crtez& crt): Pravoug(crt) { kopiraj(crt); }
    Crtez(Crtez&& crt) =default;
    ~Crtez() { brisi(); }                // Destruktor.
    Crtez& operator=(const Crtez& crt) { // Dodele vrednosti.
      if (this != &crt) {
        brisi(); Pravoug::operator=(crt); kopiraj(crt);
      }
      return *this;
    }
    Crtez& operator=(Crtez&& crt) =default;
    Crtez* kopija() const& override      // Kopije crte�a.
      { return new Crtez(*this); }
    Crtez* kopija() && override
      { return new Crtez(move(*this)); }
    Crtez& dodaj(const Figura& fig)      // Dodavanje figure kopiranjem.
      { figure.dodaj(fig.kopija()); return *this; }
    Crtez& dodaj(Figura&& fig)           // Dodavanje figure preme�tanjem.
      { figure.dodaj(move(fig).kopija()); return *this; }
    Crtez& dodaj(Figura* fig)            // Dodavanje figure preuzimanjem.
      { figure.dodaj(fig); return *this; }
    Boja boja(const Tacka& T) const override; // Boja ta�ke.
  }; // class Crtez
} // namespace Figure

#endif

