// imenik1t.C - Ispitivanje klase imenika.

#include "imenik1.h"
#include <iostream>
using namespace std;

int main() {
  Imenik im;
  im.dodaj(Osoba("Marko", JMBG("1205986110022")))
    .dodaj(Osoba("Milan", JMBG("3112969235052")))
    .dodaj(Osoba("Zoran", JMBG("1511990872035")))
    .dodaj(Osoba("Petar", JMBG("0207000345678")))
    .dodaj(Osoba("Stevo", JMBG("2503973123024")))
    .pisi();
}

