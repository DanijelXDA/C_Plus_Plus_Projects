// sekradi.C - Obrada sekvencijalne binarne datoteke.

#include <fstream>
#include <iostream>
using namespace std;

int main(int, const char* varg[]) {
  try {
    ifstream ulaz(varg[1], ios::binary); if (!ulaz) throw 1;
    ofstream poz (varg[2], ios::binary); if (!poz ) throw 2;
    ofstream neg (varg[3], ios::binary); if (!neg ) throw 3;
    int n;
    while (ulaz.read((char*)&n, sizeof(int))) {
      double* x = new double [n];
      ulaz.read((char*)x, n*sizeof(double));
      double s = 0;
      for (int i=0; i<n; s+=x[i++]);
      if (s) {
        (s>0 ? poz : neg).write((char*)&n, sizeof(int));
        (s>0 ? poz : neg).write((char*)x, n*sizeof(double));
      }
      delete [] x;
    }
  } catch (int g) {
    cout << "*** Greska pri otvaranju datoteke " << varg[g] << " ***\a\n";
    return g;
  }
  return 0;
}

