// pravoug2.h - Klasa pravougaonika.

#include <iostream>
using namespace std;

class Pravoug {
  double a, b; // Duzine ivica.
public:
  friend istream& operator>>(istream& ut, Pravoug& pp)        // Citanje.
    { return ut >> pp.a >> pp.b; }
  friend ostream& operator<<(ostream& it, const Pravoug& pp)  // Pisanje.
    { return it << "P[" << pp.a << ',' << pp.b << ']'; }
  friend bool operator<(const Pravoug& p1, const Pravoug& p2) // Uporedji-
    { return p1.a*p1.b < p2.a*p2.b; }                         //   vanje.
};

