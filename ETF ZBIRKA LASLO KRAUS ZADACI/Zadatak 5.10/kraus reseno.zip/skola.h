// skola.h - Klasa skola.

#ifndef _skola_h_
#define _skola_h_

#include "lista7.h"
#include "djak.h"
#include <string>
using namespace std;

class Skola {
  string ime;                              // Ime skole.
  Lista<Djak*> djaci;                      // Lista djaka.
 
public:
  Skola(string ii): ime(ii) {}             // Konstruktor.
  Skola(const Skola&) =delete;             // Ne sme da se kopira.
  Skola& operator=(const Skola&) =delete;  // Ne sme da se dodeljuje.
  Skola& operator+=(Djak& djak)            // Dodavanje djaka.
    { djaci.dodaj(&djak); return *this; }
  const Djak* najbolji() const;            // Djak s najvisim prosekom.
};

#endif

