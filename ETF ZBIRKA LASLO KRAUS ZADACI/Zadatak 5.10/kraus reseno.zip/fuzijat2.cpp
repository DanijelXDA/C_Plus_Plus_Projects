// fuzijat2.C - Ispitivanje genericke funkcije za fuziju nizova.

#include <iostream>
using namespace std;
#include "fuzija.h"
#include "tacka8.h"
#include "pravoug2.h"

template <typename U>
  void radi(const char* naslov) {
    cout << naslov; int na, nb, nc, i;
    cin >> na;    U* a = new U [na]; cout << "Prvi  niz:";
    for (i=0; i<na; i++) { cin >> a[i]; cout << ' ' << a[i]; } cout << endl;
    cin >> nb;    U* b = new U [nb]; cout << "Drugi niz:";
    for (i=0; i<nb; i++) { cin >> b[i]; cout << ' ' << b[i]; } cout << endl;
    nc = na + nb; U* c = new U [nc]; cout << "Fuzija   :";
    fuzija(a, na, b, nb, c, nc);
    for (i=0; i<nc; i++) {              cout << ' ' << c[i]; } cout << endl;
    delete [] a; delete [] b; delete [] c;
  }

int main() {
  radi<int>    ("\nFuzija nizova celih brojeva:\n\n");
  radi<Tacka>  ("\nFuzija nizova tacaka:\n\n");
  radi<Pravoug>("\nFuzija nizova pravougaonika:\n\n");
}

