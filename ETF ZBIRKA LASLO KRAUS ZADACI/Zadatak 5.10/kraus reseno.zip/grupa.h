// grupa.h - Klasa grupe elektri�nih potro�a�a.

#ifndef _grupa_h_
#define _grupa_h_

#include "potrosac1.h"
#include <iostream>
#include <utility>
using namespace std;

namespace Potrosaci {
  class Grupa: public Potrosac {
    struct Elem {                          // Element liste potro�a�a.
      Potrosac* potr; Elem* sled;
      Elem(Potrosac* p) { potr = p; sled = 0; }
      ~Elem() { delete potr; }
    };
    Elem *prvi, *posl;                     // Prvi i poslednji element.
    double sna;                            // Snaga grupe.
    void kopiraj(const Grupa& g);          // Kopiranje u grupu.
    void premesti(Grupa& g) {              // Preme�tanje u grupu.
      prvi = g.prvi; posl = g.posl; sna = g.sna;
      g.prvi = g.posl = nullptr;
    }
    void brisi();                          // Osloba�anje memorije.
    void pisi(ostream& it) const override; // Pisanje grupe.
  public:
    Grupa() { prvi = posl = nullptr; }     // Stvaranje prazne grupe.
    Grupa(const Grupa& g) { kopiraj(g); }  // Kopiraju�i konstruktor.
    Grupa(Grupa&& g) { premesti(g); }      // Preme�taju�i konstruktor.
    ~Grupa() { brisi(); }                  // Destruktor.
    Grupa& operator=(const Grupa& g) {     // Kopiraju�a dodela vrednosti.
      if (this != &g) { brisi(); kopiraj(g); }
      return *this;
    }
    Grupa& operator=(Grupa&& g) {          // Preme�taju�a dodela vrednosti.
      if (this != &g) { brisi(); premesti(g); }
      return *this;
    }
    Grupa& operator+=(const Potrosac& p) { // Dodavanje potro�a�a.
      Elem* novi = new Elem(p.kopija());
      posl = (!prvi ? prvi : posl->sled) = novi;
      sna += p.snaga(); return *this;
    }
    double snaga() const override { return sna; }    // Snaga grupe.
    Grupa* kopija() const& override        // Kopija grupe kopiranjem.
      { return new Grupa(*this); }
    Grupa* kopija() && override            // Kopija grupe preme�tanjem.
      { return new Grupa(*this); }
  }; // class
} // namespace

#endif

