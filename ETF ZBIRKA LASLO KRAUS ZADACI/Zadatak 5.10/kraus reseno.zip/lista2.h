// lista2.h - Definicija klase listi celih brojeva (iterativno).

class Lista {
  struct Elem {                  // ELEMENT LISTE:
    int broj;                    // - sadrzaj,
    Elem* sled;                  // - pokazivac na sledeci element,
    Elem(int b, Elem* s=nullptr) // - konstruktor.
      { broj = b; sled = s; }
  };
  Elem* prvi;                    // Pokazivac na pocetak liste.
public:                          // Konstruktori:
  Lista() { prvi = nullptr; }    // - podrazumevani,
  Lista(int b)                   // - konvertujuci,
    { prvi = new Elem(b); }
  Lista(const Lista& lst);       // - kopirajuci,
  Lista(Lista&& lst)             // - premestajuci.
    { prvi = lst.prvi; lst.prvi = nullptr; }
  ~Lista() { prazni(); }         // Destruktor.
  int duz() const;               // Broj elemenata liste.
  void pisi() const;             // Pisanje liste.
  void naPocetak(int b) {        // Dodavanje na
    prvi = new Elem(b, prvi);    //   pocetak.
  }
  void naKraj(int b);      // Dodavanje na kraj.
  void citaj1(int n);      // Citanje liste stavljajuci brojeve na pocetak.
  void citaj2(int n);      // Citanje liste stavljajuci brojeve na kraj.
  void umetni(int b);      // Umetanje u uredjenu listu.
  void prazni();           // Praznjenje liste.
  void izostavi(int b);    // Izostavljanje svakog pojavljivanja.
};

