// red3.h - Klasa redova neogranicenog kapaciteta.

#include <cstdlib>
using namespace std;

class Red {
  struct Elem {                             // Element reda:
    int   pod;                              // - sadrzaj elementa,
    Elem* sled;                             // - slede?i element;
    Elem(int p, Elem* s=nullptr)            // - konstruktor.
      { pod = p; sled = s; }
  };
  Elem *prvi, *posl;                        // Po?etak i kraj reda.
  int   duz;                                // Duzina reda.
  void  kopiraj(const Red& r);              // Kopiranje u red.
  void  premesti(Red& r) {                  // Premestanje u red.
    prvi = r.prvi; posl = r.posl; duz = r.duz;
    r.prvi = r.posl = nullptr;
  }
  void  brisi();                            // Osloba?anje memorije.
public:
  Red() { prvi = posl = nullptr; duz = 0; } // Konstruktor praznog reda.
  Red(int a)                                // Konverzija int u Red.
    { prvi = posl = new Elem(a); duz = 1; }
  Red(const Red& r) { kopiraj(r); }         // Kopiraju?i konstruktor.
  Red(Red&& r) { premesti(r); }             // Premestaju?i konstruktor.
  ~Red() { brisi(); }                       // Destruktor.
  Red& operator=(const Red& r) {            // Dodela vrednosti:
    if (this != &r) { brisi(); kopiraj(r); }// - kopiraju?a,
    return *this;
  }
 
  Red& operator=(Red&& r) {                 // - premestaju?a.
    if (this != &r) { brisi(); premesti(r); }
    return *this;
  }
  int  duzina() const { return duz; }       // Duzina reda.
  bool prazan() const { return !duz; }      // Da li je red prazan?
  Red& operator+=(const Red& r);            // Dodavanje podatka ili reda.
  Red  operator+ (const Red& r) const       // Spoj dva reda.
    { return Red(*this) += r; }
  int uzmi();                               // Uzimanje podatka s pocetka.
  int vodeci() const {                      // Vrednost podatka na po?etku.
    if (!prvi) exit(1);
    return prvi->pod;
  }
  Red  operator- (int k) const;      // Red bez elemenata jednakih k.
  Red& operator-=(int k)             // Brisanje svih elemenata jednakih k.
    { return *this = *this - k; }
  Red& operator~()                   // Praznjenje reda.
    { brisi(); return *this; }
};

