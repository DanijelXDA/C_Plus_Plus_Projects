// kompl1.h � Klasa kompleksnih brojeva.

#include <cmath>
#include <iostream>
using namespace std;

class Kompl {
  double re, im;                           // Realni i imaginarni deo.
public:
  Kompl(double r=0, double i=0)            // Stvaranje kompleksnog broja.
    { re = r; im = i; }

  friend double real(const Kompl& a)       // Realni deo.
    { return a.re; }
  friend double imag(const Kompl& a)       // Imaginarni deo.
    { return a.im; }
  friend double abs(const Kompl& a)        // Apsolutna vrednost.
    { return sqrt(a.re*a.re + a.im*a.im); }
  friend double arg(const Kompl& a)        // Argument.
    { return (a.re!=0 || a.im!=0) ? atan2(a.im,a.re) : 0; }

  Kompl operator~() const                  // Konjugovan broj.
    { return Kompl(re, -im); }
  friend Kompl operator+(const Kompl& a, const Kompl& b)          // a+b
    { return Kompl(a.re+b.re, a.im+b.im); }
  friend Kompl operator-(const Kompl& a, const Kompl& b)          // a-b
    { return Kompl(a.re-b.re, a.im-b.im); }
  friend Kompl operator*(const Kompl& a, const Kompl& b)          // a*b
    { return Kompl(a.re*b.re-a.im*b.im, a.im*b.re+a.re*b.im); }
  friend Kompl operator/(const Kompl& a, const Kompl& b) {        // a/b
    double c = b.re*b.re + b.im*b.im;
    return Kompl((a.re*b.re+a.im*b.im)/c, (a.im*b.re-a.re*b.im)/c);
  }

  Kompl& operator+=(const Kompl& b) { return *this = *this + b; } // a+=b
  Kompl& operator-=(const Kompl& b) { return *this = *this - b; } // a-=b
  Kompl& operator*=(const Kompl& b) { return *this = *this * b; } // a*=b
  Kompl& operator/=(const Kompl& b) { return *this = *this / b; } // a/=b

  Kompl& operator++() { re++; return *this; }                     // ++a
  Kompl& operator--() { re--; return *this; }                     // --a
  Kompl  operator++(int) { Kompl z=*this; re++; return z; }       // a++
  Kompl  operator--(int) { Kompl z=*this; re--; return z; }       // a--
 
  friend bool operator==(const Kompl& a, const Kompl& b)   // a==b
    { return a.re==b.re && a.im==b.im; }
  friend bool operator!=(const Kompl& a, const Kompl& b)   // a!=b
    { return a.re!=b.re || a.im!=b.im; }

  friend Kompl exp(const Kompl& a) {                       // exp(a)
    double abs = exp(a.re), arg = a.im;
    return Kompl(abs*cos(arg), abs*sin(arg));
  }
  friend Kompl log(const Kompl& a)                         // log(a)
    { return Kompl(log(abs(a)), arg(a)); }
  friend Kompl pow(const Kompl& a, const Kompl& b)         // pow(a, b)
    { return exp(b * log(a)); }

  friend istream& operator>>(istream& ut, Kompl& z)        // Citanje.
    { return ut >> z.re >> z.im; }
  friend ostream& operator<<(ostream& it, const Kompl& z)  // Pisanje.
    { return it << '(' << z.re << ',' << z.im << ')'; }
};
