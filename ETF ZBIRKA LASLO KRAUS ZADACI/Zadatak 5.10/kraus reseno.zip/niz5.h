// niz5.h - Genericka klasa nizova.

#ifndef _niz5_h_
#define _niz5_h_

#include <iostream>
using namespace std;

class G_niz_pun {};                 // KLASA GRESAKA: Niz je prepunjen.
inline ostream& operator<<(ostream& it, const G_niz_pun&)
  { return it << "*** Niz je pun! ***"; }

class G_indeks {};                  // KLASA GRESAKA: Indeks izvan opsega.
inline ostream& operator<<(ostream& it, const G_indeks&)
  { return it << "*** Nedozvoljen indeks! ***"; }

template <typename T>                      // GENERICKA KLASA NIZOVA:
class Niz {
  T* niz;                                  // Elementi niza.
  int kap, duz;                            // Kapacitet i duzina niza.
  void kopiraj(const Niz& n);              // Kopiranje u niz.
  void premesti(Niz n) {                   // Premestanje u niz.
    niz = n.niz; n.niz = nullptr;
    kap = n.kap; duz = n.duz;
  }
  void brisi() { delete [] niz; }          // Oslobadjanje memorije.
public:
  explicit Niz(int k=20) {                 // Stvaranje praznog niza.
    niz = new T [kap = k];
    duz = 0;
  }
  Niz(const Niz& n) { kopiraj(n); }        // Kopirajuci konstruktor.
  Niz(Niz&& n) { premesti(n); }            // Premestajuci konstruktor.
  ~Niz() { brisi(); }                      // Destruktor.
  Niz& operator=(const Niz& n){            // Kopirajuca dodela vrednosti.
    if (this!=&n) { brisi(); kopiraj(n); }
    return *this;
  }
  Niz& operator=(Niz&& n){                 // Premestajuca dodela vrednosti.
    if (this!=&n) { brisi(); premesti(n); }
    return *this;
  }
  int duzina() const { return duz; }       // Duzina niza.
  Niz& operator+=(const T& e) {            // Dodavanje elementa.
    if (duz == kap) throw G_niz_pun();
    niz[duz++] = e;
    return *this;
  }
  T& operator[](int i) {                   // Pristup elementu
    if (i<0 || i>=duz) throw G_indeks();   // - promenljivog niza,
    return niz[i];
  }
  const T& operator[](int i) const {       // - nepromenljivog niza.
    if (i<0 || i>=duz) throw G_indeks();
    return niz[i];
  }
};

template <typename T>                      // METODA KLASE NIZOVA:
void Niz<T>::kopiraj(const Niz& n) {       // Kopiranje u niz.
  niz = new T [kap = n.kap];
  duz = n.duz;
  for (int i=0; i<duz; i++) niz[i] = n.niz[i];
}

#endif

