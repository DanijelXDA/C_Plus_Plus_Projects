// uredi2t.C - Ispitivanje genericke klase za uredjivanje niza podataka.

#include "uredi2.h"
#include "opada.h"
#include "tacka8.h"
#include "pravoug2.h"
#include <string>
#include <iostream>
using namespace std;

template <typename T> // Genericka funkcija za obradu datog tipa podataka.
  void radi(string naslov) {
    cout << naslov;
    int n; cin >> n; T* a = new T [n];
    cout << "Pocetni   niz:";
    for (int i=0; i<n; i++) { cin>>a[i]; cout<<' '<<a[i]; } cout<<endl;
    Uredi<T>::uredi(a, n);
    cout << "Rastuci   niz:";
    for (int i=0; i<n; i++) cout << ' ' << a[i]; cout << endl;
    Uredi<T,Opada<T> >::uredi(a, n);
    cout << "Opadajuci niz:";
    for (int i=0; i<n; i++) cout << ' ' << a[i]; cout << endl;
    delete [] a;
  }

int main() {         // Glavna funkcija.
  radi<int>    ("\nUredjivanje niza celih brojeva:\n\n");
  radi<Tacka>  ("\nUredjivanje niza tacaka:\n\n");
  radi<Pravoug>("\nUredjivanje niza pravougaonika:\n\n");
}

