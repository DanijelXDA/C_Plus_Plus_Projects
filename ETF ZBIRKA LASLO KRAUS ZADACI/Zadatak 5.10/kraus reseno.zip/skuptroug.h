// skuptroug.h - Klasa skupova trouglova u ravni.

#include "trougao3.h"
#include <iostream>
using namespace std;

class Skup_troug {
  struct Elem {                                 // Element liste.
    Trougao t; Elem* sled;
    Elem(const Trougao& tt): t(tt), sled(nullptr) {}
  };
  Elem *prvi, *posl;                            // Pocetak i kraj liste.
  void kopiraj(const Skup_troug& st);           // Kopiranje u objekat.
  void premesti(Skup_troug st) {                // Premestanje u objekat.
    prvi = st.prvi; posl = st.posl;
    st.prvi = st.posl = nullptr;
  }
  void brisi();                                 // Oslobadjanje memorije.
public:
  Skup_troug() { prvi = posl = nullptr; }       // Stvaranje praznog skupa.
  Skup_troug(const Skup_troug& st)              // Kopirajuci konstruktor.
    { kopiraj(st); }
 
  Skup_troug(Skup_troug&& st)                   // Premestajuci konstruktor.
    { premesti(st); }
  ~Skup_troug() { brisi(); }                    // Destruktor.
  Skup_troug& operator=(const Skup_troug& st) { // Kopirajuca dodela
    if (this != &st){ brisi(); kopiraj(st); }   //   vrednosti.
    return *this;
  }
  Skup_troug& operator=(Skup_troug&& st) {      // Premestajuca dodela
    if (this != &st){ brisi(); premesti(st); }  //   vrednosti.
    return *this;
  }
  bool ima(const Trougao& t) const;          // Da li postoji u skupu?
  Skup_troug& operator+=(const Trougao& t);  // Dodavanje trougla.
  double ukP() const;                        // Ukupna povrsina trouglova.
  friend ostream& operator<<(ostream& it, const Skup_troug& s); // Pisanje.
};

