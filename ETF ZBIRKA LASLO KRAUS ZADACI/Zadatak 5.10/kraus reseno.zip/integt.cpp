// integt.C - Ispitivanje ra�unanja integrala.

#include "fun2.h"
#include "sin.h"
#include "oscil.h"
#include "poli2.h"
#include "log.h"
#include "integ.h"
using namespace Funkcije;
#include "greska.h"
#include "vektor2.h"
#include <string>
#include <iostream>
#include <new>
using namespace std;

int main() {
  while (true) {
    Fun* fun = nullptr;
    try {
      cout << "\nFunkcija (S, O, L, P, .)? ";
      char izb; cin >> izb;
      switch (izb) {
        case 's': case 'S': fun = new Sin; break;
        case 'o': case 'O': fun = new Oscil; break;
        case 'l': case 'L': fun = new Log; break;
        case 'p': case 'P': {
          int n; cout << "Red polinoma? "; cin >> n;
          Poli* p = new Poli(n);
          while (true) {
            cout << "Indeks i vrednost nenultog koeficijenta? ";
            int i; double k; cin >> i >> k;
          if (i<0) break;
            (*p)[i] = k;
          }
          fun = p;
          break;
        }
        case '.': break;
        default: throw "Nedozvoljen izbor";
      }
  if (!fun) break;
      double a, b; cout << "Interval? "; cin >> a >> b;
      cout << "Integral= " << integral(*fun,a,b) << endl;
    } catch (const Usluge::Greska& g) {
      cout << g;
    } catch (Vekt::Greska g) {
      cout << "\n*** Greska Vekt::" << g << " ***\n\a";
    } catch (string g) {
      cout << "\n*** " << g << " ***\n\a";
    } catch (bad_alloc) {
      cout << "\n*** Dodela memorije nije uspela ***\n\a";
    }
    delete fun;
  }
}

