// vozilo3.h - Apstraktna klasa vozila.

#ifndef _vozilo3_h_
#define _vozilo3_h_

#include <string>
#include <iostream>
using namespace std;

class Vozilo {
  float sop_tez;                                   // Sopstvena tezina.
public:
  Vozilo(float tez) { sop_tez = tez; }             // Inicijalizacija.
  virtual ~Vozilo() {}                             // Virtuelan destruktor.
  virtual string vrsta() const =0;                 // Naziv vrste vozila.
  virtual float tezina() const { return sop_tez; } // Tezina vozila.
protected:
  virtual void pisi(ostream& it) const             // Pisanje.
    { it << vrsta() << ' ' << sop_tez;  }
  friend ostream& operator<<(ostream& it, const Vozilo& v)
    { v.pisi(it); return it; }
};

#endif

