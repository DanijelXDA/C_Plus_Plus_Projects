// proizvod1.C - Staticko polje apstraktne klase proizvoda.

#include "proizvod1.h"

int Fabrika::Proizvod::pos_id = 0; // Poslednji identifikator.

