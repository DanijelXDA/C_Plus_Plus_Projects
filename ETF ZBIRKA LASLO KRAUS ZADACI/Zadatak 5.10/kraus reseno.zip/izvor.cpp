// izvor.C - Metode i funkcije uz klasu izvora elektri�ne energije.

#include "izvor.h"

namespace Potrosaci {
  Izvor::Izvor(double s, int k) {               // Stvaranje izvora.
    niz = new Potrosac* [kap = k];
    for (int i=0; i<kap; niz[i++]=nullptr); sna = s; opt = 0;
  }

  Izvor::~Izvor()                               // Uni�tavanje izvora.
    { for (int i=0; i<kap; delete niz[i++]); delete [] niz; }

  Izvor& Izvor::prikljuci(Potrosac* p, int i) { // Priklju�ivanje potro�a�a.
    if (i<0 || i>= kap) throw G_indeks();
    if (niz[i]) { opt-=niz[i]->snaga(); delete niz[i]; niz[i]=nullptr; }
    if (p) {
      double s = p->snaga();
      if (opt+s > sna) throw G_preopt();
      niz[i] = p; opt += s;
    }
    return *this;
  }

  ostream& operator<<(ostream& it, const Izvor& izv) { // Pisanje izvora.
    it << '\n' << izv.opt << '/' << izv.sna << endl;
    for (int i=0; i<izv.kap; i++) {
      it << i << ": ";
      if (izv.niz[i]) it << *izv.niz[i]; else it << "<< prazan >>";
      it << endl;
    }
    return it;
  }
} // namespce

