// presek.c - Presek dva skupa.

#include <stdio.h>
#include <stdlib.h>

typedef struct { int vel; double *niz; } Skup;

Skup presek(Skup s1, Skup s2) {
  int vel = (s1.vel<s2.vel ? s1.vel : s2.vel);
  double *niz = malloc(vel*sizeof(double));
  int k = 0;
  for (int i=0; i<s1.vel; i++) {
    int j = 0; while (j<s2.vel && s2.niz[j]!=s1.niz[i]) j++;
    if (j < s2.vel) niz[k++] = s2.niz[j];
  }
  Skup s = {k, realloc(niz, k*sizeof(double))};
  return s;
}

int main() {
  while (1) {
    Skup s1; scanf("%d", &s1.vel);
  if (s1.vel < 0) break;
    s1.niz = malloc(s1.vel*sizeof(double));
    for (int i=0; i<s1.vel; scanf("%lf",&s1.niz[i++]));
    Skup s2; scanf("%d", &s2.vel);
  if (s2.vel < 0) break;
    s2.niz = malloc(s2.vel*sizeof(double));
    for (int i=0; i<s2.vel; scanf("%lf",&s2.niz[i++]));
    Skup s = presek(s1, s2);
    for (int i=0; i<s.vel; printf("%lf ", s.niz[i++])); putchar('\n');
    free(s1.niz); free(s2.niz); free(s.niz);
  }
}
