// izvodt.C - Ispitivanje stvaranja izvoda.

#include "fun3.h"
#include "monom.h"
#include "ekspon.h"
#include "zbirfun.h"
using namespace Izvodi;
#include <iostream>
#include <cstdlib>
#include <string>
#include <new>
using namespace std;

int main(int, char** varg) {
  Zbir_fun zbir(atoi(varg[1]));
  try {
    while (true) {
      double a, b; char vrs;
      cout << "Vrsta (M, E, *)? "; cin >> vrs;
    if (vrs == '*') break;
      switch (vrs) {
        case 'm': case 'M':
          cout << "a,b? "; cin >> a >> b; zbir += Monom (a, b); break;
        case 'e': case 'E':
          cout << "a,b? "; cin >> a >> b; zbir += Ekspon(a, b); break;
        default:
          throw "*** Nedozvoljen izbor! ***\n";
      }
    }
    Delegat izvod = zbir.izvod();
    cout << "Fun= " << zbir << endl;
    cout << "Izv= " << izvod << endl;
    double xmin = atof(varg[2]), xmax = atof(varg[3]),
           dx = atof(varg[4]);
    for (double x=xmin; x<=xmax; x+=dx)
      cout << x << '\t' << zbir(x) << '\t' << izvod(x) << endl;
  } catch (G_zbir_fun_pun g) { cout << g << endl;
  } catch (string g) { cout << g;
  } catch (bad_alloc) { cout << "*** Dodela memorije nije uspela! ***\n";
  }
}

