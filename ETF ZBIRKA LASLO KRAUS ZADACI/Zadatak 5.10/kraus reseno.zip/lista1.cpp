// lista1.C - Obrada jednostruko spregnute liste.

#include <iostream>
using namespace std;

struct Elem { int broj; Elem* sled; };

Elem* citaj() {         // Stvaranje liste citajuci.
  Elem *lst = nullptr, *tek = nullptr;
  while (true) {
    int broj; cin >> broj;
  if (broj == 9999) break;
    Elem* novi = new Elem;
    novi->broj = broj; novi->sled = nullptr;
    tek = (lst==nullptr ? lst : tek->sled) = novi;
  }
  return lst;
}

void pisi(Elem* lst) {  // Ispisivanje liste.
  while (lst) {
    cout << lst->broj << ' '; lst = lst -> sled;
  }
}

void brisi(Elem* lst) { // Unistavanje liste.
  while (lst) { Elem* stari = lst; lst = lst->sled; delete stari; }
}

int main() {            // Ispitivanje funkcija.
  while (true) {
    Elem* lista;
    cout << "\nLista? ";
  if ((lista = citaj()) == nullptr) break;
    cout << "Procitano: "; pisi(lista); cout << endl;
    brisi(lista);
  }
}

