// naredba.h - Apstraktna klasa naredbi.

#ifndef _naredba_h_
#define _naredba_h_

#include <iostream>
#include <iomanip>
using namespace std;

namespace Naredbe {
  class Naredba {
  public:
    virtual ~Naredba() {}                 // Virtuelan destruktor.
    virtual void izvrsi() const =0;       // Izvr�avanje naredbe.
    virtual Naredba* kopija() const =0;   // Kopija naredbe.
  protected:
    static int nivo;                      // Nivo naredbe pri pisanju.
    virtual void pisi(ostream& it) const  // Pisanje.
      { it << setw(nivo*2) << ""; }
    friend ostream& operator<<(ostream& it, const Naredba& nar)
      { nar.pisi(it); return it; }
  }; // class Naredba
} // namespace Naredbe

#endif
