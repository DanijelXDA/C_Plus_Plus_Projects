// lista3.h - Definicija klase listi
//            celih brojeva (rekurzivno).

#include <iostream>
using namespace std;

class Lista {
  struct Elem {                  // Element liste:
    int broj;                    // - sadrzaj,
    Elem* sled;                  // - pokazivac na sledeci,
    Elem(int b, Elem* s=nullptr) // - konstruktor.
      { broj = b; sled = s; }
  };
  Elem* prvi;                    // Pokazivac na pocetak liste.
public:                          // Konstruktori:
  Lista() { prvi = nullptr; }    // - podrazumevani,
  Lista(int b)                   // - konvertujuci,
    { prvi = new Elem(b); }
  Lista(const Lista& lst)        // - kopirajuci,
    { prvi = nullptr; kopiraj(lst.prvi); }
  Lista(Lista&& lst)             // - premestajuci.
    { prvi = lst.prvi; lst.prvi = nullptr; }
  ~Lista() { brisi(prvi); }      // Destruktor.
  int duz() const                // Broj elemenata liste.
    { return duz(prvi); }
  void pisi() const              // Ispisivanje liste.
    { pisi(prvi); }
  void naPocetak(int b)          // Dodavanje na pocetak.
    { prvi = new Elem(b, prvi); }
  void naKraj(int b)             // Dodavanje na kraj.
    { naKraj(prvi, b); }
  void citaj1(int n)  // Citanje liste stavljajuci brojeve na pocetak.
    { prazni(); citaj1(prvi, n); }
  void citaj2(int n)  // Citanje liste stavljajuci brojeve na kraj.
    { prazni(); citaj2(prvi, n); }
  void umetni(int b)             // Umetanje u uredjenu listu.
    { umetni(prvi, b); }
  void prazni()                  // Praznjenje liste.
    { brisi(prvi); }
  void izostavi(int b)           // Izostavljanje svakog pojavljivanja.
    { izostavi(prvi, b); }
 
private:                                    // POMOCNE REKURZIVNE METODE:
  static Elem* kopiraj(Elem* lst) {         // Kopiranje liste.
    return lst ? new Elem(lst->broj, kopiraj(lst->sled)) : nullptr;
  }
  static int duz(Elem* lst)      // Broj elemenata liste.
    { return lst ? 1+duz(lst->sled) : 0; }
  static void pisi(Elem* lst) {  // Ispisivanje liste.
    if (lst) 
      { cout << lst->broj << ' '; pisi(lst->sled); }
  }
  static void naKraj(Elem*& lst, int b) {   // Dodavanje na kraj.
    if (!lst) lst = new Elem(b);
      else naKraj(lst->sled, b);
  }

  static void citaj1(Elem*& lst, int n) {   // Citanje stavljajuci na
    if (n) {                                //   pocetak.
      lst = new Elem(0);
      citaj1(lst->sled, n-1);
      cin >> lst->broj; 
    }
  }
  static void citaj2(Elem*& lst, int n) {   // Citanje stavljajuci na kraj.
    if (n) {
      int b; cin >> b; lst = new Elem(b);
      citaj2(lst->sled, n-1);
    }
  }
  static void umetni(Elem*& lst, int b) {   // Umetanje u uredjenu listu.
    if (!lst || lst->broj>=b)
      lst = new Elem(b, lst);
    else
      umetni(lst->sled, b);
  }
  static void brisi(Elem*& lst) {           // Brisanje svih elemenata.
    if (lst) { brisi(lst->sled);
               delete lst; lst = nullptr; }
  }
  static void izostavi(Elem*& lst, int b) { // Izostavljanje svakog
    if (lst) { izostavi(lst->sled, b);      //   pojavljivanja.
      if (lst->broj == b) {
        Elem* stari = lst; 
        lst = lst->sled; delete stari;
      }
    }
  }
};
