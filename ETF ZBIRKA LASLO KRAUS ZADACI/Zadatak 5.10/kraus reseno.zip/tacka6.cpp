// tacka6.C - Metode klase ta�aka u ravni.

#include "tacka6.h"
                                                    // Pisanje niza ta�aka.
void Linije::Tacka::pisiNiz(ostream& it, const Tacka* niz, int duz) {
  it << '(';
  for (int i=0; i<duz; i++) {
    if (i) it << ',';
    it << niz[i];
  }
  it << ')';
}
