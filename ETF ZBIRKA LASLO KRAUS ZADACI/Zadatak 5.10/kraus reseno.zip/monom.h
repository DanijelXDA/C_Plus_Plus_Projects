// monom.h - Klasa monoma.

#ifndef _monom_h_
#define _monom_h_

#include "fun3.h"
#include <cmath>
#include <utility>
using namespace std;

namespace Izvodi {
  class Monom: public Fun {
    double a, b;                               // Parametri monoma.
    void pisi(ostream& it) const override      // Pisanje monoma.
      { it << a << "*x^" << b; }
  public:
    Monom(double aa=1, double bb=1)            // Stvaranje monoma.
      { a = aa; b = bb; }
    double operator()(double x) const override // Ra�unanje vrednosti.
      { return a * pow(x, b); }
    Delegat izvod() const override             // Izvod monoma.
      { return Delegat(new Monom(a*b, b-1)); }
    Monom* kopija() const& override         // Kopija monoma kopiranjem.
      { return new Monom(*this); }
    Monom* kopija() && override             // Kopija monoma preme�tanjem.
      { return new Monom(move(*this)); }
  }; // class Monom
} // namespace Izvodi

#endif

