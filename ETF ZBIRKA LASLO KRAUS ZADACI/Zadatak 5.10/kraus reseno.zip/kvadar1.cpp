 
// kvadar1.C - Definicije statickih polja klase kvadara.

#include "kvadar1.h"

double Kvadar::Vmax = 0, Kvadar::Vuk = 0;
