// sfera4.h - Klasa sfera.

#ifndef _sfera4_h_
#define _sfera4_h_

#include "telo2.h"
#include <utility>
using namespace std;

namespace Predmeti {
  class Sfera: public Telo {
    double r;                                   // Polupre�nik sfere.
  public:
    Sfera(double rr=1, double ss=1)             // Stvaranje sfere.
      : Telo(ss) { r = rr; }
    Sfera* kopija() const& override              // Kopija sfere kopiranjem.
      { return new Sfera(*this); }
    Sfera* kopija() && override              // Kopija sfere preme�tanjem.
      { return new Sfera(move(*this)); }
    double V() const override final             // Zapremina sfere.
      { return 4 * r * r * r * 3.14159 / 3; }
    string vrsta() const override { return "Sfera"; } // Vrsta predmeta.
  private:
    void pisi(ostream& it) const override       // Pisanje sfere.
      { Telo::pisi(it); it << r << ')'; }
  }; // class Sfera
} // namespace Predmeti

#endif

