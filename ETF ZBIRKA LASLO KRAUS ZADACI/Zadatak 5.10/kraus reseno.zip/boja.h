// boja.h - Klasa boja.

#ifndef _boja_h_
#define _boja_h_

#include <iostream>
using namespace std;

namespace Figure {
  class G_boja {};                        // KLASA GRE�AKA: Neispravna boja.
  inline ostream& operator<<(ostream& it, const G_boja&)
    { return it << "*** Neispravna boja! ***"; }

  class Boja {                            // KLASA BOJA:
    double cc, zz, pp;
  public:
    Boja() { cc = zz = pp = 1; }          // Konstruktori.
    Boja(double c, double z, double p) {
      if (c<0 || c>1 || z<0 || z>1 || p<0 || p>1)
        throw G_boja();
      cc = c; zz = z; pp = p;
    }
    friend ostream& operator<<(ostream& it, const Boja& b) // Pisanje.
      { return it << '(' << b.cc << ',' << b.zz << ',' << b.pp << ')'; }
  }; // class Boja
} // namespace Figure

#endif

