// crtez2t.C - Ispitivanje klase crte�a.

#include "font.h"
#include "simbol.h"
#include "crtez2.h"
#include "vektor4.h"
#include "duz2.h"
#include "tekst4.h"
#include <iostream>
using namespace std;

int main() {
  try {
    Font fnt; 
    fnt += Simbol('m', 0.8); 
    fnt += Simbol('a', 0.5);
    fnt += Simbol('!', 0.1);
    Crtez crt(2); 
    crt += Duz(Vektor(1, 1), Vektor(2, 3));
    crt += Tekst("mama!", 1, fnt, Vektor(2, 1));
    cout << crt << endl;
    crt += Vektor(2, 1);
    cout << crt << endl;
  } catch (G_nema   g) { cout << g << endl;
  } catch (G_pun    g) { cout << g << endl;
  } catch (G_indeks g) { cout << g << endl;
  } catch (G_prazno g) { cout << g << endl;
  }
}

