// sekvenca.h - Klasa sekvenci.

#ifndef _sekvenca_h_
#define _sekvenca_h_

#include "naredba.h"

namespace Naredbe {
  class Sekvenca: public Naredba {
    struct Elem {                               // Element sekvence:
      Naredba* nar;                             // - sadr�ana naredba,
      Elem* sled;                               // - slede�i element liste,
      Elem(Naredba* n)                          // - konstruktor,
        { nar = n; sled = nullptr; }
      ~Elem() { delete nar; delete sled; }      // - destruktor.
    }; // struct Elem

    Elem *prva, *posl;                          // Prva i poslednja naredba.
    void kopiraj(const Sekvenca&);              // Kopiranje u sekvencu.
    void brisi() { delete prva; }               // Osloba�anje memorije.
    void pisi(ostream&) const override;         // Pisanje sekvence.
  public:
    Sekvenca() { prva = posl = nullptr; }       // Prazna sekvenca.
    Sekvenca(const Sekvenca& s) { kopiraj(s); } // Kopiraju�i konstruktor.
    ~Sekvenca() { brisi(); }                    // Uni�tavanje sekvence.
    Sekvenca& operator=(const Sekvenca& s) {    // Kopiraju�a odela
      if (this != &s) { brisi(); kopiraj(s); }  //   vrednosti.
      return *this;
    }
    Sekvenca& operator+=(const Naredba& n) {    // Dodavanje naredbe.
      posl = (!prva ? prva : posl->sled) = new Elem(n.kopija());
      return *this;
    }
    void izvrsi() const override;               // Izvr�avanje sekvence.
    Sekvenca* kopija() const override           // Kopija sekvence.
      { return new Sekvenca(*this); }
  }; // class Sekvenca
} // namespace Naredbe

#endif
