// podatakt.C - Ispitivanje klasa za obradu podataka.

#include "skalar.h"
#include "niz2.h"
#include <iostream>
using namespace std;

int main() {
  while (true) {
    try {
      cout << "\nBroj podataka? "; int n; cin >> n;
  if (n < 0) break;
      Niz a(n);
      for (int i=0; i<n; i++) {
        cout << "Vrsta podatka (Skalar, Niz)? ";
        char vrs; cin >> vrs;
        switch (vrs) {
          case 's': case 'S': {
            cout << "Vrednost?  "; double s; cin >> s;
            a += Skalar(s); break;
          }
          case 'n': case 'N': {
            cout << "Kapacitet? ";
            int n; cin >> n; Niz b(n);
            cout << "Vrednosti? ";
            do {
              double s; cin >> s; b += Skalar(s);
            } while (cin.get() != '\n');  // do kraja reda
            a += b; break;
          }
        }
      }
      cout << "Niz podataka: " << a << endl;
    } catch (G_pun)      { cout << "\n*** GRESKA: Niz je pun! ***\n";
    } catch (G_prazno g) { cout << endl << g;
    } catch (G_indeks g) { cout << endl << g;
    }
  }
}
