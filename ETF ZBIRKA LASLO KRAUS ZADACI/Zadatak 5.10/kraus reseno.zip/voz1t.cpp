// voz1t.C - Ispitivanje klase vozova.

#include "voz1.h"
#include "lokomot1.h"
#include "pvagon.h"
using namespace Vozovi1;
#include <iostream>
using namespace std;

int main() {
  P_vagon::post_sr_tez_put(75);
  Voz voz("Avala ekspres");
  try {
    voz += Lokomot(500, 5000);
    voz += P_vagon(300, 40).ulazePutnici(30);
    voz += P_vagon(250, 30).ulazePutnici(10);
    voz += Lokomot(400, 4000);
  } catch (G_previse_putnika g) { cout << g << endl;
  } catch (G_nema_lok        g) { cout << g << endl;
  } catch (G_ima_lok         g) { cout << g << endl;
  } catch (G_tezak_voz       g) { cout << g << endl;
  }
  cout << voz;
}

