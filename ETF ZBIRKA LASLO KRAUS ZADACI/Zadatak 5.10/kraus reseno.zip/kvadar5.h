// kvadar5.h - Klasa kvadara.

#ifndef _kvadar5_h_
#define _kvadar5_h_

#include "telo2.h"
#include <utility>
using namespace std;

namespace Predmeti {
  class Kvadar: public Telo { double a, b, c;           // Ivice kvadra.
  public:
    Kvadar(double aa=1, double bb=1, double cc=1,       // Stvaranje kvadra.
      double ss=1): Telo(ss) { a = aa; b = bb; c = cc; }
    Kvadar* kopija() const& override          // Kopija kvadra kopiranjem.
      { return new Kvadar(*this); }
    Kvadar* kopija() && override              // Kopija kvadra preme�tanjem.
      { return new Kvadar(move(*this)); }
    double V() const override final { return a * b * c; } // Zapremina kvad.
    string vrsta() const override { return "Kvadar"; }    // Vrsta predmeta.
  private:
    void pisi(ostream& it) const override                 // Pisanje kvadra.
      { Telo::pisi(it); it << a << ',' << b << ',' << c << ')'; }
  }; // class Kvadar
} // namespace Predmeti

#endif

