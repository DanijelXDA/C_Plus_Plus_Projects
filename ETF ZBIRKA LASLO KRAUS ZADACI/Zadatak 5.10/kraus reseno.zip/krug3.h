// krug3.h - Klasa obojenih krugova u ravni.

#ifndef _krug3_h_
#define _krug3_h_

#include "figura3.h"
#include <utility>
using namespace std;

namespace Figure {
  class Krug: public Figura {
    Tacka  C;                                  // Centar.
    double r;                                  // Polupre�nik.
  public:                                      // Konstruktor.
    explicit Krug(Tacka cc=Tacka(), double rr=1, Boja bb=Boja())
      : Figura(bb), C(cc), r(rr) {}
    Krug* kopija() const& override             // Kopija kruga kopiranjem.
      { return new Krug(*this); }
    Krug* kopija() && override                 // Kopija kruga preme�tanjem.
      { return new Krug(move(*this)); }
    bool pripada(const Tacka& T) const         // Da li ta�ka pripada?
      { return C.rastojanje(T) <= r; }
  }; // class Krug
} // namespace Figure

#endif

