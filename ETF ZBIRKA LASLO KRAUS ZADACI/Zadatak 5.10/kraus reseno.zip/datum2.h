// datum2.h - Definicija klase kalendarskih datuma.

#include <iostream>
#include <cstdlib>
using namespace std;

class Datum {
  int d, m, g;                            // Dan, mesec i godina.
  static int dani[2][12];                 // Brojevi dana po mesecima.
public:
  static bool moze(int d, int m, int g)   // Da li je ispravan?
    { return g>0 && m>0 && m<=12 && d>0 && d<=dani[g%4==0][m-1]; }
  explicit Datum(int dd=1, int mm=7, int gg=2011) { // Stvaranje datuma.
    if (!moze(dd, mm, gg)) exit(1);
    d = dd; m = mm; g = gg;
  }
  int dan() const { return d; }           // Dohvatanje delova datuma.
  int mes() const { return m; }
  int god() const { return g; }
  int uporedi(const Datum& dat) const {   // Uporedjivanje datuma.
    if (g != dat.g) return g - dat.g;
    if (m != dat.m) return m - dat.m;
                    return d - dat.d;
  }
  bool citaj() {                          // Citanje datuma.
    int d, m, g; cin >> d >> m >> g;
    if (!moze(d, m, g)) return false;
    *this = Datum(d, m, g); return true;
  }
  void pisi() const                       // Pisanje datuma.
    { cout << d << '.' << m << '.' << g << '.'; }
};
