// font.C - Metode klase fontova.

#include "font.h"

void Font::kopiraj(const Font& f) {        // Kopiranje u font.
  prvi = posl = nullptr; br_simb = f.br_simb;
  for (Elem *tek=f.prvi; tek; tek=tek->sled)
    posl = (!prvi ? prvi : posl->sled) = new Elem(tek->sim);
}

void Font::brisi() {                       // Osloba�anje memorije.
  while (prvi) { Elem* stari = prvi; prvi = prvi->sled; delete stari; }
}

Simbol& Font::operator[](char zn) {        // Pristup znaku nepromenljivog
  for (Elem* tek=prvi; tek; tek=tek->sled) //   fonta.
    if (tek->sim.znak() == zn) return tek->sim;
  throw G_nema();
}

