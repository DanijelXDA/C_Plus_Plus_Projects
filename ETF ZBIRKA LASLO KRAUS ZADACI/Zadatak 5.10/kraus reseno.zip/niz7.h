// niz7.h - Generi�ka klasa nizova pokaziva�a na podatke.

#ifndef _niz7_h_
#define _niz7_h_

#include <iostream>
using namespace std;

class G_pun {};                       // KLASA GRE�AKA: Niz je pun.
inline ostream& operator<<(ostream& it, const G_pun&)
  { return it << "*** Niz je pun! ***";}

class G_indeks {};                    // KLASA GRE�AKA: Nedozvoljen indeks.
inline ostream& operator<<(ostream& it, const G_indeks&)
  { return it << "*** Nedozvoljen indeks! ***"; }

class G_prazno {};                    // KLASA GRE�AKA: Mesto je prazno.
inline ostream& operator<<(ostream& it, const G_prazno&)
  { return it << "*** Mesto je prazno! ***"; }

template <class T>
class Niz {                              // GENERI�KA KLASA NIZOVA:
  T** niz;                               // Niz pokaziva�a na elemente.
  int kap;                               // Kapacitet niza.
  void kopiraj(const Niz& n);            // Kopiranje u niz.
  void premesti(Niz& n) {                // Preme�tanje u niz.
    niz = n.niz; kap = n.kap;
    n.niz = nullptr;
  }
  void brisi();                          // Osloba�anje memorije.
  int prazno() const;                    // Prvo prazno mesto u nizu.
public:
  explicit Niz(int k=10);                // Stvaranje praznog niza.
  Niz(const Niz& n) { kopiraj(n); }      // Kopiraju�i konstruktor.
  Niz(Niz&& n) { premesti(n); }          // Preme�taju�i konstruktor.
  ~Niz() { brisi(); }                    // Destruktor.
  Niz& operator=(const Niz& n) {         // Kopiraju�a dodela vrednosti.     
    if (this != &n) { brisi(); kopiraj(n); }
    return *this;
  }
  Niz& operator=(Niz&& n) {              // Preme�taju�a dodela vrednosti.     
    if (this != &n) { brisi(); premesti(n); }
    return *this;
  }
  int kapac() const { return kap; }      // Kapacitet niza.
  Niz& operator+=(const T& t)            // Dodavanje elementa kopiranjem.
    { niz[prazno()] = t.kopija(); }
  Niz& operator+=(T&& t)                 // Dodavanje elementa preme�tanjem.
    { niz[prazno()] = move(t).kopija(); }
  Niz& izbaci(int i) {                   // Izbacivanje elementa.
    if (i>=0 && i<kap) { delete niz[i]; niz[i] = nullptr; }
    return *this;
  }
  T& operator[](int i) {                 // Pristup elementu
    if (i<0 || i>=kap) throw G_indeks(); // - promenljivog niza,
    if (!niz[i]) throw G_prazno ();
    return *niz[i];
  }
  const T& operator[](int i) const {     // - nepromenljivog niza.
    if (i<0 || i>=kap) throw G_indeks();
    if (!niz[i]) throw G_prazno();
    return *niz[i];
  }
  template <class U>                     // Pisanje niza.
  friend ostream& operator<<(ostream& it, const Niz<U>& n);
};

template <class T>                    // METODE I FUNKCIJE UZ KLASU NIZOVA:
void Niz<T>::kopiraj(const Niz& n) {  // Kopiranje u objekat.
  niz = new T* [kap = n.kap];
  for (int i=0; i<kap; i++)niz[i] = n.niz[i] ? n.niz[i]->kopija() : nullptr;
}

template <class T>
void Niz<T>::brisi() {                 // Osloba�anje memorije.
  for (int i=0; i<kap; delete niz[i++]);
  delete [] niz;
}

template <class T>                     // Stvaranje praznog niza.
Niz<T>::Niz(int k) {
  niz = new T* [kap = k];
  for (int i=0; i<k; niz[i++]=nullptr);
}

template <class T>
int Niz<T>::prazno() const {           // Prvo prazno mesto u nizu.
  int i = 0; while (i<kap && niz[i]) i++;
  if (i == kap) throw G_pun();
  return i;
}

template <class U>                        // Pisanje niza.
ostream& operator<<(ostream& it, const Niz<U>& n) {
  it << '<';
  for (int i=0; i<n.kap; i++) {
    if (i) it << " # ";
    if (n.niz[i]) it << *n.niz[i];
  }
  return it << '>';
}

#endif

