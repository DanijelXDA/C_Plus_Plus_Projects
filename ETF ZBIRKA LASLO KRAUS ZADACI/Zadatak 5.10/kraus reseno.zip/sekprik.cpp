// sekprik.C - Prikazivanje sadrzaja sekvencijalne binarne datoteke.

#include <fstream>
#include <iostream>
#include <iomanip>
using namespace std;

int main(int, const char* varg[]) {
  try {
    ifstream ulaz(varg[1], ios::binary); if (!ulaz) throw 1;
    int n;
    cout << fixed << setprecision(2);
    while (ulaz.read((char*)&n, sizeof(int))) {
      double* x = new double [n];
      ulaz.read((char*)x, n*sizeof(double));
      cout << setw(3) << n << ' ';
      for (int i=0; i<n; i++)
	      cout << setw(7) << x[i] <<
	              (i==n-1 ? "\n" : i%8==7 ? "\n    " : " ");
      delete [] x;
    }
  }
 
  catch (int g) {
    cout << "*** Greska pri otvaranju datoteke " << varg[g] << " ***\a\n";
    return g;
  }
  return 0;
}

