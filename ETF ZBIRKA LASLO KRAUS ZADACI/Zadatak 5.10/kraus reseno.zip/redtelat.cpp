// redtelat.C - Ispitivanje klase redova tela.

#include "sfera2.h"
#include "valjak2.h"
#include "redtela.h"
#include <iostream>
using namespace std;

int main() {
  while (true) {
    cout << "kap? "; int k; cin >> k;
  if (k <= 0) break;
    Red_tela red(k);
    while (!red.pun()) {
      cout << "Vrsta (S,V)? "; char vr; cin >> vr;
      double r, h;
      switch (vr) {
        case 's': case 'S':
          cout << "r? "; cin >> r;
          red += Sfera(r);
          break;
        case 'v': case 'V':
          cout << "r,h? "; cin >> r >> h;
          red += Valjak(r, h);
          break;
      }
    }
 
    cout << red << endl;
    double V = 0; int n = 0;
    while (!red.prazan()) {
      Telo* t = red.uzmi();
      V += t->V(); n++;
      delete t;
    }
    if (n) V /= n;
    cout << "Vsr= " << V << endl;
  }
}
