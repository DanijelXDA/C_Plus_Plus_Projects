// telo2.h - Apstraktna klasa tela.

#ifndef _telo2_h_
#define _telo2_h_

#include "predmet3.h"

namespace Predmeti {
  class Telo: public Predmet {
    double sigma;                               // Specifi�na te�ina tela.
  public:
    Telo(double s=1) { sigma = s; }             // Stvaranje tela.
    double spTez() const { return sigma; }      // Specifi�na te�ina tela.
    double Q() const override final             // Te�ina tela.
      { return sigma * V(); }
  protected:
    void pisi(ostream& it) const override       // Pisanje tela.
      { Predmet::pisi(it); it << '(' << sigma << ';'; }
  }; // class Telo
} // namespace Predmeti

#endif

