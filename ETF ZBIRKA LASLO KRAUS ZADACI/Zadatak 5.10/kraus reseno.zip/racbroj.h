// racbroj.h - Klasa racionalnih brojeva.

#ifndef _racbroj_h_
#define _racbroj_h_

#include <iostream>
#include <cstdlib>
using namespace std;

namespace Aritmetika {
  class G_rac_broj {}; // Klasa gre�aka: Imenilac jednak nuli.

  class Rac_broj {
    typedef const Rac_broj CRB;         // Nepromenljiv racionalan broj.
    typedef long long Ceo;              // Ceo broj.
    Ceo x, y;                           // Brojilac i delilac.
    static Ceo nzd(Ceo a, Ceo b);       // Najve�i zajedni�ki delilac.
  public:
    Rac_broj(Ceo a = 0, Ceo b = 1) {    // Inicijalizacija.
      x = a; y = b;
      if (y == 0) throw G_rac_broj();
      if (y < 0) { x = -x; y = -y; }
      Ceo z = nzd(llabs(x), y); x /= z; y /= z;
    }

    Rac_broj operator-() const { return Rac_broj(-x, y); }      // -r
    Rac_broj operator+() const { return *this; }                // +r
    Rac_broj operator!() const { return Rac_broj(y, x); }       // 1 / r

    friend Rac_broj operator+(CRB& r, CRB& s)                   // r + s
      { return Rac_broj(r.x*s.y+s.x*r.y, r.y*s.y); }
    friend Rac_broj operator-(CRB& r, CRB& s)                   // r - s
      { return Rac_broj(r.x*s.y-s.x*r.y, r.y*s.y); }
    friend Rac_broj operator*(CRB& r, CRB& s)                   // r * s
      { return Rac_broj(r.x*s.x, r.y*s.y); }
    friend Rac_broj operator/(CRB& r, CRB& s)                   // r / s
      { return Rac_broj(r.x*s.y, r.y*s.x); }

    Rac_broj& operator+=(CRB& s) { return *this = *this + s; }  // r += s
    Rac_broj& operator-=(CRB& s) { return *this = *this - s; }  // r -= s
    Rac_broj& operator*=(CRB& s) { return *this = *this * s; }  // r *= s
    Rac_broj& operator/=(CRB& s) { return *this = *this / s; }  // r /= s
 
    Rac_broj& operator++() { return *this += 1; }                     // ++r
    Rac_broj& operator--() { return *this -= 1; }                     // --r
    Rac_broj operator++(int) { Rac_broj a(*this); ++*this; return a; }// r++
    Rac_broj operator--(int) { Rac_broj a(*this); --*this; return a; }// r--

    friend bool operator==(CRB& r, CRB& s)                      // r == s
      { return r.x==s.x && r.y==s.y; }
    friend bool operator!=(CRB& r, CRB& s)                      // r != s
      { return r.x!=s.x || r.y!=s.y; }
    friend bool operator< (CRB& r, CRB& s)                      // r <  s
      { return r.x* s.y <  r.y* s.x; }
    friend bool operator<=(CRB& r, CRB& s)                      // r <= s
      { return r.x* s.y <= r.y* s.x; }
    friend bool operator> (CRB& r, CRB& s)                      // r >  s
      { return r.x* s.y >  r.y* s.x; }
    friend bool operator>=(CRB& r, CRB& s)                      // r >= s
      { return r.x* s.y >= r.y* s.x; }

    friend istream& operator>>(istream& ut, Rac_broj& r);       // �itanje.
    friend ostream& operator<<(ostream& it, CRB& r);            // Pisanje.
  };
}

#endif
