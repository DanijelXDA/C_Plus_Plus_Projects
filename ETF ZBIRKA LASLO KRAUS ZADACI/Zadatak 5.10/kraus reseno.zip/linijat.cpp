// linijat.C - Ispitivanje klasa linija u ravni.

#include "tacka6.h"
#include "linija.h"
#include "duz1.h"
#include "izlomljena.h"
#include "poligon.h"
using namespace Linije;
#include <iostream>
#include <cstdlib>
using namespace std;

Linija* citaj() {                                  // �itanje jedne linije.
  cout << "Vrsta (D, I, P)? "; char vrs; cin >> vrs;
  switch (vrs) {
    case 'd': case 'D': {
      cout << "A? "; double xA, yA; cin >> xA >> yA;
      cout << "B? "; double xB, yB; cin >> xB >> yB;
      return new Duz(Tacka(xA, yA), Tacka(xB, yB));
    }
    case 'i': case 'I':
    case 'p': case 'P': {
      cout << "Broj temena? "; int n; cin >> n;
      Tacka* niz = new Tacka [n];
      for (int i=0; i<n; i++) {
        cout << i+1 << ". teme? "; double x, y; cin >> x >> y;
        niz[i] = Tacka(x, y);
      }
      Linija* lin = (vrs=='i' || vrs=='I') ? new Izlomljena(niz, n)
                                           : new Poligon   (niz, n);
      delete [] niz;
      return lin;
    }
    default: return nullptr;
  }
}

int main(int, const char** varg) {                 // Glavna funkcija.
  int n = atoi(varg[1]);
  Linija** niz = new Linija* [n];
  for (int i=0; i<n; )
    if (Linija* lin = citaj()) niz[i++] = lin;
      else cout << "*** Nepoznata vrsta linije! ***\n";
  cout << "\nProcitano:\n";
  double max = niz[0]->duzina(); int imax = 0;
  for (int i=0; i<n; i++) {
    double d = niz[i]->duzina();
    cout << *niz[i] << " d=" << d << endl;
    if (d > max) { max = d; imax = i; }
  }
  cout << "\nNajduza: " << *niz[imax] << endl;
  for (int i=0; i<n; delete niz[i++]);
  delete [] niz;
}
