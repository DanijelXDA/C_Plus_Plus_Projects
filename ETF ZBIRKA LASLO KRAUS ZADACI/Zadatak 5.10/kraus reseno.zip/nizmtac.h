// nizmatac.h - Definicija klase nizova materijalnih tacaka.

#include "mattacka.h"

class Niz_mat_tac {
  Mat_tacka* niz;                              // Niz tacaka.
  int kap, duz;                                // Kapacitet i duzina niza.
public:
  explicit Niz_mat_tac(int k=5) {              // Stvaranje praznog niza.
    niz = new Mat_tacka [kap = k];
    duz = 0;
  }
  Niz_mat_tac(const Niz_mat_tac& nmt);         // Kopirajuci konstruktor.
  Niz_mat_tac(Niz_mat_tac&& nmt) {             // Premestajuci konstruktor.
    niz = nmt.niz; nmt.niz = nullptr;
    kap = nmt.kap; duz = nmt.duz;
  }
  ~Niz_mat_tac() { delete [] niz; }            // Destruktor.
  int vel() const { return duz; }              // Velicina niza.
  Niz_mat_tac& dodaj(const Mat_tacka& mt);     // Dodavanje tacke.
  Mat_tacka max_F(const Mat_tacka& mt) const;  // Najjaca tacka.
  void pisi() const;                           // Pisanje niza.
};
