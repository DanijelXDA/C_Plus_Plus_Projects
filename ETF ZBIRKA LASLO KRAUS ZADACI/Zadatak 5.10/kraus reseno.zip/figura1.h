// figura1.h - Klasa geometrijskih figura u ravni.

#ifndef _figura1_h_
#define _figura1_h_

#include "tacka4.h"

class Figura {
  Tacka T;                                           // Te�i�te figure.
public:
  Figura(const Tacka& tt=ORG): T(tt)  {}             // Stvaranje figure.
  virtual ~Figura() {}                               // Uni�tavanje figure.
  Figura& postavi(Real x, Real y)                    // Postavljanje figure.
    { T = Tacka(x, y); return *this; }
  Figura& pomeri(Real dx, Real dy)                   // Pomeranje figure.
    { T = Tacka(T.aps()+dx, T.ord()+dy); return *this; }
  virtual Real O() const =0;                         // Obim figure.
  virtual Real P() const =0;                         // Povr�ina figure.
  virtual Figura* kopija() const =0;                 // Kopija figure.
protected:
  virtual void citaj(istream& ut)       { ut >> T; }         // �itanje fig.
  friend istream& operator>>(istream& ut, Figura& f)
    { f.citaj(ut); return ut; }
  virtual void pisi (ostream& it) const { it << "T=" << T; } // Pisanje fig.
  friend ostream& operator<<(ostream& it, const Figura& f)
    { f.pisi(it); return it; }
};

