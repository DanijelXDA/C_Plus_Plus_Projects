// red5.h - Klasa redova tacaka pomocu klase list<>.

#ifndef _red5_h_
#define _red5_h_

#include "tacka4.h"
#include "greska.h"
#include <list>
#include <iostream>
using namespace std;

class Red5 {
  list<Tacka> niz;                             // Sadrzaj reda.
public:
  void stavi(const Tacka& t)                   // Stavljanje na kraj.
    { niz.push_back(t); }
   Tacka uzmi() {                               // Uzimanje sa pocetka.
    if (prazan()) throw Usluge::Greska("Red je prazan!");
    Tacka t = niz.front();
    niz.pop_front();
    return t;
  }
  unsigned vel() const { return niz.size(); }  // Broj elemenata u redu.
  bool prazan() const { return vel() == 0; }   // Da li je red prazan?
  void prazni() { niz.clear(); }               // Praznjenje reda.
  friend ostream& operator<<(ostream& it, const Red5& r); // Pisanje.
};

#endif

