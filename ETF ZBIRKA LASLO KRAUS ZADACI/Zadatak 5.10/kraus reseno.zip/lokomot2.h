// lokomot2.h - Klasa lokomotiva.

#ifndef _lokomot2_h_
#define _lokomot2_h_

#include "vozilo4.h"

class Lokomot: public Vozilo {
  double v_sila;                                           // Vu�na sila.
  void pisi(ostream& it) const override                    // Pisanje.
    { it << "L(" << uk_tezina() << '|' << v_sila<< ')'; }
public:
  Lokomot(double st, double vs): Vozilo(st), v_sila(vs) {} // Stvaranje.
  double vucna_sila() const override { return v_sila; }    // Vu�na sila.
};

#endif

