// vektor2.h - Klasa vektora realnih brojeva.

#ifndef _vektor2_h_
#define _vektor2_h_

class Vekt {                            // Polja:
  int min, max;                         // - granice indeksa,
  int duz;                              // - broj komponenata,
  double* niz;                          // - niz komponenata.
                                        // Pomo�ne metode:
  void pravi(int poc, int kra);         // - formiranje vektora,
  void kopiraj(const Vekt& v);          // - kopiranje u vektor,
  void premesti(Vekt& v) {              // - preme�tanje u vektor,
    min = v.min; max = v.max; duz = v.duz;
    niz = v.niz; v.niz = nullptr;
  }
  void brisi()                          // - osloba�anje memorije.
    { delete[] niz; niz = nullptr; }
public:                                 // Kodovi gre�aka:
  enum Greska { OPSEG,                  // - neispravan opseg indeksa,
                PRAZAN,                 // - vektor je prazan,
                INDEKS,                 // - indeks je izvan opsega,
                DUZINA };               // - neusagla�ene du�ine vektora.
                                             // Konstruktori:
  Vekt() { niz = nullptr; }                  // - prazan niz,
  explicit Vekt(int kra) { pravi(1, kra); }  // - podraz. po�etni indeks,
  Vekt(int poc, int kra) { pravi(poc,kra); } // - sa zadatim indeksima,
  Vekt(const Vekt& v) { kopiraj(v); }        // - kopiranjem,
  Vekt(Vekt&& v) { premesti(v); }            // - preme�tanjem.
  ~Vekt() { brisi(); }                       // Destruktor.
  Vekt& operator=(const Vekt& v) {           // Dodela vrednosti:
    if (this != &v) { brisi(); kopiraj(v); } // - kopiranjem,
    return *this;
  }
  Vekt& operator=(Vekt&& v) {                // - preme�tanjem.
    if (this != &v) { brisi(); kopiraj(v); }
    return *this;
  }                                          // Pristup komponenti:
  double& operator[](int ind) {              // - promenljivog vektora,
    if (niz == nullptr)     throw PRAZAN;
    if (ind<min || ind>max) throw INDEKS;
    return niz[ind-min];
  }
  const double& operator[](int ind) const    // - nepromenljivog vektora.
    { return const_cast<Vekt&>(*this)[ind]; }
  friend double operator*                    // Skalarni proizvod.
    (const Vekt& v, const Vekt& w);
  int minInd() const { return min; }         // Najmanji indeks.
  int maxInd() const { return max; }         // Najve�i indeks.
};

#endif
