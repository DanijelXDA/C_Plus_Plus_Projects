// tekst1t.C - Ispitivanje klase tekstova.

#include "tekst1.h"
#include <iostream>
using namespace std;

int main(int barg, char* varg[]) {
  Tekst t;
  while (--barg) { t += *++varg; if (barg > 1) t += " "; }
  cout << len(t) << " - " << t << endl;
  int k = 1; for (int i=0; i<len(t); i++) if (t[i] == ' ') k++;
  cout << "Broj reci: " << k << endl;
  int i;
  while ((i = t % " ") >= 0) {
    Tekst r = t(0, i-1);
    cout << len(r) << " - " << r <<endl;
    t = t(i+1, len(t)-1);
  }
  cout << len(t) << " - " << t << endl;
}
