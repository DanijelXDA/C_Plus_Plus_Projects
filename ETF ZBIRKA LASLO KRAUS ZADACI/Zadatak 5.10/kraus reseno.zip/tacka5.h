// tacka5.h - Klasa pokretnih tacaka.

#ifndef _tacka5_h_
#define _tacka5_h_

#include "pokretan.h"
#include "vektor1.h"
#include "brzina.h"

class Tacka: public Pokretan {
  static int posId;  // Poslednji identifikator.
  const int id;      // Identifikator tacke.
  Vektor r;          // Vektor polozaja.
  Brzina v;          // Vektor brzine.
public:
  Tacka(const Vektor& rr=Vektor(),              // Nova tacka dobija nov 
        const Brzina& vv=Brzina())              //   identifikator.
    : r(rr), v(vv), id(++posId) {}
  Tacka(const Tacka& T)                         // Kopija tacke dobija nov
    : r(T.r), v(T.v), id(++posId) {}            //   identifikator.
  Tacka& operator=(const Tacka& T)              // Levom operandu se ne
    { r = T.r; v = T.v; return *this; }         //   menja identifikator.
  Tacka& proteklo(double dt)                    // Promena polozaja zbog
    { r = r + v * dt; return *this; }           //   proteklog vremena.
  Vektor R() const { return r; }                // Trenutni polozaj.
  friend double rastojanje(const Tacka& T1, const Tacka& T2) // Rastojanje
    { return (T2.r + T1.r * -1).intenz(); }                  //   dve tacke
  friend ostream&  operator<<(ostream& it, const Tacka& T)   // Pisanje.
    { return it << 'T' << T.id << T.r; }
};

#endif
