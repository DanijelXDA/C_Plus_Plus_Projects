// vektor4.h - Klasa vektora u ravni.

#ifndef _vektor4_h_
#define _vektor4_h_

#include <iostream>
using namespace std;

class Vektor {
  double x, y;                               // Komponente vektora.
public:
  Vektor(double a=0, double b=0) {x=a; y=b;} // Inicijalizacija.
  Vektor& operator+=(const Vektor& v)        // Dodavanje (zbir) vektora.
    { x += v.x; y += v.y; return *this; }
  friend ostream& operator<<(ostream& it, const Vektor& v) // Pisanje.
    { return it<<'('<<v.x<<','<<v.y<<')'; }
};

#endif

