// stek1t.C - Ispitivanje genericke klase stekova zadatih kapaciteta. 

#include "stek1.h"
#include <iostream>
using namespace std;

int main() {
  Stek<int,10>   clb_stek; // Stek celih   brojeva kapaciteta 10.
  Stek<double,3> dbl_stek; // Stek realnih brojeva kapaciteta  3.

  cout << "\nPunjenje   celobrojnog steka:";
  int i = 0;
  while (!clb_stek.pun()) { clb_stek.stavi(i); cout << ' ' << i; i++; }
  cout << "\nPraznjenje celobrojnog steka:";
  while (!clb_stek.prazan()) { clb_stek.uzmi(i); cout << ' ' << i; }
  cout << endl;
  cout << "\nPunjenje   realnog steka:";
  double d = 1.11;
  while (!dbl_stek.pun()) { dbl_stek.stavi(d); cout << ' ' << d; d+=1.11; }
  cout << "\nPraznjenje realnog steka:";
  while (!dbl_stek.prazan()) { dbl_stek.uzmi(d); cout << ' ' << d; }
  cout << endl;
}

