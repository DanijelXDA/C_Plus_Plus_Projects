// niz2gr.h - Klase gre�aka.

#ifndef _niz2gr_h_
#define _niz2gr_h_

#include <iostream>
using namespace std;

class G_pun {};         // GRE�KA: Niz je pun.

class G_prazno {        // GRE�KA: Mesto u nizu je prazno.
public:
  friend ostream& operator<<(ostream& it, const G_prazno&)
    { return it << "*** GRESKA: Pristup praznom mestu u nizu! ***\n"; }
};

class G_indeks {        // GRE�KA: Indeks je izvan opsega.
  int ind, duz;         // Pogre�an indeks i du�ina niza.
public:
  G_indeks(int i, int d) { ind = i; duz = d; }
  int dohv_ind() const { return ind; } // Dohvatanje pogre�nog indeksa.
  int dohv_duz() const { return duz; } // Dohvatanje du�ine niza.
  friend ostream& operator<<(ostream& it, const G_indeks& g) {
    return it << "*** GRESKA: Nedozvoljen indeks " << g.ind
              << " u nizu duzine " << g.duz << "! ***\n";
  }
};

#endif
