// redtela.C - Metode i funkcije uz klasu redova tela.

#include "redtela.h"

Red_tela::Red_tela(int k) {                  // Konstruktor praznog reda.
  tela = new Telo* [kap = k];
  for (int i=0; i<kap; tela[i++]=0);
  prvo = posl = duz = 0;
}

void Red_tela::kopiraj(const Red_tela& rt) { // Kopiranje u red.
  tela = new Telo* [kap = rt.kap];
  for (int i=0; i<kap; i++)
    tela[i] = rt.tela[i] ? rt.tela[i]->kopija() : 0;
  prvo = rt.prvo; posl = rt.posl; duz  = rt.duz;
}

void Red_tela::brisi() {                     // Osloba�anje memorije.
  for (int i=0; i<kap; delete tela[i++]);
  delete [] tela;
}

ostream& operator<<(ostream& it, // Pisanje.
                    const Red_tela& r) {
  it << "red[";
  for (int i=0; i<r.duz; i++) {
    if (i) it << ',';
    it << *r.tela[(r.prvo+i)%r.kap];
  }
  return it << ']';
}
