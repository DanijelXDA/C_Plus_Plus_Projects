// listadatt.C - Ispitivanje klase listi datuma.

#include "listadat.h"
#include <iostream>
using namespace std;

int main() {
  while (true) {
    Lista lst;
    while (true) {
      cout << "Datum (d,m,g)? "; int d, m, g; cin >> d >> m >> g;
    if (!Datum::moze(d, m, g)) break;
      lst.dodaj(Datum(d, m, g));
    }
  if (lst.duzina() == 0) break;
    cout << "Lista= "; lst.pisi(); cout << endl;
    cout << "Najkasnije= "; lst.max()->pisi(); cout << endl;
  }
}
