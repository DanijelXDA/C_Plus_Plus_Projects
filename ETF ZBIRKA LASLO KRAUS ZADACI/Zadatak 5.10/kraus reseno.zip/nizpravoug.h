// nizpravoug.h - Deklaracije paketa za obradu
//                dinamickih nizova pravougaonika u ravni.

#include "pravoug1.h"
#include <iostream>
using namespace std;

namespace Geometr {
  struct Niz_prav { int n; Pravoug* a; };

  inline void pravi(Niz_prav& niz) { niz.n = 0; niz.a = nullptr; }

  void citaj(Niz_prav& niz);

  void pisi(const Niz_prav& niz);

  void brisi(Niz_prav& niz);

  void kopiraj(Niz_prav& niz1, const Niz_prav& niz2);

  void uredi(Niz_prav& niz);
}

