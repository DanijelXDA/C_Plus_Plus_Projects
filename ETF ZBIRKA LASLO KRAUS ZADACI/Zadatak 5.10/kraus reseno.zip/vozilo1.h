// vozilo1.h - Apstraktna klasa vozila.

#ifndef _vozilo1_h_
#define _vozilo1_h_

#include "osoba3.h"
#include <iostream>
using namespace std;

class Vozilo { 
  float sop_tez;                                 // Sopstvena tezina vozila.
  const Osoba *vozac;                            // Vozac vozila.
public:
  Vozilo(const Osoba* vozac, float sop_tez)      // Konstruktor.
    { this->vozac = vozac; this->sop_tez=sop_tez; }
  Vozilo(const Vozilo&) =delete;                 // Ne sme da se kopira.
  Vozilo& operator=(const Vozilo&) =delete;      // Ne sme da se dodeljuje.
  virtual ~Vozilo() {}                           // Virtuelan destruktor.
  virtual char vrsta() const =0;                 // Oznaka vrste vozila.
  virtual float tezina() const                   // Ukupna tezina vozila.
    { return sop_tez + vozac->dohv_tez(); }
protected:
  virtual void pisi(ostream& it) const           // Pisanje vozila.
    { it << vrsta() << '[' << *vozac << ',' << sop_tez << ']'; }
  friend ostream& operator<<(ostream& it, const Vozilo& v)
    { v.pisi(it); return it; }
};

#endif

