// vagon.C - Metode klase vagona.

#include "vagon.h"

void Vagon::pisi(ostream& it) const {               // Pisanje vagona.
  it << "V(" << uk_tezina() << "|";
  for (int i=0; i<tereti.duzina(); i++) {
    if (i > 0) it << ',';
    it << tereti[i];
  }
  it << ')';
}

double Vagon::uk_tezina() const {                   // Ukupna te�ina vagona.
  double t = Vozilo::uk_tezina();
  for (int i=0; i<tereti.duzina(); i++)
    t += tereti[i].tezina();
  return t;
}

