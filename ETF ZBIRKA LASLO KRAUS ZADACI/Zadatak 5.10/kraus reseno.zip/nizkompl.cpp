// Niz_kompl.C - Metoda klase nizova kompleksnih brojeva.

#include "nizkompl.h"

void Niz_kompl::kopiraj(const Niz_kompl& nk) { // kopiranje u niz.
  niz = new Kompl [n = nk.n];
  for (int i=0; i<n; i++) niz[i] = nk.niz[i];
}

