// tacka2.h - Definicija klase tacaka u ravni.

class Tacka {
  double x, y;                      // Koordinate.
public:
  void postavi(double a, double b)  // Postavljanje
    { x = a; y = b; }               //   koordinata.
  double aps() const { return x; }  // Apscisa.
  double ord() const { return y; }  // Ordinata.
  double rastojanje(Tacka) const;   // Rastojanje do tacke.
  void citaj();                     // Citanje tacke.
  void pisi() const;                // Pisanje tacke.
};

// Definicije ugradjenih metoda izvan klase.

#include <iostream>
using namespace std;

inline void Tacka::citaj()          // Citanje tacke.
  { cin >> x >> y; }

inline void Tacka::pisi() const     // Pisanje tacke.
  { cout << '(' << x << ',' << y << ')'; }
