// lista6t.C - Ispitivanje klasa neuredjenih i uredjenih listi.

#include "lista5.h"
#include "lista6.h"
#include <iostream>
using namespace std;

int main() {
  N_lista lst1; U_lista lst2; cout << "Niz? ";
  do { int b; cin >> b; lst1 += b; lst2 += b; } while (cin.get() != '\n');
  cout << "Neuredjeno= " << lst1 << endl;
  cout << "Uredjeno  = " << lst2 << endl;
  N_lista lst3; cout << "Niz? ";
  do { int b; cin >> b; lst3 += b; } while (cin.get() != '\n');
  cout << "Neuredjeno= " << (lst1+=lst3) << endl;
  cout << "Uredjeno  = " << (lst2+=lst3) << endl;
  cout << "Neuredjeno= " << (lst1+=lst1) << endl;
  cout << "Uredjeno  = " << (lst2+=lst2) << endl;
}

