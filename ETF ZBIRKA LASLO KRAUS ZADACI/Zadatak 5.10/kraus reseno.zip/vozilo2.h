// vozilo2.h - Klasa vozila.

#ifndef _vozilo2_h_
#define _vozilo2_h_

#include <iostream>
using namespace std;

namespace Vozovi1 {
  class Vozilo {
    static int pos_id;                   // Poslednji identifikator.
    int id = ++pos_id;                   // Identifikator vozila.
    float sop_tez;                       // Sopstvena te�ina vozila.
 
  public:
    Vozilo(float tez)                   // Novom vozilu novi identifikator.
      { sop_tez = tez; }
    Vozilo(const Vozilo& v)             // Kopiji novi identifikator.
      { sop_tez = v.sop_tez; }
    Vozilo& operator=(const Vozilo&v)   // Levom operandu se ne menja ident.
      { sop_tez = v.sop_tez; return *this; }
    float sop_tezina() const { return sop_tez; } // Sopstvena te�ina vozila.
    virtual char vrsta() const =0;               // Oznaka vrste vozila.
    virtual float uk_tezina() const =0;          // Ukupna te�ina vozila.
    virtual Vozilo* kopija() const& =0;       // Kopija vozila kopiranjem.
    virtual Vozilo* kopija() && =0;           // Kopija vozila preme�tanjem.
  protected:
    virtual void pisi(ostream& it) const      // Pisanje vozila.
      { it << vrsta() << id << '[' << sop_tez << ']'; }
    friend ostream& operator<<(ostream& it,
        const Vozilo& v) { v.pisi(it); return it; }
  }; // class
} // namespace

#endif

