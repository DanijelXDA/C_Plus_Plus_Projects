// oper.h - Klasa operatora.

#ifndef _oper_h_
#define _oper_h_

#include "izraz.h"
#include <cmath>
using namespace std;

namespace Izrazi {
  class Oper: public Izraz { // APSTRAKTNA KLASA BINARNIH OPERATORA.
  protected:
    Izraz *a, *b;                          // Operandi.
    void pisi(ostream& it, char op) const  // Pisanje operatora.
      { it << '(' << *a << op << *b << ')'; }
  private:
    void kopiraj(const Oper& op)           // Kopiranje u objekat.
      { a = op.a->kopija(); b = op.b->kopija(); }
    void brisi() { delete a; delete b; }   // Osloba�anje memorije.
  public:
    Oper(const Izraz& x, const Izraz& y)   // Inicijalizacija izrazima.
      { a = x.kopija(); b = y.kopija(); }
    Oper(const Oper& op) { kopiraj(op); }  // Kopiraju�i konstruktor.
    ~Oper() { brisi(); }                   // Destruktor.
    Oper& operator=(const Oper& op) {      // Kopiraju�a dodela vrednosti.
      if (this != &op) { brisi(); kopiraj(op); }
      return *this;
    }
  }; // class Oper

  class Zbir: public Oper {                                // KLASA ZBIROVA.
    void pisi(ostream& it) const override {Oper::pisi(it,'+');}  // Pisanje.
  public:
    Zbir(const Izraz& x, const Izraz& y): Oper(x, y) {}        // Stvaranje.
    double vredn() const override {return a->vredn() + b->vredn();} //Vredn.
    Zbir* kopija() const override {return new Zbir(*this);}       // Kopija.
  }; // class Zbir

  class Razl: public Oper {                                // KLASA RAZLIKA.
    void pisi(ostream& it) const override {Oper::pisi(it,'-');}  // Pisanje.
  public:
    Razl(const Izraz& x, const Izraz& y): Oper(x, y) {}        // Stvaranje.
    double vredn() const override {return a->vredn() - b->vredn();} //Vredn.
    Razl* kopija() const override {return new Razl(*this);}       // Kopija.
  }; // class Razl

  class Proizv: public Oper {                            // KLASA PROIZVODA.
    void pisi(ostream& it) const override {Oper::pisi(it,'*');}  // Pisanje.
  public:
    Proizv(const Izraz& x, const Izraz& y): Oper(x,y) {}       // Stvaranje.
    double vredn() const override {return a->vredn() * b->vredn();} //Vredn.
    Proizv* kopija() const override {return new Proizv(*this);}   // Kopija.
  }; // class Proizv

  class Kolic: public Oper {                             // KLASA KOLI�NIKA.
    void pisi(ostream& it) const override {Oper::pisi(it,'/');}  // Pisanje.
  public:
    Kolic(const Izraz& x, const Izraz& y): Oper(x, y) {}       // Stvaranje.
    double vredn() const override {return a->vredn() / b->vredn();} //Vredn.
    Kolic* kopija() const override {return new Kolic(*this);}     // Kopija.
  }; // class Kolic

  class Step: public Oper {                                // KLASA STEPENA.
    void pisi(ostream& it) const override {Oper::pisi(it,'^');}  // Pisanje.
  public:
    Step(const Izraz& x, const Izraz& y): Oper(x, y) {}        // Stvaranje.
    double vredn() const override                               // Vrednost.
      { return pow(a->vredn(), b->vredn()); }
    Step* kopija() const override {return new Step(*this);}       // Kopija.
  }; // class Step

  // POMO�NE FUNKCIJE ZA OMOGU�AVANJE PISANJA �ITLJIVIH IZRAZA.
  inline Zbir   operator+ (const Izraz& a, const Izraz& b) // a +  b
    { return Zbir  (a, b); }
  inline Razl   operator- (const Izraz& a, const Izraz& b) // a -  b
    { return Razl  (a, b); }
  inline Proizv operator* (const Izraz& a, const Izraz& b) // a *  b
    { return Proizv(a, b); }
  inline Kolic  operator/ (const Izraz& a, const Izraz& b) // a /  b
    { return Kolic (a, b); }
  inline Step   operator^ (const Izraz& a, const Izraz& b) // a ^  b
    { return Step  (a, b); }
  inline bool   operator==(const Izraz& a, const Izraz& b) // a == b
    { return a.vredn() == b.vredn(); }
  inline bool   operator!=(const Izraz& a, const Izraz& b) // a != b
    { return a.vredn() != b.vredn(); }
  inline bool   operator< (const Izraz& a, const Izraz& b) // a <  b
    { return a.vredn() <  b.vredn(); }
  inline bool   operator<=(const Izraz& a, const Izraz& b) // a <= b
    { return a.vredn() <= b.vredn(); }
  inline bool   operator> (const Izraz& a, const Izraz& b) // a >  b
    { return a.vredn() >  b.vredn(); }
  inline bool   operator>=(const Izraz& a, const Izraz& b) // a >= b
    { return a.vredn() >= b.vredn(); }

} // namespace Izrazi;

#endif
