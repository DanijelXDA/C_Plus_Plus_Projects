// mnogougao2.C - Metode klase mnogouglova u ravni.

#include "mnogougao2.h"
#include "trougao5.h"

bool Figure::Mnogougao::pripada(const Tacka& T) const { // Da li pripada?
  for (int i=1; i<temena.vel()-1; i++)
    if (Trougao(temena[0],temena[i],temena[i+1]).pripada(T)) return true;
  return false;
}

