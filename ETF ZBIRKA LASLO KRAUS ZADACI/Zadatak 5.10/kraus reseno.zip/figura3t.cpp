// figura3t.C - Ispitivanje klasa obojenih figura u ravni.

#include "boja.h"
#include "tacka9.h"
#include "krug3.h"
#include "pravoug3.h"
#include "trougao5.h"
#include "mnogougao2.h"
#include "crtez1.h"
using namespace Figure;
#include <iostream>
using namespace std;

int main() {
  Crtez crt(Tacka(3,1), 15, 12, Boja(.9,.9,.9));
  crt.dodaj(new Pravoug(Tacka(-2,5), 11, 3, Boja(1,0,0)))
     .dodaj(new Mnogougao(Niz<Tacka>().dodaj(Tacka(8,2))
                                      .dodaj(Tacka(11,4))
                                      .dodaj(Tacka(12,8))
                                      .dodaj(Tacka(7,7))
                                      .dodaj(Tacka(6,4)),
                          Boja(0,1,0)
           ))
     .dodaj(&(new Crtez(Tacka(9,6), 9, 6, Boja(.5,.5,.5)))
               ->dodaj(new Trougao(Tacka(1,1),Tacka(5,1),Tacka(1,3),
                                   Boja(0,1,1)))
                .dodaj(new Pravoug(Tacka(4,4), 4, 2, Boja(1,0,1)))
           )
     .dodaj(new Krug(Tacka(5,6), 3, Boja(0,0,1)));

  while (true) {
    cout << "Tacka (x,y)? "; double x, y; cin >> x >> y;
  if (x == 1E38) break;
    try {
      cout << "Boja tacke:  " << crt.boja(Tacka(x,y)) << endl;
    } catch (G_ne_pripada g) { cout << g << '\n'; }
  }
}

