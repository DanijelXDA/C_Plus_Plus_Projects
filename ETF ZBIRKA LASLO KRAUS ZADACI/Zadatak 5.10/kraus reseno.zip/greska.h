// greska.h - Klasa gre�aka.

#ifndef _greska_h_
#define _greska_h_

#include <iostream>
#include <string>
using namespace std;

namespace Usluge {
  class Greska {
    string poruka;                                   // Tekst poruke.
  public:                                            // Konstruktori:
    Greska() =default;                               // - podrazumevani,
    Greska(string por) { poruka = por; }             // - konvertuju�i.
    virtual ~Greska() {}                             // Destruktor.
  protected:
    virtual void pisi(ostream& it) const {           // Pisanje poruke.
      it << "\n*** " << (poruka!="" ? poruka : "Greska") << " ***\a\n";
    }
    friend ostream& operator<<(ostream& it, const Greska& g)
      { g.pisi(it); return it; }
    bool imaPoruke() const { return poruka != ""; }  // Ima li poruke?
  }; // class Greska
} // namespace Usluge

#endif

