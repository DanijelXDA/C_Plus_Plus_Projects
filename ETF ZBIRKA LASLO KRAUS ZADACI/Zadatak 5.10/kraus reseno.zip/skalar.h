// skalar.h - Klasa skalarnih podataka.

#ifndef _skalar_h_
#define _skalar_h_

#include "podatak.h"
#include <utility>
using namespace std;

class Skalar: public Podatak {
  double vredn;                              // Vrednost skalara.
public:
  Skalar(double v=0) { vredn = v; }          // Konstruktor.
  Skalar* kopija() const& override           // Kopija skalara kopiranjem.
    { return new Skalar(*this); }
  Skalar* kopija() && override               // Kopija skalara preme�tanjem.
    { return new Skalar(move(*this)); }
  double vr() const { return vredn; }        // Vrednost skalara.
private:
  void pisi(ostream& it) const override {it << vredn;} // Pisanje skalara.
};

#endif

