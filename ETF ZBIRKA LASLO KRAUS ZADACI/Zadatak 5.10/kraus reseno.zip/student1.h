// student1.h - Klasa studenata.

#include <string>
using namespace std;

class Student {
  string ime;          // Ime studenta.
  long  ind;           // Broj indeksa (ggggrrrr).
  int*  ocene;         // Niz ocena.
  int   kap, br_oc;    // Kapacitet niza i broj ocena.
public:
  Student(string iime, long iind, int kkap=40);   // Konstruktor.
  ~Student() { delete [] ocene; }                 // Destruktor.
  Student(const Student&) =delete;                // Ne sme da se kopira.
  Student& operator=(const Student&) =delete;     // Ne sme da se dodeljuje.
  string dohvati_ime() const { return ime; }      // Ime studenta.
  long dohvati_ind() const { return ind; }        // Broj indeksa.
  Student& promeni_ime(string iime)               // Promena imena.
    { ime = iime; return *this; }
  Student& promeni_ind(long iind)                 // Promena broja indeksa.
    { ind = iind; return *this; }
  Student& operator+=(int ocena);                 // Dodavanje ocene.
  int br_ocena() const { return br_oc; }          // Broj ocena.
  int& operator[](int i);                         // Dohvatanje ocene.
  int operator[](int i) const; 
  double sr_ocena() const;                        // Srednja ocena.
};

