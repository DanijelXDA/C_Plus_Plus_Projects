// prodavac.h - Klasa prodavaca.

#ifndef _prodavac_h_
#define _prodavac_h_

#include "radnik2.h"

namespace Trgovina {
  class Prodavac: public Radnik {
    double prih;                                    // Ostvareni prihod.
  public:
    Prodavac(string ime, double procenat):          // Inicijalizacija.
        Radnik(ime, procenat) { prih = 0; }
    Prodavac& prodao(double vrednost)               // Prodaja robe.
      { prih += vrednost; return *this; };
    double prihod() const override { return prih; } // Ostvareni prihod.
  }; // class
} // namespace

#endif

