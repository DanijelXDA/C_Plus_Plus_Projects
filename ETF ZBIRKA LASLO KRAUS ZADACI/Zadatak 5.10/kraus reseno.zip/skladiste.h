// skladiste.h - Generi�ka klasa skladi�ta stvari.

#ifndef _skladiste_h_
#define _skladiste_h_

#include <iostream>
using namespace std;

class G_puno {};                     // KLASA GRE�AKA: Skladi�te je puno.
inline ostream& operator<<(ostream& it, const G_puno&)
  { return it << "*** Skladiste je puno! ***"; }

class G_prazno {};                   // KLASA GRE�AKA: Skladi�te je prazno.
inline ostream& operator<<(ostream& it, const G_prazno&)
  { return it << "*** Skladiste je prazno! ***"; }

template <typename T>               // GENERI�KA KLASA SKLADI�TA:
class Skladiste {
  T* niz;                           // Niz stvari.
  int kap, duz;                     // Kapacitet i popunjenost niza.
  int prvi, posl;                   // Indeks prve i poslednje stvari.
  void kopiraj(const Skladiste& s); // Kopiranje u skladi�te.
  void premesti(Skladiste s) {      // Preme�tanje u skladi�te.
    niz = s.niz; s.niz = nullptr;
    kap = s.kap; duz = s.duz;
    prvi = s.prvi; posl = s.posl;
  }
  void brisi() { delete [] niz; }   // Osloba�anje memorije.
public:
  explicit Skladiste(int k=10) {    // Stvaranje praznog skladi�ta.
    niz = new T [kap = k];
    prvi = posl = duz = 0;
  }
  Skladiste(const Skladiste& s) { kopiraj(s); } // Kopiraju�i konstruktor.
  Skladiste(Skladiste&& s) { premesti(s); }     // Preme�taju�i konstruktor.
  ~Skladiste() { brisi(); }                     // Destruktor.
  Skladiste& operator=(const Skladiste& s) {    // Kopiraju�a dodela
    if (this != &s) { brisi(); kopiraj(s); }    //   vrednosti.
    return *this;
  }
  Skladiste& operator=(Skladiste&& s) {          // Preme�taju�a dodela
    if (this != &s) { brisi(); premesti(s); }    //   vrednosti.
    return *this;
  }
  void stavi(const T& t) {                       // Stavljanje u skladi�te.
    if (duz == kap) throw G_puno();
    niz[posl++] = t;
    if (posl == kap) posl = 0;
    duz++;
  }
  T uzmi() {                                     // Uzimanje iz skladi�ta.
    if (duz == 0) throw G_prazno();
    T t = niz[prvi++];
    if (prvi == kap) prvi = 0;
    duz --;
    return t;
  }
};

template <typename T>                            // METODA KLASE SKLADI�TA:
void Skladiste<T>::kopiraj(const Skladiste& s) { // Kopiranje u skladi�te.
  niz = new T [kap = s.kap];
  for (int i=0; i<kap; i++) niz[i] = s.niz[i];
  prvi = s.prvi; posl = s.posl; duz = s.duz;
}

#endif
