// bure.h - Klasa buradi.

#ifndef _bure_h_
#define _bure_h_

#include "teret.h"
#include <utility>
using namespace std;

class Bure: public Teret {
  double r, h;                               // Polupre�nik i visina valjka.
public:
  explicit Bure(double s=1, double rr=1, double hh=1): // Inicijalizacija.
    Teret(s), r(rr), h(hh) {}
  char vrsta() const override { return 'B'; }// Oznaka vrste tereta.
  double zapr() const override               // Zapremina bureta.
    { return r * r * 3.14159 * h; }
  Bure* kopija() const& override             // Kopija bureta kopiranjem.
    { return new Bure(*this); }
  Bure* kopija() && override                 // Kopija bureta preme�tanjem.
    { return new Bure(move(*this)); }
};

#endif

