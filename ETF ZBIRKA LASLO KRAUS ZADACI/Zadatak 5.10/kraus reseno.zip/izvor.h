// izvor.h - Klasa izvora elektri�ne energije.

#ifndef _izvor_h_
#define _izvor_h_

#include "potrosac1.h"
#include <iostream>
using namespace std;
 
namespace Potrosaci {
  class G_indeks{};                // KLASA GRE�AKA: Indeks izvan opsega.
  inline ostream& operator<<(ostream& it, const G_indeks&)
    { return it << "*** Nedozvoljen indeks! ***"; }

  class G_preopt {};               // KLASA GRE�AKA: Preoptere�en izvor.
  inline ostream& operator<<(ostream& it, const G_preopt&)
    { return it << "*** Preopterecen izvor! ***"; }

  class Izvor {                                 // KLASA IZVORA:
    Potrosac** niz;                             // Niz potro�a�a. 
    int kap;                                    // Broj priklju�nih mesta.
    double sna, opt;               // Nazivna snaga i trenutno optere�enje.
  public:
    Izvor(double s, int k);                     // Stvaranje izvora.
    Izvor(const Izvor&) =delete;                // Ne sme da se kopira.
    Izvor& operator=(const Izvor&) =delete;     // Ne sme da se dodeljuje.
    ~Izvor();                                   // Uni�tavanje izvora.
    double snaga() const { return sna; }        // Nazivna snaga izvora.
    double opterecenje() const { return opt; }  // Trenutno optere�enje.
    int brMesta() const { return kap; }         // Broj priklju�nih mesta.
    Izvor& prikljuci(Potrosac* p, int i);       // Priklju�ivanje potro�a�a.
    friend ostream& operator<<(ostream& it, const Izvor& izv); // Pisanje.
  }; // class
} // namespace

#endif

