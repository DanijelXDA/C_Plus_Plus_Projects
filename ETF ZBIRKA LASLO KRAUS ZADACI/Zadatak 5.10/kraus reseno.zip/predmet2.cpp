// predmet2.C - Stati�ko polje apstraktne klase predmeta.

#include "predmet2.h"

int Zbirke::Predmet::pos_id = 0;

