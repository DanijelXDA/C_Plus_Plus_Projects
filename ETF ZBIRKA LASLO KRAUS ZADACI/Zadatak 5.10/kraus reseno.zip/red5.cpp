// red5.C - Metode i funkcije uz klasu redova tacaka pomocu list<>.

#include "red5.h"

ostream& operator<<(ostream& it, const Red5& r) {         // Pisanje reda.
  for (list<Tacka>::const_iterator i=r.niz.begin();
       i!=r.niz.end();it <<*i++<<' ');
  return it;
}

