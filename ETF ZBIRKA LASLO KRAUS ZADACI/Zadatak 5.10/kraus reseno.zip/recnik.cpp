// recnik.C - Metode i funkcije uz klasu recnika.

#include "recnik.h"

// Pisanje svih prevoda reci.
void Recnik::pisiPrevode(ostream& it, const string& rec) const {
  map<string, set<string> >::const_iterator i = niz.find(rec);
  if (i != niz.end()) {
    for (set<string>::const_iterator j=i->second.begin();
         j!=i->second.end(); j++) {
      if (j != i->second.begin()) it << ", ";
      it << *j;
    }
  }
}

// Pisanje sadrzaja recnika.
ostream& operator<<(ostream& it, const Recnik& recnik) {
  for (map<string,set<string> >::const_iterator i=recnik.niz.begin();
       i!=recnik.niz.end(); i++) {
    it << i->first << ": ";
    for (set<string>::const_iterator j=i->second.begin();
         j!=i->second.end(); j++) {
      if (j != i->second.begin()) it << ", ";
      it << *j;
    }
    it << '.' << endl;
  }
  return it;
}

