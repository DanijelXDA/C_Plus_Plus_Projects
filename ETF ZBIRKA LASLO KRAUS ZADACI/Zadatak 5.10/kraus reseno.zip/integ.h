// integ.h - Deklaracija funkcije za ra�unanje odre�enog integrala.

#ifndef _integ_h_
#define _integ_h_

#include "fun2.h"

namespace Funkcije {
  double integral(const Fun& f, double a, double b);
} // namespace Funkcije

#endif

