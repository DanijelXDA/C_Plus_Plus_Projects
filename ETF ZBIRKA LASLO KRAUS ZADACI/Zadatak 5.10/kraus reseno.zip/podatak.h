// podatak.h - Apstraktna klasa podataka.

#ifndef _podatak_h_
#define _podatak_h_

#include <iostream>
using namespace std;

class Podatak {
public:
  virtual ~Podatak() {}                      // Virtuelan destruktor.
  virtual Podatak* kopija() const& =0;       // Kopija podatka kopiranjem.
  virtual Podatak* kopija() && =0;           // Kopija podatka preme�tanjem.
private:
  virtual void pisi(ostream& it) const =0;   // Pisanje podatka.
  friend ostream& operator<<(ostream& it, const Podatak& pp)
    { pp.pisi(it); return it; }
};

#endif
