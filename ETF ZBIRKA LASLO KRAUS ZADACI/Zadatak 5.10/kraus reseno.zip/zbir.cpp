// zbir.C - Zbir niza celih brojeva.

#include <iostream>
using namespace std;

int main() {

  const int DUZ = 100;

  while (true) {
    cout << "\nDuzina niza? ";
    int n; cin >> n;
  if (n <= 0 || n > DUZ) break;
    int a[DUZ]; cout << "Elementi niza? ";
    for (int i=0; i<n; cin >> a[i++]);
    int s = 0;
    for (int i=0; i<n; s+=a[i++]);
    cout << "Zbir elemenata: " << s << endl;
  }
  return 0;
}
