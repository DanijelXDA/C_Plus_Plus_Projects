// tekst4.C - Metoda klase tekstova.

#include "tekst4.h"

double Tekst::sirina() const {                        // �irina teksta.
  double s = 0;
  for (unsigned i=0; i<tks.length(); s += fnt[tks[i++]].sirina(vis));
  return s;
}

