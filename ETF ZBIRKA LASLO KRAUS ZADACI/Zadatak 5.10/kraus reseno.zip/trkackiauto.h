// tkackiauto.h - Klasa trkackog automobila.

#ifndef _tkackiauto_h_
#define _tkackiauto_h_

#include "vozilo3.h"
#include "niz5.h"
#include "voznja.h"
#include "etapa.h"

class Trkacki_auto: public Vozilo {
  Niz<Voznja> voznje;                           // Niz voznji.
public:
  Trkacki_auto(float sTez, int kap)             // Stvaranje automobila.
    : Vozilo(sTez), voznje(kap) {}
  string vrsta() const {return "Trkacki auto";} // Naziv vrste.
  Trkacki_auto& novaVoznja(int kap) {           // Pocetak nove voznje.
    voznje += Voznja(kap);
    return *this;
  }
  Trkacki_auto& dodaj_etapu(const Etapa& e) {   // Dodavanje nove etape.
    voznje[voznje.duzina()-1] += e;
    return *this;
  }
  const Voznja& najbrza() const;                // Nalazenje najbrze voznje.
};

#endif

