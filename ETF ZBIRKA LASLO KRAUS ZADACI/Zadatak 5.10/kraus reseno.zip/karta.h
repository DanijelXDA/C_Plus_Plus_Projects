// karta.h - Klasa karata.

#include <iostream>
using namespace std;

class Karta {
  int red, sed;                            // Broj reda i sedista.
  float cena;                              // Cena karte.
public:
  Karta(int r, int s, float c)             // Stvaranje karte.
    { red = r; sed = s; cena = c; }
  int dohv_red() const { return red; }     // Dohvatanje broja reda.
  int dohv_sed() const { return sed; }     // Dohvatanje broja sedista.
  float dohv_cenu() const { return cena; } // Dohvatanje cene.
  friend ostream& operator<<(ostream& it, const Karta& k) // Pisanje.
    { return it << '(' << k.red << ',' << k.sed <<  ',' << k.cena << ')'; }
};

