// skladistet.C - Ispitivanje klase skladista.

#include "skladiste.h"
#include "proizvod2.h"
#include "casovnik.h"
#include "proizvodjac.h"
#include "potrosac2.h"

int main() {
  Skladiste<Proizvod> s(3);
  Casovnik c;
  Akter* akteri[5];
  c += akteri[0] = new Proizvodjac<Proizvod>(&s, 2  , 4  );
  c += akteri[1] = new Proizvodjac<Proizvod>(&s, 1  , 5  );
  c += akteri[2] = new Proizvodjac<Proizvod>(&s, 1.5, 4.5);
  c += akteri[3] = new Potrosac   <Proizvod>(&s, 1.5, 2.5);
  c += akteri[4] = new Potrosac   <Proizvod>(&s, 1  , 3  );
  c.radi(0.25, 10);
  for (int i=0; i<5; delete akteri[i++]);
}

