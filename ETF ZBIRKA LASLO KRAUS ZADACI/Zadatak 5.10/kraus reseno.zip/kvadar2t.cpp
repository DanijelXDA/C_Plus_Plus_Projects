// kvadar2t.C - Ispitivanje klase numerisanih kvadara.

#include "kvadar2.h"
#include <iostream>
using namespace std;

int main() {
  Kvadar niz[20];                       // Tu se stvara 20 kvadara.
  cout << "n? "; int n; cin >> n;
  for (int i=0; i<n; i++)
    { cout << "niz[" << i << "]? "; cin >> niz[i]; }
  cout << "\nProcitano:\n";
  for (int i=0; i<n; i++)
    cout << niz[i] << "\t V=" << niz[i].V() << endl;
  Kvadar min = niz[0];                  // Tu se stvara jos jedan kvadar.
  for (int i=1; i<n; i++) if (niz[i] < min) min = niz[i];
  cout << "\nmin= " << min << endl;
}
