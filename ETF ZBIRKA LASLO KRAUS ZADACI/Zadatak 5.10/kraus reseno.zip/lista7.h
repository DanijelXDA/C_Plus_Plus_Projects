// lista7.h - Genericka klasa listi.

#ifndef _lista7_h_
#define _lista7_h_

#include <iostream>
using namespace std;

class G_nema_tek {};                // KLASA GRESAKA: Nema tekuceg elementa.
inline ostream& operator<<(ostream& it, const G_nema_tek&)
  { return it << "*** Nema tekuceg elementa! ***"; }

template <typename T>                         // GENERICKA KLASA LISTI:
  class Lista {

    struct Elem {                             // Element liste:
      T pod;                                  // - sadrzani podatak,
      Elem* sled;                             // - sledeci element,
      Elem(const T& p, Elem* s=nullptr)       // - konstruktor.
        { pod = p; sled = s; }
    };
    Elem *prvi, *posl;                        // Prvi i poslednji element.
    mutable Elem *tek, *pret;                 // Tekuci i prethodni element.
    void kopiraj(const Lista& lst);           // Kopiranje u listu.
    void premesti(Lista& lst) {               // Premestanje u listu.
      prvi = lst.prvi; posl = lst.posl;
      lst.orvi = lst.posl = nullptr;
    }
  public:
    Lista()                                   // Stvaranje prazne liste.
      { prvi = posl = tek = pret = nullptr; }
    Lista(const Lista& lst) { kopiraj(lst); } // Kopirajuci konstruktor.
    Lista(Lista&& lst) { premesti(lst); }     // Premestajuci konstruktor.
    ~Lista() { isprazni(); }                  // Destruktor.
    Lista& operator=(const Lista& lst) {              // Kopirajuca dodela
      if (this != &lst) { isprazni(); kopiraj(lst); } //   vrednosti.
      return *this;
    }
    Lista& operator=(Lista&& lst) {                   // Premestajuca dodela
      if (this != &lst) { isprazni(); premesti(lst); }//   vrednosti.
      return *this;
    }
    Lista& dodaj(const T& t) {                        // Dodavanje na kraj.
      posl = (!prvi ? prvi : posl->sled) = new Elem(t);
      return *this;
    }
    Lista& naPrvi()                         // Postavljanje na prvi element:
      { tek = prvi; pret = nullptr; return *this; }// - promenljive liste,
    const Lista& naPrvi() const                  
      { tek = prvi; pret = nullptr; return *this; }// - nepromenljive liste.
    Lista& naSled() {                       // Pomeranje na sledeci element:
      pret = tek;                                  // - promenljive liste,
      if (tek) tek = tek->sled;
      return *this;
    }
    const Lista& naSled() const {                  // - nepromenljve liste.
      pret = tek;
      if (tek) tek = tek->sled;
      return *this;
    }
    bool imaTek() const { return tek != nullptr; } // Ima li tekuceg?
    T& dohvTek() {                          // Pristup tekucem podatku:
      if (!tek) throw G_nema_tek();         // - promenljive liste,
      return tek->pod;
    }
    const T& dohvTek() const {              // - nepromenljive liste.
      if (!tek) throw G_nema_tek();
      return tek->pod;
    }
    Lista& izbaciTek() {                    // Izbacivanje tekuceg elementa.
      if (!tek) throw G_nema_tek();
      Elem* stari = tek;
      tek = tek->sled;
      (!pret ? prvi : pret->sled) = tek;
      if (!tek) posl = pret;
      delete stari;
      return *this;
    }
    Lista& isprazni();                      // Praznjenje liste.
  }; // class Lista<T>

template <typename T>                         // METODE KLASE LISTI:
  void Lista<T>::kopiraj(const Lista& lst) {  // Kopiranje u listu.
    prvi = posl = tek = pret = nullptr;
    for (Elem* pok=lst.prvi; pok; pok=pok->sled) {
      Elem* novi = new Elem(pok->pod);
      posl = (!prvi ? prvi : posl->sled) = novi;
      if (pok == lst.tek ) tek  = novi;
      if (pok == lst.pret) pret = novi;
    }
  }

template <typename T>
  Lista<T>& Lista<T>::isprazni() {           // Praznjenje liste.
    while (prvi) { Elem* stari = prvi; prvi = prvi->sled; delete stari; }
    posl = tek = pret = nullptr;
    return *this;
  }

#endif

