// tacka5.C - Staticko polje klase pokretnih tacaka.

#include "tacka5.h"

int Tacka::posId = 0;
