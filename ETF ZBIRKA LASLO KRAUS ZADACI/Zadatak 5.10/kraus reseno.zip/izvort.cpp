// izvort.C - Ispitivanje klasa elektri�nih potro�a�a i izvora.

#include "uredjaj.h"
#include "grupa.h"
#include "izvor.h"
using namespace Potrosaci;
#include <iostream>
using namespace std;

Potrosac* citaj() {                             // �itanje potro�a�a:
  cout << "\nTip (U,G,.)? "; char izb; cin >> izb;
  switch (izb) {
    case 'u': case 'U': {                       // - ure�aj,
      cout << "Vrsta? "; char v[20]; cin >> v;
      cout << "Snaga? "; double s; cin >> s;
      return new Uredjaj(v, s);
    }
    case 'g': case 'G': {                       // - grupa ure�aja,
      Grupa* g = new Grupa();
      while (Potrosac* p=citaj()) { *g += *p; delete p; }
      return g;
    }
    default: return nullptr;                    // - "prazan" ure�aj.
  }
}

int main() {                                    // Glavna funkcija.
  cout << "Snaga izvora? "; double s; cin >> s;
  cout << "Broj prikljucaka? "; int k; cin >> k;
  Izvor izv(s, k);
  try {
    while (true) {
      Potrosac* p = citaj();
    if (!p) break;
      cout << "Prikljucak? "; int i; cin >> i;
      izv.prikljuci(p, i);
    }
  } catch (G_indeks g) { cout << g << endl;
  } catch (G_preopt g) { cout << g << endl;
  }
  cout << izv;
}

