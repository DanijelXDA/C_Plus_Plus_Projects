// tekst1.h - Klasa tekstova.

#include <iostream>
#include <cstring>
#include <cstdlib>
using namespace std;

class Tekst {
  char* niz;                                      // Pokazivac na s�m tekst.
  void kopiraj(const char*);                      // Kopiranje u tekst.
  void premesti(Tekst& t)                         // Premestanje u tekst.
    { niz = t.niz; t.niz = nullptr; }
  void brisi() { delete [] niz; }                 // Oslobadjanje memorije.
public:                                           // Inicijalizacija:
  Tekst() { niz = nullptr; }                      // - kao prazan tekst,
  Tekst(const char* n) { kopiraj(n); }            // - niskom,
  Tekst(const Tekst& t) { kopiraj(t.niz); }       // - kopiranjem,
  Tekst(Tekst&& t) { premesti(t);}                // - premestanjem.
  ~Tekst() { brisi(); }                           // Unistavanje.
  Tekst& operator=(const Tekst& t) {              // Dodela vrednosti:
    if (this != &t) { brisi(); kopiraj(t.niz); } // - kopiranjem,
    return *this;
  }
  Tekst& operator=(Tekst&& t) {                   // - premestanjem.
    if (this != &t) { brisi(); premesti(t); }
    return *this;
  }
  friend int len(const Tekst& t)          // Duzina teksta.
    { return t.niz ? strlen(t.niz) : 0; }
  friend Tekst operator+                  // Spajanje tekstova.
    (const Tekst&, const Tekst&);
  Tekst& operator+=(const Tekst& t)       // Dodavanje teksta.
    { return *this = *this + t; }
  char& operator[](int i) {               // Znak u promenljivom tekstu.
    if (i<0 || len(*this)<=i) exit(1);
    return niz[i];
  }
 
  const char& operator[](int i) const {   // Znak u nepromenljivom tekstu.
    if (i<0 || len(*this)<=i) exit(1);
    return niz[i];
  }
  Tekst operator()(int, int) const;                      // Podniz teksta.
  friend int operator%(const Tekst&, const Tekst&);      // Mesto podniza.
  friend ostream& operator<<(ostream& it, const Tekst& t)// Pisanje teksta.
    { if (t.niz) it << t.niz; return it; }
  friend istream& operator>>(istream&, Tekst&);          // Citanje teksta.
};

