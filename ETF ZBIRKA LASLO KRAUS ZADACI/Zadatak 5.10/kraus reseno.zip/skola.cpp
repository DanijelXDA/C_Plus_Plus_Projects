// skola.C - Metode klase skola.

#include "skola.h"

const Djak* Skola::najbolji() const {      // Djak s najvisim prosekom.
  Djak* naj = nullptr; double max = 0;
  for (djaci.naPrvi(); djaci.imaTek(); djaci.naSled()) {
    Djak* tek = djaci.dohvTek();
    double m = tek->srOce();
    if (m > max) { max = m; naj = tek; }
  }
  return naj;
}

