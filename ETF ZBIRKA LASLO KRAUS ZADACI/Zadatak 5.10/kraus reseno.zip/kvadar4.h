// kvadar4.h - Klasa kvadara.

#ifndef _kvadar4_h_
#define _kvadar4_h_

#include "proizvod1.h"

namespace Fabrika {
  class Kvadar: public Proizvod {
    double a, b, c;                             // Dimenzije kvadra.
    void pisi(ostream& it) const override       // Pisanje kvadra.
      { Proizvod::pisi(it); it << '(' << a << ',' << b << ',' << c << ')'; }
  public:
    static const char VR = 'K';                 // Oznaka vrste proizvoda.
    Kvadar(double aa, double bb, double cc)     // Stvaranje kvadra.
      { a = aa; b = bb; c = cc; }
    char vrsta() const override { return VR; }  // Vrsta proizvoda.
    double V() const override { return a*b*c; } // Zapremina kvadra.
  }; // class Kvadar
} // namespace Fabrika

#endif

