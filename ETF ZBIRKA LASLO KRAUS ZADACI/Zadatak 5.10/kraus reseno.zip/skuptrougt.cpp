// skuptrougt.C - Ispitivanje klase skupova trouglova u ravni.

#include "skuptroug.h"
#include <iostream>
using namespace std;

int main() {
  Skup_troug s;
  s += Trougao(Tacka( 1, 1), Tacka( 2, 5), Tacka( 4, 3));
  s += Trougao(Tacka(-1, 1), Tacka(-2, 5), Tacka(-4, 3));
  s += Trougao(Tacka( 1, 1), Tacka( 2, 5), Tacka( 4, 3));
  s += Trougao(Tacka(-1, 1), Tacka(-2, 5), Tacka(-4, 3));
  cout << s << endl << s.ukP() << endl;
}

