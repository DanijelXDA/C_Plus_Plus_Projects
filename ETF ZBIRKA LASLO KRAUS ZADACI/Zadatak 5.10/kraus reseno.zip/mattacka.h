// mattacka.h - Definicija klase materijalnih tacaka.

#include <iostream>
#include <cmath>
using namespace std;

class Mat_tacka {
  double m, x, y, z;                           // Masa i koordinate tacke.
public:
  explicit Mat_tacka(double mm=1, double xx=0, // Stvaranje tacke.
                     double yy=0, double zz=0)
    { m = mm; x = xx; y = yy; z = zz;  }
  double r(const Mat_tacka& mt) const          // Rastojanje do tacke.
    { return sqrt(pow(x-mt.x,2) + pow(y-mt.y,2) + pow(z-mt.z,2)); }
  double F(const Mat_tacka& mt) const          // Privlacna sila.
    { return 6.67e-11 * m * mt.m / pow(r(mt),2); }
  void pisi() const                            // Pisanje tacke.
    { cout << '[' << m << ",(" << x << ',' << y << ',' << z <<")]"; }
};
