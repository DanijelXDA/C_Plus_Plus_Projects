// red2.C - Definicije metoda klase redova ogranicenih kapaciteta.

#include "red2.h"
#include <iostream>
#include <cstdlib>
using namespace std;

Red::Red(int k) {              // Stvaranje praznog reda.
  cout << "Nov red\n";
  niz = new int [kap = k];
  duz = prvi = posl = 0;
}
 
Red::Red(const Red& rd) {      // Stvaranje reda kopiranjem drugog reda.
  cout << "Kopira\n";
  niz = new int [kap = rd.kap];
  for (int i=0; i<kap; i++) niz[i] = rd.niz[i];
  duz = rd.duz; prvi = rd.prvi; posl = rd.posl;
}

Red::Red(Red&& rd) {           // Stvaranje reda premestanjem drugog reda.
  cout << "Premesta\n";
  niz = rd.niz;
  duz = rd.duz; prvi = rd.prvi; posl = rd.posl;
  rd.niz = nullptr;
}

void Red::stavi(int b) {       // Stavljanje broja u red.
  if (duz == kap) exit(1);
  niz[posl++] = b;
  if (posl == kap) posl = 0;
  duz++;
}

int Red::uzmi() {              // Uzimanje broja iz reda.
  if (duz == 0) exit(2);
  int b = niz[prvi++];
  if (prvi == kap) prvi = 0;
  duz--;
  return b;
}

void Red::pisi() const {       // Pisanje sadrzaja reda.
  for (int i=0; i<duz; cout<<niz[(prvi+i++)%kap]<<' ');
}
