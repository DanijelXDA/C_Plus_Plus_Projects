// niz3.h - Klasa nizova apstraktnih predmeta.

#ifndef _niz3_h_
#define _niz3_h_

#include "zbirka.h"
#include "predmet2.h"

namespace Zbirke {
  class Niz: public Zbirka {                    // Polja:
    Predmet** niz;                              // - niz predmeta,
    int duz, kap;                               // - du�ina i kapacitet.
                                                // Pomo�ne metode:
    void kopiraj(const Niz& n);                 // - kopiranje u niz,
    void premesti(Niz& n) {                     // - preme�tanje u niz,
      niz = n.niz; n.niz = nullptr;
      duz = n.duz; kap = n.kap;
    }
    void brisi()                                // - osloba�anje memorije,
      { ~*this; delete[] niz; }
    void povecaj();                             // - pove�avanje kapaciteta.
  public:                                       // Konstruktori:
    explicit Niz(int k=5)                       // - praznog niza,
      { niz = new Predmet* [kap = k]; duz = 0; }
    Niz(const Niz& n) { kopiraj(n); }           // - kopiraju�i,
    Niz(Niz&& n) { premesti(n); }               // - preme�taju�i.
    ~Niz() { brisi(); }                         // Destruktor.
    Niz& operator=(const Niz& n) {              // Dodela vrednosti.
      if (this != &n){ brisi(); Zbirka::operator=(n); kopiraj(n); }
      return *this;
    }
    Niz& operator=(Niz&& n) {                   // Dodela vrednosti.
      if (this != &n){ brisi(); Zbirka::operator=(n); premesti(n); }
      return *this;
    }
    string vrsta() const override { return "Niz"; } // Ime vrste zbirke.
    Niz& operator+=(const Predmet& p) override  // Dodavanje kopiranjem.
      { povecaj(); niz[duz++] = p.kopija(); return *this; }
    Niz& operator+=(Predmet&& p) override       // Dodavanje preme�tanjem.
      { povecaj(); niz[duz++] = move(p).kopija(); return *this; }
    Predmet*& operator[](int i) override {      // Dohvatanje elementa:
      if (i<0 || i>=duz) throw G_indeks();      // - promenljivog niza,
      return niz[i];
    }
    const Predmet* operator[](int i) const override{
      if (i<0 || i>=duz) throw G_indeks();      // - nepromenljivog niza.
      return niz[i];
    }
    int vel() const override { return duz; }    // Du�ina niza.
    Niz& operator~() override;                  // Pra�njenje niza.
    virtual Predmet** begin() override { return niz; }     // Po�etak niza.
    virtual const Predmet*const*const begin() const override { return niz; }
    virtual Predmet** end() override { return niz + duz; } // Kraj niza.
    virtual const Predmet*const*const end() const override
      { return niz + duz; }
  };
} // namespace

#endif

