// linija.C - Stati�ko polje apstraktne klase linija u ravni.

#include "linija.h"

int Linije::Linija::pos_id= 0;
