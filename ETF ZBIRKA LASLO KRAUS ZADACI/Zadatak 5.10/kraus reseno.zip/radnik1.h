// radnik1.h - Klasa radnika.

#ifndef _radnik1_h_
#define _radnik1_h_

#include "proizvod1.h"
#include "masina.h"
#include <iostream>
#include <string>
using namespace std;

namespace Fabrika {
  class G_nema_masinu { // KLASA GRESAKA: Radnik nema masinu.
    string ime; int id; // Ime i identifikator problematicnog radnika.
  public:
    G_nema_masinu(string iime, int iid)           // Inicijalizacija.
      { ime = iime; id = iid; }
    void operator=(const G_nema_masinu&) =delete; // Ne sme da se dodeljuje.
    friend ostream& operator<<(ostream& it, const G_nema_masinu& g) {
      return it << "\n*** Radniku " << g.ime << ", id " << g.id
                << ", nije dodeljena masina ***\n\a";
    }
  }; // class G_nema_masinu

  class Radnik {         // KLASA RADNIKA:
    static int pos_id;   // Poslednji identifikator.
    int id = ++pos_id;   // Identifikator radnika.
    string ime;          // Ime radnika.
    Masina* mas;         // Masina koju radnik koristi (nije joj vlasnik).
    int br;              // Broj napravljenih proizvoda na masini.
  public:
    Radnik(string iime)                      // Inicijalizacija.
      { ime = iime; mas = nullptr; }
    Radnik(const Radnik&) =delete;           // Ne sme da se kopira.
    void operator=(const Radnik&) =delete;   // Ne sme da se dodeljuje.
    string dohv_ime() const { return ime; }  // Dohvatanje imena.
    int dohv_id() const { return id; }       // Dohvatanje identifikatora
    Radnik& operator+=(Masina* m)            // Pridruzivanje masine.
      { mas = m; br = 0; return *this; }
    int broj() const {                       // Broj napravljenih proizvoda.
      if (!mas) throw G_nema_masinu(ime, id);
      return br;
    }
    Proizvod* napravi() {                    // Napravi proizvod.
      if (!mas) throw G_nema_masinu(ime, id);
      br++; return mas->napravi();
    }
    friend ostream& operator<<(ostream& it, const Radnik& r) { // Pisanje.
      it << r.ime << '/' << r.id;
      if (r.mas) it << '(' << r.mas->vrsta() << ',' << r.br << ')';
      return it;
    }
  }; // class Radnik
} // namespace Fabrika

#endif

