// osoba1.h - Definicija klase osoba.

#include "jmbg.h"
#include <string>
#include <iostream>
using namespace std;

class Osoba {
  string ime;                                 // Ime osobe.
  JMBG jmbg;                                  // Jedinstveni maticni broj.
public:
  Osoba(string i, JMBG j): jmbg(j), ime(i) {} // Stvaranje.
  string dohv_ime() const { return ime; }     // Dohvatanje imena.
  JMBG dohv_JMGB() const { return jmbg; }     // Dohvatanje JBMG.
  void pisi() const                           // Pisanje.
    { cout << ime << '('; jmbg.pisi(); cout << ')'; }
};

