// racbroj.C - Metode i funkcije uz klasu racionalnih brojeva.

#include "racbroj.h"
#include <cstdlib>
using namespace std;

namespace Aritmetika {
  Rac_broj::Ceo Rac_broj::nzd(Ceo a, Ceo b) { // Najve�i zajedni�ki delilac.
    while (b != 0) { Ceo c = a % b; a = b; b = c; }
    return a;
  }

  istream& operator>>(istream& ut, Rac_broj& r) {       // �itanje.
    Rac_broj::Ceo a, b = 1; ut >> a;
    if (ut.peek() == '/') { ut.get(); ut >> b; }
    r = Rac_broj(a, b);
    return ut;
  }

  ostream& operator<<(ostream& it, const Rac_broj& r) { // Pisanje.
    it << r.x;
    if (r.y != 1) it << '/' << r.y;
    return it;
  } 
}
