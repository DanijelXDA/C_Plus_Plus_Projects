// trougao4.h - Klasa trouglova u ravni.

#ifndef _trougao4_h_
#define _trougao4_h_

#include "figura1.h"
#include <cmath>
using namespace std;

class Trougao: public Figura {
  Real a, b, c;                                      // Stranice trougla.
public:                                              // Stvaranje trougla:
  Trougao(Real aa=1, const Tacka& tt=ORG)            // - jednakostrani�nog,
    : Figura(tt) { a = b = c = aa; }
  Trougao(Real aa, Real bb, const Tacka& tt=ORG)     // - jednakokrakog,
    : Figura(tt) { a = aa; b = c = bb; }
  Trougao(Real aa, Real bb, Real cc, const Tacka& tt=ORG) // - op�teg.
    : Figura(tt) { a = aa; b = bb; c = cc; }
  Real O() const override { return a + b + c; }      // Obim trougla.
  Real P() const override                            // Povr�ina troug.
    { Real s = (a + b + c) / 2; return sqrt(s*(s-a)*(s-b)*(s-c)); }
  Trougao* kopija() const override                  // Kopija trougla.
    { return new Trougao(*this); }
 private:
  void citaj(istream& ut) override                   // �itanje troug.
    { Figura::citaj(ut); ut >> a >> b >> c; }
  void pisi (ostream& it) const override {           // Pisanje troug.
    it << "trougao ["; Figura::pisi(it);
    it << ", a=" << a << ", b=" << b   << ", c=" << c
       << ", O=" << O() << ", P=" << P() << ']';
  }
};

#endif

