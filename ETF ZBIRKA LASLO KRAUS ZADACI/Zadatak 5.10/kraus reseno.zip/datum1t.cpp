// datum1t.C - Ispitivanje klase kalendarskih datuma.

#include "datum1.h"
#include <iostream>
using namespace std;

int main() {
 cout << "Danasnji datum? "; Datum dat1 = Datum::citaj();
 cout << "Datum rodjenja? "; Datum dat2 = Datum::citaj();
 dat1.pisi();
 cout << " je " << dat1.imeDan() << ", "
                << dat1.danUGod() << ". dan u godini.\n"
      << "Rodili ste se u " << dat2.imeDan() << " i imate "
                            << razlika(dat1,dat2) << " dana.\n";
}
