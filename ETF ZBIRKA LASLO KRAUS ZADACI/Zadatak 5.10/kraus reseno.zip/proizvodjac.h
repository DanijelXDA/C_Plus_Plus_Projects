// proizvodjac.h - Genericka klasa proizvodjaca.

#ifndef _proizvodjac_h_
#define _proizvodjac_h_

#include "akter.h"
#include "skladiste.h"

template <typename T>
class Proizvodjac: public Akter {
  Skladiste<T>* sklad;                           // Odredisno skladiste.
public:
  Proizvodjac(Skladiste<T>* s, double tMin=0,    // Inicijalizacija.
              double tMax=1): Akter(tMin, tMax)
    { sklad = s; }
  void radnja() override {                       // Radnja proizvodjaca.
    cout << *this << ": ";
    try {
      T t = T();
      sklad->stavi(t);
      cout << "stavio " << t << endl;
    } catch (G_puno g) { cout << g << endl; }
  }
};

#endif

