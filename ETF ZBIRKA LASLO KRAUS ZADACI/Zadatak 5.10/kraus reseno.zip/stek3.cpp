// stek3.C - Metode i funkcije uz klasu stekova tacaka pomocu list<>.

#include "stek3.h"

ostream& operator<<(ostream& it, const Stek3& s) {         // Pisanje steka.
  for (list<Tacka>::const_iterator i=s.niz.end();
       i!=s.niz.begin();it <<*--i<<' ');
  return it;
}

