// dodela.h - Klasa dodele vrednosti.

#ifndef _dodela_h_
#define _dodela_h_

#include "izraz.h"
#include "prom.h"

namespace Izrazi {
  class Dodela: public Izraz {
  private:
    Prom* a; Izraz* b;                        // Operandi dodele.
    void pisi(ostream& it) const override     // Pisanje dodele.
      { it << '(' << *a << '=' << *b << ')'; }
    void kopiraj(const Dodela& d)             // Kopiranje u objekat.
      { a = d.a->kopija(); b = d.b->kopija(); }
    void brisi() { delete a; delete b; }      // Osloba�anje memorije.
  public:
    Dodela(const Prom& x, const Izraz& y)     // Inicijalizacija izrazima.
      { a = x.kopija(); b = y.kopija(); }
    Dodela(const Dodela& d) { kopiraj(d); }   // Kopiraju�i konstruktor.
    ~Dodela() { brisi(); }                    // Destruktor.
    Dodela& operator=(const Dodela& d) {      // Kopiraju�a dodela vredn.
      if (this != &d) { brisi(); kopiraj(d); }
      return *this;
    }
    double vredn() const override { return (*a = *b).vredn(); } // Vrednost.
    Dodela* kopija() const override{ return new Dodela (*this); } // Kopija.
  }; // class Dodela
} // namespace Izrazi;

#endif
