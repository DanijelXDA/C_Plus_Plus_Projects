// ceo.h - Klasa celih brojeva.

#ifndef _ceo_h_
#define _ceo_h_

#include "predmet2.h"

namespace Zbirke {
  class Ceo: public Predmet {
    int vr;                                             // Vrednost broja.
    void pisi(ostream& it) const override { it << vr; } // Pisanje broja.
  public:
    Ceo(int v=0) { vr = v; }                   // Konstruktor.
    int vredn() const { return vr; }           // Dohvatanje vrednosti.
    Ceo* kopija() const& override              // Kopija broja kopiranjem.
      { return new Ceo(*this); }
    Ceo* kopija() && override                  // Kopija broja preme�tanjem.
      { return new Ceo(move(*this)); }
  };
} // namespace

#endif

