// voznja.h - Klasa voznji.

#ifndef _voznja_h_
#define _voznja_h_

#include "niz5.h"
#include "etapa.h"
#include <iostream>
using namespace std;

class Voznja {
  Niz<Etapa> etape;                          // Niz etapa voznje.
public:
  explicit Voznja(int k=10): etape(10) {}    // Stvaranje prazne voznje.
  Voznja& operator+=(const Etapa& e){        // Dodavanje etape.
    etape += e;
    return *this;
  }
  float duzina() const;                      // Duzina voznje.
  float trajanje() const;                    // Vreme voznje.
  float srBrzina() const                     // Srednja brzina voznje.
    { return duzina() /  trajanje(); }
  friend ostream& operator<<(ostream& it, const Voznja& v) { // Pisanje.
    return it << "(s=" << v.duzina() << ",t=" << v.trajanje()
              << ",v=" << v.srBrzina() << ')';
  }
};

#endif

