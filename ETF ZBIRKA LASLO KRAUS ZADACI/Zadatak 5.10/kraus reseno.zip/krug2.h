// krug2.h - Klasa krugova u ravni.

#ifndef _krug2_h_
#define _krug2_h_

#include "figura1.h"

const Real PI = 3.1415926535897932;

class Krug: public Figura {
  Real r;                                            // Polupre�nik kruga.
public:
  Krug(Real rr=1, const Tacka& tt=ORG)               // Konstruktor.
    : Figura(tt) { r = rr; }
  Real O() const override { return 2 * r * PI; }     // Obim kruga.
  Real P() const override { return r * r * PI; }     // Povr�ina kruga.
  Krug* kopija() const override                      // Kopija kruga.
    { return new Krug(*this); }
private:
  void citaj(istream& ut) override                   // �itanje kruga.
    { Figura::citaj(ut); ut >> r; }
 
  void pisi (ostream& it) const override {           // Pisanje kruga.
    it << "krug    ["; Figura::pisi(it);
    it << ", r=" << r << ", O=" << O() << ", P=" << P() << ']';
  }
};

#endif

