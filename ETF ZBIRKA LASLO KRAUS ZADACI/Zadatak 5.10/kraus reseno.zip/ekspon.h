// ekspon.h - Klasa eksponencijalnih funkcija.

#ifndef _ekspon_h_
#define _ekspon_h_

#include "fun3.h"
#include <cmath>
#include <utility>
using namespace std;

namespace Izvodi {
  class Ekspon: public Fun {
    double a, b;                          // Parametri ekspon. funkcije.
    void pisi(ostream& it) const override // Pisanje ekspon. funkcije.
      { it << a << "*exp(" << b << "*x)"; }
  public:
    Ekspon(double aa=1, double bb=1)           // Stvaranje ekspon. funkc.
      { a = aa; b = bb; }
    double operator()(double x) const override // Vrednost ekspon. funkcije.
      { return a * exp(b*x); }
    Delegat izvod() const override             // Izvod ekspon. funkcije.
      { return Delegat(new Ekspon(a*b, b)); }
    Ekspon* kopija() const& override  // Kopija ekspon. funk. kopiranjem.
      { return new Ekspon(*this); }
    Ekspon* kopija() && override      // Kopija ekspon. funkc. preme�tanjem.
      { return new Ekspon(move(*this)); }
  }; // class Ekspon
} // namespace Izvodi

#endif

