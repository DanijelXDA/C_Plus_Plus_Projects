// imenik2.h - Klasa imenika osoba.

#ifndef _imenik2_h_
#define _imenik2_h_

#include "osoba2.h"
#include <cstdlib>
#include <iostream>
using namespace std;

class Imenik {
  Osoba** ljudi;                            // Niz osoba.
  int kap, n;                               // Kapacitet niza i broj osoba.
public:
  explicit Imenik(int k=10) {               // Stvaranje imenika.
    ljudi = new Osoba* [kap = k];
    n = 0;
  }
  Imenik(const Imenik&) =delete;            // Ne sme da se kopira.
  Imenik& operator=(const Imenik&) =delete; // Ne sme da se dodeljuje.
  ~Imenik();                                // Unistavanje imenika.
  Imenik& operator+=(Osoba* oso) {          // Dodavanje osobe.
    if (n == kap) exit(2);
    ljudi[n++] = oso;
    return *this;
  }
  int kapac() const { return kap; }         // Kapacitet imenika.
  int vel() const { return n; }             // Broj osoba u imeniku.
  Imenik& uredi();                          // Uredjivanje imenika.
  friend ostream& operator<<(ostream& it, const Imenik& imen); // Pisanje.
};

#endif

