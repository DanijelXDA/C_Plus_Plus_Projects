// sklop.C - Metode klase sklopova predmeta.

#include "sklop.h"

namespace Predmeti {
  void Sklop::kopiraj(const Sklop& s) {      // Kopiranje u sklop.
    for (unsigned i=0; i<s.niz.size(); i++)
      niz.push_back(s.niz[i]->kopija());
  }

  void Sklop::brisi() {                      // Osloba�anje memorije.
    for (unsigned i=0; i<niz.size(); delete niz[i++]);
    niz.clear();
  }

  void Sklop::pisi(ostream& it) const {      // Pisanje.
    Predmet::pisi(it); it << '[' << endl; nivo++;
    for (unsigned i=0; i<niz.size();it <<*niz[i++]<<endl);
    --nivo; it << setw(2*nivo+1) << ']';
  }

  double Sklop::V() const {                  // Zapremina sklopa.
    double v = 0;
    for (unsigned i=0; i<niz.size(); v+=niz[i++]->V());
    return v;
  }

  double Sklop::Q() const {                  // Te�ina sklopa.
    double q = 0;
    for (unsigned i=0; i<niz.size(); q+=niz[i++]->Q());
    return q;
  }
} // namespace Predmeti

