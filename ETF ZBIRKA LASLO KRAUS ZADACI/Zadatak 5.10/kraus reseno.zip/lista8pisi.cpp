// lista8pisi.C - Prikazivanje sadrzaja liste iz relativne datoteke.

#include "rfile.h"
#include <iostream>
#include <iomanip>
using namespace std;

struct Zapis { int sif; char txt[50]; unsigned nar; };

int main() {
  try {
    RFile dat("lista8.dat");
    Zapis zap;
    dat.read(&zap, 1);
    while (zap.nar) {
      dat.read(&zap, zap.nar);
      cout << setw(5) << zap.sif << "   " << zap.txt << endl;
    }
  } catch (RFile::Greska g) { cout << g; }
}

