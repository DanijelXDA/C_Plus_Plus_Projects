// tacka7.h - Klasa ta�aka u prostoru.

#ifndef _tacka7_h_
#define _tacka7_h_

#include "figura2.h"
#include "vektor3.h"

class Tacka: public Figura {
  Vektor p;                                          // Vektor polo�aja.
  void pisi(ostream& it) const override              // Pisanje ta�ke.
    { it << 'T' << p; }
public:
  Tacka(const Vektor& v=Vektor()): p(v) {}           // Stvaranje ta�ke.
  Tacka* kopija() const override                     // Kopija ta�ke.
    { return new Tacka(*this); }
  Tacka& operator+=(const Vektor& v) override        // Pomeranje ta�ke.
    { p += v; return *this; }
  Vektor teziste() const override { return p; }      // Te�iste ta�ke.
};

#endif

