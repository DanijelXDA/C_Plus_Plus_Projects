// uredjaj.h - Klasa elektri�nih ure�aja.

#ifndef _uredjaj_h_
#define _uredjaj_h_

#include "potrosac1.h"
#include <iostream>
#include <string>
#include <utility>
using namespace std;

namespace Potrosaci {
  class Uredjaj: public Potrosac {
    string naz;                                    // Naziv ure�aja.
    double sna;                                    // Snaga ure�aja.
    void pisi(ostream&it) const override           // Pisanje ure�aja.
      { it << naz << '(' << sna << ')'; }
  public:
    Uredjaj(string n, double s): naz(n), sna(s) {} // Inicijalizacija.
    double snaga() const override { return sna; }  // Snaga ure�aja.
    Uredjaj* kopija() const& override    // Kopija potro�a�a kopiranjem.
      {return new Uredjaj(*this);}
    Uredjaj* kopija() && override        // Kopija potro�a�a preme�tanjem.
      {return new Uredjaj(*this);}
  }; // class
} // namespace

#endif
