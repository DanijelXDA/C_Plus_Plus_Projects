// lokomot1.h - Klasa lokomotiva.

#ifndef _lokomot1_h_
#define _lokomot1_h_

#include "vozilo2.h"
#include <iostream>
#include <utility>
using namespace std;

namespace Vozovi1 {
  class Lokomot: public Vozilo {
    float v_sila;                         // Vu�na sila lokomotive.
    void pisi(ostream& it) const override // Pisanje lokomotive.
      { Vozilo::pisi(it); it << '(' << v_sila << ')'; }
  public:
    static const char VR = 'L';           // Oznaka za lokomotive.
    Lokomot(float sop_tez, float vs): Vozilo(sop_tez)    // Konstruktor.
      { v_sila = vs; }
    char vrsta() const override { return VR; }           // Oznaka vrste.
    float uk_tezina() const override                     // Ukupna te�ina.
      { return sop_tezina(); }
    float vucna_sila() const& { return v_sila; }         // Vu�na sila.
    Lokomot* kopija() const& override     // Kopija lokomotive kopiranjem.
      {return new Lokomot(*this);}
    Lokomot* kopija() && override         // Kopija lokomotive preme�tanjem.
      {return new Lokomot(move(*this));}
  }; // class
} // namespace

#endif

