// skolat.C - Ispitivanje klasa za obradu skola.

#include "djak.h"
#include "skola.h"
#include <iostream>
using namespace std;

int main() {
  Skola sk("ETF, Beograd");
  Djak marko("Marko", Datum(12,5,1992));
  Djak zoran("Zoran", Datum(31,7,1990));
  sk += marko; sk += zoran;
  marko += new Ispit('a', 10, Datum(12, 6,2006));
  marko += new Ispit('b',  7, Datum(24, 6,2006));
  marko += new Ispit('c',  5, Datum( 1, 7,2006));
  zoran += new Ispit('c',  9, Datum( 1, 7,2006));
  zoran += new Ispit('a', 10, Datum(12, 6,2006));
  zoran += new Ispit('d',  7, Datum(20, 6,2006));
  cout << *sk.najbolji() << '\n';
}

