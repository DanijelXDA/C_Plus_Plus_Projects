// potrosac2.h - Genericka klasa potrosaca.

#ifndef _potrosac2_h_
#define _potrosac2_h_

#include "akter.h"
#include "skladiste.h"

template <typename T>
class Potrosac: public Akter {
  Skladiste<T>* sklad;                           // Izvorisno skladiste.
public:
  Potrosac(Skladiste<T>* s, double tMin=0,       // Inicijalizacija.
           double tMax=1): Akter(tMin, tMax)
    { sklad = s; }
  void radnja() override {                       // Radnja potrosaca.
    cout << *this << ": ";
    try { cout << "uzeo " << sklad->uzmi() << endl; }
      catch (G_prazno g) { cout << g << endl; }
  }
};

#endif

