// grupa.C - Metode klase grupa elektri�nih potro�a�a.

#include "grupa.h"

namespace Potrosaci {
  void Grupa::kopiraj(const Grupa& g) {    // Kopiranje u grupu.
    prvi = posl = nullptr;
    for (Elem* tek=g.prvi; tek; tek=tek->sled) {
      Elem* novi = new Elem(tek->potr->kopija());
      posl = (!prvi ? prvi : posl->sled) = novi;
    }
    sna = g.sna;
  }

  void Grupa::brisi() {                    // Osloba�anje memorije.
    while (prvi) { Elem* stari = prvi; prvi = prvi->sled; delete stari; }
    posl = nullptr;
  }

  void Grupa::pisi(ostream& it) const {    // Pisanje grupe.
    it << '[';
    for (Elem* tek=prvi; tek; tek=tek->sled)
      { it << *tek->potr; if (tek->sled) it << ','; }
    it << ']';
  }
} // namespace

