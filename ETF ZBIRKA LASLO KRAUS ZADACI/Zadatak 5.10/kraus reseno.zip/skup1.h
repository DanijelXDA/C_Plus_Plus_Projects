// skup1.h - Definicija klase uredjenih skupova.

class Skup {
  int vel; double* niz;                   // Velicina i elementi skupa.
  void kopiraj(const Skup&);              // Kopiranje u skup.
  void premesti(Skup& s)                  // Premestanje u skup.
    { vel = s.vel; niz = s.niz; s.niz = nullptr; }
  void brisi()                            // Oslobadjanje memorije.
    { delete [] niz; niz = nullptr; vel = 0; }
public:
  Skup() { niz = nullptr; vel = 0; }      // Stvaranje praznog skupa.
  Skup(double a) {                        // Konverzija broja u skup.
    niz = new double [vel = 1];
    niz[0] = a;
  }
  Skup(const Skup& s) { kopiraj(s); }     // Inicijalizacija kopiranjem.
  Skup(Skup&& s) { premesti(s); }         // Inicijalizacija premestanjem.
  ~Skup() { brisi(); }                    // Unistavanje skupa.
  void unija  (const Skup&, const Skup&); // Unija dva skupa.
  void presek (const Skup&, const Skup&); // Presek dva skupa.
  void razlika(const Skup&, const Skup&); // Razlika dva skupa.
  void pisi () const;                     // Pisanje skupa.
  void citaj();                           // Citanje skupa.
  int velicina() const { return vel; }    // Velicina skupa.
};

