// sef.C - Metoda klase sefova.

#include "sef.h"

double Trgovina::Sef::prihod() const {        // Ostvareni prihod.
  double p = 0;
  for (int i=0; i<br_pot; p+=podredjeni[i++]->prihod());
  return p;
}

