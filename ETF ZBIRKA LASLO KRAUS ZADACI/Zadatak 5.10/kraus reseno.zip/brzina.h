// brzina.h - Klasa brzina.

#ifndef _brzina_h_
#define _brzina_h_

#include "vektor1.h"

class Brzina: public Vektor {
  void pisi(ostream& it) const { it << 'v'; Vektor::pisi(it); } // Pisanje.
public:
  Brzina(): Vektor() {}                                    // Konstruktori.
  Brzina(double x, double y, double z): Vektor(x, y, z) {}
};

#endif
