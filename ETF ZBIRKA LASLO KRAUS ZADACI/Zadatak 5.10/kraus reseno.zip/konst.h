// konst.h - Klasa konstanti.

#ifndef _konst_h_
#define _konst_h_

#include "izraz.h"

namespace Izrazi {
  class Konst: public Izraz {
    double vr;                                 // Vrednost konstante.
    void pisi(ostream& it) const override { it << vr; } // Pisanje konst.
    void operator=(const Konst&) {}            // Ne sme da se menja.
  public:
    Konst(double v=0) { vr = v; }              // Stvaranje konstante.
    double vredn() const { return vr; }        // Vrednost konstante.
    Konst* kopija() const override             // Kopija konstante.
      { return new Konst(*this); }
  }; // class Konst
} // namespace Izrazi

#endif
