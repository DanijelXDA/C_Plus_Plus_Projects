// figura2.h - Apstraktna klasa figura u prostoru.

#ifndef _figura2_h_
#define _figura2_h_

#include "vektor3.h"
#include <iostream>
using namespace std;

class Figura {
public:
  virtual ~Figura() {}                            // Virt. destruktor.
  virtual Figura* kopija() const =0;              // Kopija figure.
  virtual Figura& operator+=(const Vektor& v) =0; // Pomeranje figure.
  virtual Vektor  teziste() const =0;             // Te�iste figure.
private:
  virtual void pisi(ostream& it) const =0;        // Pisanje figure.
  friend ostream& operator<<(ostream& it, const Figura& f)
    { f.pisi(it); return it; }
};

#endif

