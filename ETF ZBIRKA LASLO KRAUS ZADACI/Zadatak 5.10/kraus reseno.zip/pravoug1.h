// pravoug1.h - Deklaracije paketa za obradu pravougaonika u ravni.

#include "tacka1.h"
#include <iostream>
#include <cmath>
using namespace std;

namespace Geometr {
  struct Pravoug { Tacka A, C; };

  inline void pravi(Pravoug& p, Tacka A=ORG, Tacka C=JED)
    { p.A = A; p.C = C; }

  inline void pravi(Pravoug& p, double xA, double yA, double xC, double yC)
    { pravi(p.A, xA, yA); pravi(p.C, xC,yC); }

  inline void citaj(Pravoug& p) { citaj(p.A); citaj(p.C); }

  inline void pisi(const Pravoug& p)
    { cout << '['; pisi(p.A); cout <<','; pisi(p.C); cout << ']'; }

  inline double P(const Pravoug& p)
    { return fabs(p.A.x-p.C.x) * fabs(p.A.y-p.C.y); }
}
