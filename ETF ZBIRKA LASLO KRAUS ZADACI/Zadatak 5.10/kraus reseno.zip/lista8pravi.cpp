// lista8pravi.C - Obrazovanje uredjene liste u relativnoj datoteci.

#include "rfile.h"
#include <iostream>
#include <iomanip>
using namespace std;

struct Zapis { int sif; char txt[50]; unsigned nar; };
 
int main() {
  try {
    RFile dat("lista8.dat", sizeof(Zapis));
    Zapis zap; zap.sif = zap.txt[0] = zap.nar = 0;     // Glava liste.
    dat.write(&zap, 1);
    ifstream pod("lista8.pod");       // Tekstualna datoteka s podacima.
    while (pod >> zap.sif >> zap.txt) {
      cout << setw(5) << zap.sif << "   " << zap.txt << endl;
      unsigned nov = dat.recn() + 1; dat.write(&zap, nov);
      int sif = zap.sif;
      dat.read(&zap, 1); unsigned pre = 1, tek = zap.nar;
      while(tek && (dat.read(&zap,tek), zap.sif<sif))
        { pre = tek; tek = zap.nar; }
      dat.read(&zap, pre); zap.nar = nov; dat.write(&zap, pre);
      dat.read(&zap, nov); zap.nar = tek; dat.write(&zap, nov);
    }
  } catch (RFile::Greska g) { cout << g; }
}

