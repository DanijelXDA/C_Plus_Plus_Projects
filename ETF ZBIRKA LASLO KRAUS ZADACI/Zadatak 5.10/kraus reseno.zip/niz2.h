// niz2.h - Klasa nizova apstraktnih podataka.

#ifndef _niz2_h_
#define _niz2_h_

#include "podatak.h"
#include "niz2gr.h"
#include <utility>
using namespace std;

class Niz: public Podatak {   // Polja:
  Podatak** niz;              // - niz pokaziva�a na podatke,
  int kap;                    // - kapacitet niza.
                                              // Pomo�ne metode:
  void kopiraj(const Niz& n);                 // - kopiranje u niz,
  void premesti(Niz& n)                       // - preme�tanje u niz,
    { niz = n.niz; kap = n.kap; n.niz = nullptr; }
  void brisi() { ~*this; delete [] niz; }     // - osloba�anje memorije,
  int prazno() const;                         // - nala�enje praznog mesta,
  void pisi(ostream& it) const override;      // - pisanje niza.
public:                                       // Konstruktori:
  explicit Niz(int kk=10);                    // - praznog niza,
  Niz(const Niz& nn) { kopiraj(nn); }         // - kopiraju�i,
  Niz(Niz&& nn) { premesti(nn); }             // - preme�taju�i.
  ~Niz() { brisi(); }                         // Destruktor.
  Niz& operator=(const Niz& n) {              // Dodela vrednosti.
    if (this != &n) { brisi(); kopiraj(n); }  // - kopiranjem,
    return *this;
  }
  Niz& operator=(Niz&& n) {                   // - preme�tanjem.
    if (this != &n) { brisi(); premesti(n); }
    return *this;
  }
  Niz* kopija() const& override            // Kopija niza kopiranjem.
    { return new Niz(*this); }
  Niz* kopija() && override                // Kopija niza preme�tanjem.
    { return new Niz(move(*this)); }
  int kapac() const { return kap; }        // Kapacitet niza.
                                           // Pristup komponenti:
  Podatak& operator[](int ind) {           // - promenljivog niza,
    if (ind < 0 || ind >= kap) throw G_indeks(ind, kap);
    if (niz[ind] == nullptr)   throw G_prazno();
    return *niz[ind];
  }
  const Podatak& operator[](int ind) const // - nepromenljivog niza.
    { return const_cast<Niz&>(*this)[ind]; }
  Niz& operator+=(const Podatak& p)        // Umetanje podatka kopiranjem.
    { niz[prazno()] = p.kopija(); return *this; }
  Niz& operator+=(Podatak&& p)             // Umetanje podatka preme�tanjem.
    { niz[prazno()] = move(p).kopija(); return *this; }
  Niz& operator-=(int ind) {               // Izbacivanje podatka.
    if (ind < 0 || ind >= kap) throw G_indeks(ind, kap);
    delete niz[ind]; niz[ind] = nullptr;
    return *this;
  }
  Niz& operator~();                        // Pra�njenje niza.
};

#endif

