// mnogougao1.h - Klasa mnogouglova u prostoru.

#ifndef _mnogougao1_h_
#define _mnogougao1_h_

#include "figura2.h"
#include "vektor3.h"
#include <iostream>
using namespace std;

class G_indeks {}; // Klasa gre�aka: Nedozvoljen indeks.
inline ostream& operator<<(ostream& it, const G_indeks&)
  { return it << "*** Nedozvoljen indeks! ***"; }
class Mnogougao: public Figura {
  Vektor* niz;                                  // Temena mnogougla.
  int     n;                                    // Broj temena.
  void pisi(ostream& it) const;                 // Pisanje mnogougla.
  void kopiraj(const Mnogougao& m);             // Kopiranje u mnogougao.
  void premesti(Mnogougao& m)                   // Preme�tanje u mnogougao.
    { niz = m.niz; n = m.n; m.niz = nullptr; }
  void brisi() { delete [] niz; }               // Osloba�anje memorije.
public:
  explicit Mnogougao(int k=3)                   // Stvaranje mnogougla.
    { niz = new Vektor [n = k]; }
  Mnogougao(const Mnogougao& m) { kopiraj(m); } // Kopiraju�i konstruktor.
  Mnogougao(Mnogougao&& m) { premesti(m); }     // Preme�taju�i konstruktor.
  ~Mnogougao() { delete [] niz; }               // Uni�tavanje mnogougla.
  Mnogougao& operator=(const Mnogougao& m) {    // Kopiraju�a dodela
    if (this != &m) { brisi(); kopiraj(m); }    //   vrednosti.
    return *this;
  }
  Mnogougao& operator=(Mnogougao&& m) {         // Preme�taju�a dodela
    if (this != &m) { brisi(); premesti(m); }   //   vrednosti.
    return *this;
  }
  Mnogougao* kopija() const                     // Kopija mnogougla
    { return new Mnogougao(*this); }
  Mnogougao& operator+=(const Vektor& v);       // Pomeranje mnogougla.
  Vektor teziste() const;                       // Te�i�te.
  Vektor& operator[](int i) {                   // Pristupanje temenu:
    if (i<0 || i>=n) throw G_indeks();          // - promenljivog
    return niz[i];                              //   mnogougla,
  }
  const Vektor& operator[](int i) const {       // - nepromenljivog objekta.
    if (i<0 || i>=n) throw G_indeks();          //   mnogougla.
    return niz[i];
  }
};

#endif

