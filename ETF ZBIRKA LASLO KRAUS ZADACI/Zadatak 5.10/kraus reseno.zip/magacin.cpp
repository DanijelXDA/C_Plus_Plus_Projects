// magacin.C - Obrada relativne binarne datoteke.

#include <fstream>
#include <iostream>
#include <iomanip>
using namespace std;

int main() {
  struct Zapis { char naziv[30]; float kolicina, cena; };
  Zapis zapis;
  float ukupno=0, promena; int sifra, duzina = sizeof zapis;
  fstream datot("magacin.dat", ios::in | ios::out | ios::binary);
  ifstream prom("promene.txt");
  while (prom >> sifra >> promena) {
    datot.seekg((long)(sifra-1)*duzina);
    datot.read((char*)&zapis, duzina);
    zapis.kolicina += promena;
    ukupno += zapis.cena * promena;
    datot.seekp(-(long)duzina, ios::cur);
    datot.write((char*)&zapis, duzina);
  }
  cout << "Ukupna promena vrednosti robe je "
       << setprecision(2) << fixed << ukupno << endl;
}

