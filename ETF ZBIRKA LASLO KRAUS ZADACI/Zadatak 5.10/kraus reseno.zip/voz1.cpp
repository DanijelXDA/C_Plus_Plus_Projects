// voz1.C - Metode i funkcije uz klasu vozova.

#include "voz1.h"
#include <utility>
using namespace std;

namespace Vozovi1 {
  void Voz::kopiraj(const Voz& v) {           // Kopiranje u objekat.
    ime = v.ime;
    prvi = posl = nullptr;
    for (Elem* tek=v.prvi; tek; tek=tek->sled) {
      Elem* novi = new Elem(tek->vozilo->kopija());
      posl = (!prvi ? prvi : prvi->sled) = novi;
    }
  }

  void Voz::brisi() {                         // Osloba�anje memorije.
    while (prvi)
      {Elem* stari=prvi; prvi=prvi->sled; delete stari;}
    posl = nullptr;
  }

  Voz& Voz::operator+=(const Lokomot& lok) {  // Dodavanje lokomotive
    if (prvi) throw G_ima_lok();              //   kopiranjem.
    posl = prvi = new Elem(lok.kopija());
    return *this;
  }

  Voz& Voz::operator+=(Lokomot&& lok) {       // Dodavanje lokomotive
    if (prvi) throw G_ima_lok();              //   preme�tanjem.
    posl = prvi = new Elem(move(lok).kopija());
    return *this;
  }

  Voz& Voz::operator+=(const P_vagon& pvag) { // Dodavanje putn. vagona
    if (!prvi) throw G_nema_lok();            //   kopiranjem.
    if (uk_tez_voza()+pvag.uk_tezina() >
        ((Lokomot*)prvi->vozilo)->vucna_sila()) throw G_tezak_voz();
    posl = posl->sled = new Elem(pvag.kopija());
    return *this;
  }
  
  Voz& Voz::operator+=(P_vagon&& pvag) {      // Dodavanje putn. vagona
    if (!prvi) throw G_nema_lok();            //   preme�tanjem.
    if (uk_tez_voza()+pvag.uk_tezina() >
        ((Lokomot*)prvi->vozilo)->vucna_sila()) throw G_tezak_voz();
    posl = posl->sled = new Elem(move(pvag).kopija());
    return *this;
  }

  float Voz::uk_tez_voza() const {            // Ukupna te�ina voza.
    float t = 0;
    for (Elem* tek=prvi; tek; tek=tek->sled)
      t += tek->vozilo->uk_tezina();
    return t;
  }
 
  ostream& operator<<(ostream& it, const Voz& v) { // Pisanje voza.
    it << v.ime << '(' << v.uk_tez_voza() << ','
       << P_vagon::dohv_sr_tez_put() << ')' << endl;
    for (Voz::Elem* tek=v.prvi; tek; tek=tek->sled)
      it << *tek->vozilo << endl;
    return it;
  }
} // namespace

