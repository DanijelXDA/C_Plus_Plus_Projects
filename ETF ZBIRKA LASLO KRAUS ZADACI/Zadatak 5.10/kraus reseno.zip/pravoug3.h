// pravoug3.h - Klasa obojenih pravougaonika u ravni.

#ifndef _pravoug3_h_
#define _pravoug3_h_

#include "figura3.h"
#include <utility>
using namespace std;

namespace Figure {
  class Pravoug: public Figura {
  protected:
    Tacka A;                           // Donje levo teme.
    double sir, vis;                   // �irina i visina.
  public:                              // Konstruktor.
    explicit Pravoug(Tacka P=Tacka(), double s=1, double v=1, Boja b=Boja())
      : Figura(b), A(P), sir(s), vis(v) {}
    Pravoug* kopija() const& override  // Kopija pravougaonika kopiranjem.
      { return new Pravoug(*this); }
    Pravoug* kopija() && override      // Kopija pravougaonika preme�tanjem.
      { return new Pravoug(move(*this)); }
    bool pripada(const Tacka& T) const override { // Da li ta�ka pripada?
      return A.x()<=T.x() && T.x()<=A.x()+sir &&
             A.y()<=T.y() && T.y()<=A.y()+vis;
    }
  }; // class Pravoug
} // namespace Figure

#endif

