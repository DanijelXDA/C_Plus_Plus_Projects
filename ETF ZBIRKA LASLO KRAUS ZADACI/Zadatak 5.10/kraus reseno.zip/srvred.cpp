// srvred.C - Srednja vrednost brojeva u zapisima tekstualne datoteke.

#include <fstream>
#include <iostream>
using namespace std;

int main() {
  ifstream ul ("srvred.pod");
  ofstream izl("srvred.rez");
  double z = 0;
  while (true) {
    int n; ul >> n;
  if (!ul) break;
    double* a = new double [n];
    double s = 0;
    for (int i=0; i<n; i++) { ul >> a[i]; s += a[i]; }
    if (n) s /= n;
    z += s;
    if (s > 0) {
      izl << n;
      for (int i=0; i<n; izl << ' ' << a[i++]);
      izl.put('\n');
    }
    delete [] a;
  }
  cout << "Zbir srednjih vrednosti= " << z << endl;
}

