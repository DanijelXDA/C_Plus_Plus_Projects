// crtez2.h - Klasa crte�a.

#ifndef _crtez2_h_
#define _crtez2_h_

#include "figura4.h"
#include "niz7.h"
#include <iostream>
#include <utility>
using namespace std;

class Crtez: public Figura {
  Niz<Figura> niz;                                       // Niz figura.
  void pisi(ostream& it) const override { it << niz; }   // Pisanje crte�a.
public:
  explicit Crtez(int kap): niz(kap) {}    // Stvaranje praznog crte�a.
  Crtez& operator+=(const Figura& f)      // Dodavanje figure kopiranjem.
    { niz += f; return *this;}
  Crtez& operator+=(Figura&& f)           // Dodavanje figure preme�tanjem.
    { niz += move(f); return *this;}
  Crtez& operator+=(const Vektor& v);     // Pomeranje crte�a.
  Crtez* kopija() const& override         // Kopija crte�a kopiranjem.
    { return new Crtez(*this); }
  Crtez* kopija() && override             // Kopija crte�a preme�tanjem.
    { return new Crtez(move(*this)); }
};

#endif

