// nizmtac.C - Definicije metoda klase nizova materijalnih tacaka.

#include "nizmtac.h"
#include <iostream>
using namespace std;

Niz_mat_tac::Niz_mat_tac(const Niz_mat_tac& nmt) {// Kopirajuci konstruktor.
  niz = new Mat_tacka [kap = nmt.kap];
  duz = nmt.duz;
  for (int i=0; i<duz; i++) niz[i] = nmt.niz[i];
}

Niz_mat_tac& Niz_mat_tac::dodaj(const Mat_tacka& mt) { // Dodavanje tacke.
  if (duz == kap) {
    Mat_tacka* pom = new Mat_tacka [kap += 5];
    for (int i=0; i<duz; i++) pom[i] = niz[i];
    delete [] niz; niz = pom;
  }
  niz[duz++] = mt;
  return *this;
}

Mat_tacka Niz_mat_tac::max_F(const Mat_tacka& mt) const { // Najjaca tacka.
  double max = mt.F(niz[0]);
  int ind = 0;
  for (int i=1; i<duz; i++) {
    double F = mt.F(niz[i]);
    if (F > max) { max = F; ind = i; }
  }
  return niz[ind];
}

void Niz_mat_tac::pisi() const {                          // Pisanje niza.
  for (int i=0; i<duz; i++) { niz[i].pisi(); cout << endl; }
}
