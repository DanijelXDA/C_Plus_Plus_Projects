// voznja.C - Metode klase voznji.

#include "voznja.h"

float Voznja::duzina() const {               // Duzina voznje.
  float d = 0;
  for (int i=0; i<etape.duzina(); d+=etape[i++].duzina());
  return d;
}

float Voznja::trajanje() const{              // Vreme voznje.
  float t = 0;
  for (int i=0; i<etape.duzina(); t+=etape[i++].vreme());
  return t;
}

