// djak.C - Metode klase djaka.

#include "djak.h"

Djak::~Djak() {                            // Destruktor.
  for (ispiti.naPrvi(); ispiti.imaTek(); ispiti.naSled())
    delete ispiti.dohvTek();
}

double Djak::srOce() const {               // Srednja ocena.
  double s = 0; int n = 0;
  for (ispiti.naPrvi(); ispiti.imaTek(); ispiti.naSled()) {
    int k = ispiti.dohvTek()->dohvOce();
    if (k > 5) { s += k; n++; }
  }
  return n ? s/n : 0;
}

