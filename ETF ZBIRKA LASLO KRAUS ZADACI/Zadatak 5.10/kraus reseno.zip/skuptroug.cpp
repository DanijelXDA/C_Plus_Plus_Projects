// skuptroug.C - Metode i funkcije uz klasu trouglova u ravni.

#include "skuptroug.h"

void Skup_troug::kopiraj(const Skup_troug& s) { // Kopiranje u objekat.
  prvi = posl = nullptr;
  for (Elem* tek=s.prvi; tek; tek=tek->sled)
    posl = (!prvi ? prvi : posl->sled) = new Elem(tek->t);
}

void Skup_troug::brisi() {                      // Brisanje objekta.
  while (prvi) { Elem* stari = prvi; prvi = prvi->sled; delete stari; }
  posl = nullptr;
}

bool Skup_troug::ima(const Trougao& t) const {  // Da li postoji u skupu?
  for (Elem* tek=prvi; tek; tek=tek->sled)
    if (tek->t == t) return true;
  return false;
}

Skup_troug& Skup_troug::operator+=(const Trougao& t){ // Dodavanje trougla.
  if (!ima(t)) posl = (!prvi ? prvi : posl->sled) = new Elem(t);
  return *this;
}

double Skup_troug::ukP() const {               // Ukupna povrsina trouglova.
  double p = 0;
  for (Elem* tek=prvi; tek; tek=tek->sled) p += tek->t.P();
  return p;
}

ostream& operator<<(ostream& it, const Skup_troug& s) { // Pisanje.
  it << '{';
  for (Skup_troug::Elem* tek=s.prvi; tek; tek=tek->sled) {
    it << tek->t;
    if (tek->sled) it << ',';
  }
  return it << '}';
}

