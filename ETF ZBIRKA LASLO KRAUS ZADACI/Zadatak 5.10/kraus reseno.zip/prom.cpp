// prom.C - Stati�ko polje i metode klase promenljivih.

#include "prom.h"

Izrazi::Prom::Elem* Izrazi::Prom::prvi = nullptr;// Lista svih promenljivih.

void Izrazi::Prom::pravi(string ime, double vr) {// Stvaranje promenljive.
  Elem *tek = prvi, *pret = nullptr;
  while (tek && tek->ime<ime)
    { pret = tek; tek = tek->sled; }
  if (tek && tek->ime==ime) { // Ime ve� postoji.
    ovaj = tek; ovaj->br_kor++;
  } else {                    // Novo ime.
    Elem* novi = new Elem(ime, vr, pret, tek);
    if (tek) tek->pret = novi;
    (!pret ? prvi : pret->sled) = novi;
    ovaj = novi;
  }
}

void Izrazi::Prom::pisiSve(ostream& it) {
  for (Elem* tek=prvi; tek; tek=tek->sled)
    it << tek->ime << ' ';
  it << endl;
}
