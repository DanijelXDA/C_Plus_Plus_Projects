// kvadar2.C - Staticko polje klase numerisanih kvadara.

#include "kvadar2.h"

int Kvadar::pos_id = 0;
