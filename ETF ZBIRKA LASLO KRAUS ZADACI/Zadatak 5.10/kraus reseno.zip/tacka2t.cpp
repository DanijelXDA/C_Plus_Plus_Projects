// tacka2t.C - Ispitivanje klase tacaka u ravni.

#include "tacka2.h"
#include <iostream>
using namespace std;

int main() {
  cout << "t1? "; double x, y; cin >> x >> y;
  Tacka t1; t1.postavi(x, y);
  cout << "t2? "; Tacka t2; t2.citaj();
  cout << "t1=(" << t1.aps() << ',' << t1.ord()
       << "), t2="; t2.pisi(); cout << endl;
  cout << "Rastojanje=" << t1.rastojanje(t2) << endl;
}
