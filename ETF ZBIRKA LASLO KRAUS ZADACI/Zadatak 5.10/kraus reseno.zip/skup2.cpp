// skup2.C - Metode i funkcije uz klasu skupova apstraktnih objekata.

#include "skup2.h"

void Skup::kopiraj(const Skup& s) {                  // Kopiranje u objekat.
  prvi = posl = nullptr;
  for (Elem* tek=s.prvi; tek; tek=tek->sled) dodaj(*tek->obj);
}

void Skup::brisi() {                                 // Unistavanje.
  while (prvi) { Elem* stari = prvi; prvi = prvi->sled; delete stari; }
  posl = nullptr;
}

bool Skup::operator%(const Obj& obj) const {         // Element skupa?
  for (Elem* tek=prvi; tek; tek=tek->sled)
    if (*tek->obj == obj) return true;
  return false;
}

Skup operator-(const Skup& s1, const Skup& s2) {     // Razlika dva skupa.
  Skup s;
  for (Skup::Elem* tek=s1.prvi; tek; tek=tek->sled)
    if (!(s2 % *tek->obj)) s.dodaj(*tek->obj);
  return s;
}

Skup operator*(const Skup& s1, const Skup& s2) {     // Presek dva skupa.
  Skup s;
  for (Skup::Elem* tek=s1.prvi; tek; tek=tek->sled)
    if (s2 % *tek->obj) s.dodaj(*tek->obj);
  return s;
}
 
Skup& Skup::operator+=(const Skup& s) {              // Unija dva skupa.
  for (Elem* tek=s.prvi; tek; tek=tek->sled)
    if (!(*this % *tek->obj)) dodaj(*tek->obj);
  return *this;
}
ostream& operator<<(ostream& it, const Skup& s) {    // Pisanje skupa.
  it << '{';
  for (Skup::Elem* tek=s.prvi; tek; tek=tek->sled) {
    it << *tek->obj << (tek->sled ? ", " : "");
  }
  return it << '}';
}

