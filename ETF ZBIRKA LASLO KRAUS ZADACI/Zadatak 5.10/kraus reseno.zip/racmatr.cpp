// racmatr.C - Metode i funkcije uz klasu matrica racionalnih brojeva.

#include "racmatr.h"
#include <iomanip>
using namespace std;

namespace Aritmetika {
  void Rac_matr::pravi(int v, int k, CRB& r) {     // Dodela memorije.
    m = v; n = k;
    mat = new Rac_broj* [m];
    for (int i=0; i<m; i++) {
      mat[i] = new Rac_broj [n];
      for (int j=0; j<n; mat[i][j++]=r);
    }
  }

  void Rac_matr::kopiraj(CRM& a) {                 // Kopiranje.
    m = a.m; n = a.n;
    mat = new Rac_broj* [m];
    for (int i=0; i<m; i++) {
      mat[i] = new Rac_broj [n];
      for (int j=0; j<n; j++) mat[i][j] = a.mat[i][j];
    }
  }

  void Rac_matr::brisi() {                         // Osloba�anje memorije.
    for (int i=0; i<m; delete [] mat[i++]);
    delete [] mat; mat = nullptr; m = n = 0;
  }

  Rac_matr Rac_matr::operator-() const {           // -A
    Rac_matr a(*this);
    for (int i=0; i<m; i++)
      for (int j=0; j<n; j++)
        a.mat[i][j] = -a.mat[i][j];
    return a;
  }

  Rac_matr T(const Rac_matr& a) {                  // Transponovana matrica.
    Rac_matr b(a.n, a.m);
    for (int i=0; i<a.m; i++)
      for (int j=0; j<a.n; j++) b.mat[j][i] = a.mat[i][j];
    return b;
  }

   Rac_matr Rac_matr::inv_det(Rac_broj& det) const { // Inverzna matrica i
    if (m != n) throw G_rac_mat_kvd();               //   determinata.
    Rac_matr b(m, 2*m); Rac_broj d(1);
    // Stvaranje pro�irene matrice:
    for (int i=0; i<m; i++)
      for (int j=0; j<m; j++)
        { b.mat[i][j] = mat[i][j]; b.mat[i][j+m] = i==j; }
    // Eliminacija unapred:
    for (int i1=0; i1<m; i1++) {
      // obezbe�ivanje nenulte vrednosti na dijagonali:
      if (b.mat[i1][i1] == 0) {
        int j=i1+1; while (j<n && b.mat[j][i1]==0) j++;
        if (j == n) throw G_rac_mat_inv();
        Rac_broj* p = b.mat[i1]; b.mat[i1] = b.mat[j]; b.mat[j] = p;
      }
      // normiranje vrste:
      if (b.mat[i1][i1] != 1) {
        d *= b.mat[i1][i1];
        for (int j=2*m-1; j>=i1; j--) b.mat[i1][j] /= b.mat[i1][i1];
      }
      // stvaranje nula u koloni i1 nadole:
      for (int i2=i1+1; i2<m; i2++)
        if (b.mat[i2][i1] != 0)
          for (int j=2*m-1; j>=i1; j--)
            b.mat[i2][j] -= b.mat[i1][j] * b.mat[i2][i1];
    }
    // Zamenjivanje unazad (stvaranje nula u kolonama nagore):
    for (int i1=m-1; i1>0; i1--) {
      for (int i2=i1-1; i2>=0; i2--)
        if (b.mat[i2][i1] != 0)
          for (int j=2*m-1; j>=i1; j--)
            b.mat[i2][j] -= b.mat[i1][j] * b.mat[i2][i1];
    }
    // Vra�anje rezultata:
    Rac_matr a(m, m);
    for (int i=0; i<m; i++)
      for (int j=0; j<m; j++) a.mat[i][j] = b.mat[i][j+m];
    det = d;
    return a;
  }
 
  Rac_matr& Rac_matr::operator+=(CRM& b) {               // A += B
    if (m!=b.m || n!=b.n) throw G_rac_mat_dim();
    for (int i=0; i<m; i++)
      for (int j=0; j<n; j++) mat[i][j] += b.mat[i][j];
    return *this;
  }

  Rac_matr& Rac_matr::operator-=(CRM& b) {               // A -= B
    if (m!=b.m || n!=b.n) throw G_rac_mat_dim();
    for (int i=0; i<m; i++)
      for (int j=0; j<n; j++) mat[i][j] -= b.mat[i][j];
    return *this;
  }

  Rac_matr Rac_matr::operator*(CRM& b) const {           // A *  B
    if (n != b.m) throw G_rac_mat_dim();
    Rac_matr c(m, b.n);
    for (int i=0; i<m; i++)
      for (int k=0; k<b.n; k++)
        for (int j=0; j<n; j++)
          c.mat[i][k] += mat[i][j] * b.mat[j][k];
    return c;
  }

  Rac_matr& Rac_matr::operator+=(CRB& r) {               // A += r
    for (int i=0; i<m; i++)
      for (int j=0; j<n; mat[i][j++]+=r);
    return *this;
  }

  Rac_matr& Rac_matr::operator*=(CRB& r) {               // A *= r
    for (int i=0; i<m; i++)
      for (int j=0; j<n; mat[i][j++]*=r);
    return *this;
  }

  bool Rac_matr::operator==(CRM& b) const {              // A == B
    if (m!=b.m || n!=b.n) return false;
    for (int i=0; i<m; i++)
      for (int j=0; j<n; j++)
        if (mat[i][j] != b.mat[i][j]) return false;
    return true;
  }

  istream& operator>>(istream& ut, Rac_matr& a) {        // �itanje.
    for (int i=0; i<a.m; i++)
      for (int j=0; j<a.n; ut>>a.mat[i][j++]);
    return ut;
  }

  ostream& operator<<(ostream& it, const Rac_matr& a) {  // Pisanje.
    int sir = it.width(1);
    for (int i=0; i<a.m; i++) {
      it << '[';
      for (int j=0; j<a.n; it << setw(sir) << a.mat[i][j++]);
      it << ']' << endl;
    }
    return it;
  }
}
