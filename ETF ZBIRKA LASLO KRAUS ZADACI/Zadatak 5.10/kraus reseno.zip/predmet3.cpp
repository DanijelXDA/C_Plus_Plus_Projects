// predmet3.C - Stati�ka polja apstraktne klase predmeta.

#include "predmet3.h"

int Predmeti::Predmet::pos_id = 0, Predmeti::Predmet::nivo = 0;

