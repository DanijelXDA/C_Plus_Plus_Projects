// verizt.C - Ispitivanje klase veri�nih razlomaka.

#include "veriz.h"
#include <iostream>
using namespace std;

int main() {
  cout << "n? "; int n; cin >> n; Veriz v(n);
  try {
    while (true) { cout << "i, a[i]? "; int i; cin >> i; cin >> v[i]; }
  } catch (int) {}
  cout << endl << v << endl << endl;
  cout << "xmin, xmax, dx? ";
  double xmin, xmax, dx; cin >> xmin >> xmax >> dx; cout << endl;
  for (double x=xmin; x<=xmax; x+=dx) {
    cout << x << '\t';
    try { cout << v(x) << endl; } catch (int) { cout << "Ne moze!\n"; }
  }
}
