// rfile.h - Klasa relativnih binarnih datoteka.

#include <fstream>
using namespace std;

class RFile : fstream {
public:
  class Greska {         // KLASA GRESAKA.
  public:
    enum Gre { OK ,      // sifre gresaka:
               DUZ,      // - neispravna duzina zapisa,
               BRO,      // - neispravan redni broj zapisa,
               VEL,      // - datoteka nije ceo broj zapisa,
               ZAT,      // - datoteka nije otvorena,
               IMA,      //   datoteka vec postoji,
               NEMA,     //   datoteka ne postoji,
               OTV,      // - nije uspelo otvaranje,
               POZ,      // - nije uspelo pozicioniranje,
               PIS,      // - nije uspelo upisivanje,
               CIT,      // - nije uspelo citanje,
               ZAP       // - zapis ne postoji.
             };
  private:
    Gre gre;                    // sifra greske.
    static const string por[];  // Tekstualni opisi gresaka.
  public:
    Greska(Gre g) { gre = g; }
    friend ostream& operator<<(ostream& it, const Greska& g);
  };
                                            // CLANOVI GLAVNE KLASE:
private:
  long duz_zap, bro_zap, tek_zap, tek_poz;  // bro_zap==-1 - nije otvorena.
  void otvori(const char* ime, long duz=0); // Otvaranje datoteke (duz>0
                                            //   - stvaranje nove).
public:
  RFile(): fstream() { bro_zap = -1; }      // Inic. bez otvaranja datoteke.
  RFile(const char* ime, long duz=0)        // Inic. s otvaranjem datoteke.
    : fstream() { otvori(ime, duz); }
  ~RFile() { close(); }                     // Unistavanje objekta.
  RFile& open(const char* ime, long duz=0)  // Otvaranje datoteke.
    { otvori(ime, duz); return *this; }
  bool open() { return bro_zap >= 0; }      // Da li je datoteka otvorena?
  RFile& write(const void* niz, long zap=0);// Pisanje zap (zap==0 - sekv).
  RFile& read(void* niz, long zap=0);       // Citanje zap (zap==0 - sekv).
  RFile& close();                                  // Zatvaranje datoteke.
  long recn() { return bro_zap<0 ? -1 : bro_zap; } // Broj zapisa u datoteci
  long recl() { return bro_zap<0 ? -1 : duz_zap; } // Duzina zapisa.
};

