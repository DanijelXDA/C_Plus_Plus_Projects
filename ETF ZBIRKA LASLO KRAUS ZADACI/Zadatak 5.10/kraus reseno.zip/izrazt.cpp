// izrazt.C - Ispitivanje klasa za izraze.

#include "konst.h"
#include "prom.h"
#include "oper.h"
using namespace Izrazi;
#include <iostream>
#include <cstdlib>
using namespace std;

int main(int, const char** varg) {
  Prom x("x"), xmin("xmin", atof(varg[1])),
       xmax("xmax", atof(varg[2])), dx("dx", atof(varg[3]));
  const Izraz& izr = (x ^ Konst(3)) - Konst(2) * x;
  cout << xmin << '=' << xmin.vredn() << ", " 
       << xmax << '=' << xmax.vredn() << ", "
       << dx   << '=' << dx  .vredn() << endl;
  cout << '\n' << x << '\t' << izr 
       << "\n======================\n";
  for (x=xmin; x<=xmax; x=x+dx)
    cout << x.vredn() << '\t' << izr.vredn() << endl;
}
