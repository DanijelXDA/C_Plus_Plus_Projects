// poli1.h - Klasa polinoma.

#include <iostream>
using namespace std;

class Poli {
  int n; double* a;          // Red polinoma i pokazivac na koeficijente.
  typedef const Poli CP;     // Nepromenljiv polinom.
  void kopiraj(const double* a, int n);     // Kopiranje u polinom.
  void premesti(Poli& p)                    // Premestanje u polinom.
    { n = p.n; a = p.a; p.a = nullptr; }
  void brisi() { delete [] a; a=nullptr; n=-1; }  // Oslobadjane memorije.
public:                                           // Konstruktori:
  Poli() { a = nullptr; n = -1; }                 // - prazan polinom,
  Poli(const double* a, int n) { kopiraj(a, n); } // - kopiranjem niza,
  Poli(CP& p) { kopiraj(p.a, p.n); }              // - kopiranjem polinoma,
  Poli(Poli&& p) { premesti(p); }                 // - premestanjem polin.
  ~Poli() { brisi(); }                            // Destruktor.
                                                  // Dodela vrednosti:
  Poli& operator=(CP& p) {                        // - kopiranjem,
    if (this != &p) { brisi(); kopiraj(p.a, p.n); }
    return *this;
  }
  Poli& operator=(Poli&& p) {                      // - premestanjem.
    if (this != &p) { brisi(); premesti(p); }
    return *this;
  }
  void niz(double* a, int& n) const;       // Smestanje polinoma u niz.
  int red() const { return n; }            // Red polinoma.
  double operator()(double x) const;       // Vrednost polinoma.
  double& operator[](int ind);             // Pristupanje koeficijentu.
  const double& operator[](int ind) const;
  friend Poli operator+(CP& p1, CP& p2);                  // p1 +  p2
  friend Poli operator-(CP& p1, CP& p2);                  // p1 -  p2
  friend Poli operator*(CP& p1, CP& p2);                  // p1 *  p2
 
  Poli& operator+=(CP& p2) { return *this = *this + p2; } // p1 += p2
  Poli& operator-=(CP& p2) { return *this = *this - p2; } // p1 -= p2
  Poli& operator*=(CP& p2) { return *this = *this * p2; } // p1 *= p2
  friend istream& operator>>(istream& ut, Poli& p);  // Citanje polinoma.
  friend ostream& operator<<(ostream& it, CP& p);    // Pisanje polinoma.
private:
  enum Greska { G_RED, G_IND };            // Sifre gresaka.
  static void greska(Greska g);            // Obrada greske.
};

