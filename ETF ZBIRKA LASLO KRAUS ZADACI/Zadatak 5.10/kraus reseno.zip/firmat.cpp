// firmat.C - Ispitivanje klasa trgovackih firmi.

#include "firmagr.h"
#include "prodavac.h"
#include "sef.h"
#include "firma.h"
using namespace Trgovina;
#include <iostream>
using namespace std;

int main() {
  try {
    Firma firma(30, 5);
    Prodavac* marko = new Prodavac("Marko", 5);
    Prodavac* zoran = new Prodavac("Zoran", 4);
    Sef*      nenad = new Sef     ("Nenad", 6, 2);
    firma.zaposli(marko);
    firma.zaposli(zoran);
    firma.zaposli(nenad);
    nenad->dodeli(marko);
    nenad->dodeli(zoran);
    marko->prodao(5000);
    zoran->prodao(8000);
    cout << firma;
  } catch (G_previse g) { cout << g << endl; }
    catch (G_nema    g) { cout << g << endl; }
}

