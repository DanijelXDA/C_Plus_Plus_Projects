// racmatr.h - Klasa matrica racionalnih brojeva.

#ifndef _racmatr_h_
#define _racmatr_h_

#include "racbroj.h"
#include <iostream>
using namespace std;

namespace Aritmetika {
  class G_rac_mat_ind {}; // Klasa gre�aka: Indeks izvan opsega.
  class G_rac_mat_dim {}; // Klasa gre�aka: Neusagla�ene dimenzije.
  class G_rac_mat_inv {}; // Klasa gre�aka: Ne postoji inverzna matrica.
  class G_rac_mat_kvd {}; // Klasa gre�aka: Matrica nije kvadratna.

  class Rac_matr {
    typedef const Rac_broj CRB;             // Nepromenljiv racionalan broj.
    typedef const Rac_matr CRM;             // Nepromenljiva matrica.
    Rac_broj** mat; int m, n;               // Elementi i dimenzije matrice.
    void pravi(int v, int k, CRB& r);       // Dodela memorije.
    void kopiraj(CRM& a);                   // Kopiranje u matricu.
    void premesti(Rac_matr a) {             // Preme�tanje u matricu.
      mat = a.mat; a.mat = nullptr;
      m = a.m; n = a.n;
    }
    void brisi();                           // Osloba�anje memorije.
    Rac_matr inv_det(Rac_broj& det) const;  // Inverzna matrica i determ.
  public:                                   // Inicijalizacija matrice:
    Rac_matr(int v, int k, Rac_broj r=0)    // - pravougaona matr.,
      { pravi(v, k, r); }
    explicit Rac_matr(int v=5, Rac_broj r=0)// - kvadratna matrica,
      { pravi(v, v, r); }
    Rac_matr(CRM& a) { kopiraj(a); }        // - kopranjem,
    Rac_matr(Rac_matr&& a) { premesti(a); } // - preme�tanjem.
    ~Rac_matr() { brisi(); }                // Uni�tavanje matrice.
    Rac_matr& operator=(CRM& b) {           // A = B (kopiraju�i)
      if (this != &b) { brisi(); kopiraj(b); }
      return *this;
    }
    Rac_matr& operator=(Rac_matr&& b) {     // A = B (preme�taju�i)
      if (this != &b) { brisi(); premesti(b); }
      return *this;
    }
    int vrs() const { return m; }                   // Broj vrsta.
    int kol() const { return n; }                   // Broj kolona.
    const Rac_broj*const operator[](int i) const {  // A[i] (pok. na vrstu):
      if (i<0 || i>=m) throw G_rac_mat_ind();       // - nepromenljiva matr,
      return mat[i];
    }
    Rac_broj*const operator[](int i)                // - promenljiva matr.
      { return (Rac_broj*const)((const Rac_matr&)(*this))[i]; }

    Rac_matr operator+() const { return *this; }    // +A
    Rac_matr operator-() const;                     // -A
    friend Rac_matr T  (CRM& a);                    // Transponovana matr.
    friend Rac_matr inv(CRM& a)                     // Invrezna matrica.
      { Rac_broj det; return a.inv_det(det); }
    friend Rac_broj det(CRM& a)                     // Determinanta.
      { Rac_broj det; a.inv_det(det); return det; }

    Rac_matr& operator+=(CRM& b);                                  // A += B
    Rac_matr& operator-=(CRM& b);                                  // A -= B
    Rac_matr operator+(CRM& b) const { return Rac_matr(*this)+=b; }// A +  B
    Rac_matr operator-(CRM& b) const { return Rac_matr(*this)-=b; }// A -  B

    Rac_matr operator*(CRM& b) const;                              // A *  B
    Rac_matr operator/(CRM& b) const { return *this * inv(b); }    // A /  B
    Rac_matr& operator*=(CRM& b) { return *this = *this * b; }     // A *= B
    Rac_matr& operator/=(CRM& b) { return *this = *this / b; }     // A /= B

    Rac_matr& operator+=(CRB& r);                                  // A += r
    Rac_matr& operator-=(CRB& r) { return *this += -r; }           // A -= r
    Rac_matr& operator*=(CRB& r);                                  // A *= r
    Rac_matr& operator/=(CRB& r) { return *this *= !r; }           // A /= r

    friend Rac_matr operator+(CRB& r, CRM& a)                      // r +  A
      { return Rac_matr(a) += r; }
    friend Rac_matr operator-(CRB& r, CRM& a)                      // r -  A
      { return Rac_matr(-a) += r; }
    friend Rac_matr operator*(CRB& r, CRM& a)                      // r *  A
      { return Rac_matr(a) *= r; }
    friend Rac_matr operator/(CRB& r, CRM& a)                      // r /  A
      { return inv(a) *= r; }

    Rac_matr operator+(CRB& r) const { return   r + *this; }       // A +  r
    Rac_matr operator-(CRB& r) const { return  -r + *this; }       // A -  r
    Rac_matr operator*(CRB& r) const { return   r * *this; }       // A *  r
    Rac_matr operator/(CRB& r) const { return  !r * *this; }       // A /  r

    bool operator==(CRM& b) const;                                 // A == B
    bool operator!=(CRM& b) const { return !(*this == b); }        // A != B

    friend istream& operator>>(istream& ut, Rac_matr& a);        // �itanje.
    friend ostream& operator<<(ostream& it, CRM& a);             // Pisanje.
  };
}
#endif
