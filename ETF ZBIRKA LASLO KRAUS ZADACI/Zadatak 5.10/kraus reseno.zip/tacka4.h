// tacka4.h - Klasa ta�aka u ravni.

#ifndef _tacka4_h_
#define _tacka4_h_

typedef double Real;           // Tip za realne vrednosti.

#include <iostream>
using namespace std;

class Tacka {
  Real x, y;                                              // Koordinate.
public:
  Tacka(Real xx=0, Real yy=0) { x = xx; y = yy; }         // Konstruktor.
  Real aps() const { return x; }                          // Apscisa.
  Real ord() const { return y; }                          // Ordinata.
  friend istream& operator>>(istream& ut, Tacka& t)       // �itanje.
    { return ut >> t.x >> t.y; }
  friend ostream& operator<<(ostream& it, const Tacka& t) // Pisanje.
    { return it << '(' << t.x << ',' << t.y << ')'; }
};

const Tacka ORG;               // Koordinatni po�etak.

#endif

