// zbirka.C - Funkcija uz apstraktnu klasu zbirki apstraktnih predmeta.

#include "zbirka.h"

namespace Zbirke {
  ostream& operator<<(ostream& it,  const Zbirka& z) { // Pisanje.
    it << z.vrsta() << '[';
    for (int i=0; i<z.vel(); i++) { if (i) it << ','; it << *z[i]; }
    return it << ']';
  }
} // namespace

