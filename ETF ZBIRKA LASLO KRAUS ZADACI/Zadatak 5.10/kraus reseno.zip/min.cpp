// min.C - Nala�enje minimuma funkcije.

#include <cmath>
#include <iostream>
using namespace std;

using T = double;         // Tip nezavisno promenljive.
using Pf = T (*)(T);      // Tip pokaziva�a na funkcije.

// Funkcija za nalazenje minimuma zadate funkcije.
double min(Pf pf, T xmin, T xmax, T dx) {
  T m = pf(xmin);
  for (T x=xmin+dx; x<=xmax; x+=dx) {
    double f = pf(x);
    if (f < m) m = f;
  }
  return m;
}

int main() {
  auto oscil = [](T x) { return exp(-0.1*x)*sin(x); }; // Lambda izraz.
  cout << "min(oscil)=" << min(oscil, 0, 6.28, .00314) << endl;
  
  static T p[] = {1, -2, -5, 6}; // Koeficijeti polinoma (x+2)(x-1)(x-3).
  static int n = sizeof(p)/sizeof(T) - 1;              // Red polinoma.
  auto poli = [](T x) -> T {                           // Lambda izraz.
    T s = p[n];
    for (int i=n-1; i>=0; (s*=x)+=p[i--]);
    return s;
  };
  cout << "min(poli)=" << min(poli, -3, 4, .001) << endl;
}
