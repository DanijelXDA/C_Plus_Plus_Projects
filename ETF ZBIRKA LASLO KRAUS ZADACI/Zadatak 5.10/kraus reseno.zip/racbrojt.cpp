// racbrojt.C - Ispitivanje klase racionalnih brojeva.

#include "racbroj.h"
using namespace Aritmetika;
#include <iostream>
#include <iomanip>
using namespace std;

int main() {
  while (true) {
    try {
      Rac_broj a, b; cout << "\na,b? "; cin >> a >> b;
      cout << "a,b= " << setw(12) << a << setw(12) << b << endl;
      cout << "a+b= " << setw(12) << (a + b) << endl;
      cout << "a-b= " << setw(12) << (a - b) << endl;
      cout << "a*b= " << setw(12) << (a * b) << endl;
      cout << "a/b= " << setw(12) << (a / b) << endl;
      cout << "1/a= " << setw(12) << (!a   ) << endl;
      cout << "-a = " << setw(12) << (-a   ) << endl;
      cout << "+a = " << setw(12) << (+a   ) << endl;
      cout << "a++= " << setw(12) << (a++  ) << endl;
      cout << "++a= " << setw(12) << (++a  ) << endl;
      cout << "a--= " << setw(12) << (a--  ) << endl;
      cout << "--a= " << setw(12) << (--a  ) << endl;
    } catch (G_rac_broj) {
      cout << "\nGreska: Delilac jednak nuli.\n";
    }
  }
}
