// kamion.h - Klasa kamiona.

#ifndef _kamion_h_
#define _kamion_h_

#include "vozilo3.h"
#include <iostream>
using namespace std;

class G_pretovaren {};              // KLASA GRESKE: Kamion je pretovaren.
inline ostream& operator<<(ostream& it, const G_pretovaren&) {
  return it << "*** Kamion je pretovaren! ***"; }

class Kamion: public Vozilo {      // KLASA KAMIONA:
  float nos, tov;                  // Nosivost i trenutna tezina tovara.
public:
  Kamion(float sTez, float ns): Vozilo(sTez)  // Stvaranje praznog kamiona.
    { nos = ns; tov = 0; }
  string vrsta() const override { return "Kamion"; } // Naziv vrste vozila.
  float tezina() const override { return Vozilo::tezina() + tov; }// Tezina.
  Kamion& operator+=(float tovar){              // Dodavanje tovara.
    if (tov+tovar > nos) throw G_pretovaren();
    tov += tovarv;
    return *this;
  }
  Kamion& operator-=(float tovar) {             // Skidanje tovara.
    tov -= tovar;
    if (tov<0) tov = 0;
    return *this;
  }
private:
  void pisi(ostream& it) const override         // Pisanje kamiona.
    { Vozilo::pisi(it); it << ' ' << tov; }
};

#endif

