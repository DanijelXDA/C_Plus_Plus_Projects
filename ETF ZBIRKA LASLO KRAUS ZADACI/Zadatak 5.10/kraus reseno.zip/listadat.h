// listadat.h - Definicija klase listi datuma.

#include "datum2.h"

class Lista {
  struct Elem {                    // ELEMENT LISTE:
    Datum dat;                     // - sadrzani datum,
    Elem* sled;                    // - pokazivac na sledeci element,
    Elem(const Datum& d)           // - konstruktor.
      { dat = d; sled = nullptr; }
  };

  Elem *prvi, *posl;               // Pokazivac na pocetak i kraj liste.
  int duz;                         // Duzina liste.
public:                                       // Konstruktori:
  Lista() { prvi = posl = nullptr; duz = 0; } // - podrazumevani,
  Lista(const Lista& lst);                    // - kopirajuci,
  Lista(Lista&& lst) {                        // - premestajuci.
    prvi = lst.prvi; posl = lst.posl;
    duz = lst.duz; lst.prvi = lst.posl = nullptr; }
  ~Lista();                                   // Destruktor.
  Lista& dodaj(const Datum& dat) {            // Dodavanje datuma.
    posl = (!prvi ? prvi : posl->sled) = new Elem(dat);
    duz++;
    return *this;
  }
  int duzina() const { return duz; }    // Duzina liste.
  const Datum* max() const;             // Najkasniji (sveziji) datum.
  void pisi() const;                    // Pisanje  liste.
};
