// duz2.h - Klasa du�i.

#ifndef _duz2_h_
#define _duz2_h_

#include "figura4.h"
#include <iostream>
#include <utility>
using namespace std;

class Duz: public Figura {
  Vektor A, B;                                 // Vektori polo�aja krajeva.
  void pisi(ostream& it) const override { it << A << '-' << B; } // Pisanje.
public:
  Duz(const Vektor& P, const Vektor& Q): A(P), B(Q) {} // Inicijalizacija.
  Duz& operator+=(const Vektor& v) override            // Pomeranje du�i.
    { A += v; B += v; return *this; }
  Duz* kopija() const& override                // Kopija du�i kopiranjem.
    { return new Duz(*this); }
  Duz* kopija() && override                    // Kopija du�i preme�tanjem.
    { return new Duz(move(*this)); }
};

#endif
