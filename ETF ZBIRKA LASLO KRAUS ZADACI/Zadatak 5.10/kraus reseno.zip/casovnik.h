// casovnik.h - Klasa casovnika.

#ifndef _casovnik_h_
#define _casovnik_h_

#include "akter.h"

class Casovnik {
  struct Elem {                            // Element liste aktera.
    Akter* akter; Elem* sled;
    Elem(Akter* akt) { akter = akt; sled = nullptr; }
  };
  Elem *prvi, *posl;                       // Prvi i poslednji element.
public:
  Casovnik() { prvi = posl = nullptr; }    // Stvaranje praznog casovnika.
  Casovnik(const Casovnik&) =delete;       // Ne sme da se kopira.
  void operator=(const Casovnik&) =delete; // Ne sme da se dodeljuje.
  ~Casovnik();                             // Destruktor.
  Casovnik& operator+=(Akter* akt) {       // Prijavljivanje aktera.
    posl = (!prvi ? prvi : posl->sled) = new Elem(akt);
    return *this;
  }
  Casovnik& operator-=(Akter* akt);        // Odjavljivanje aktera.
  void radi(double dt, double maxT);       // Rad casovnika.
};

#endif

