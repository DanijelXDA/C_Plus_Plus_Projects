// poli2.C - Metode klase polinoma.

#include "poli2.h"

double Funkcije::Poli::operator()(double x) const { // Vrednost polinoma.
  double s = 0;
  for (int i=a.maxInd(); i>=0; (s*=x)+=a[i--]);
  return s;
}

double Funkcije::Poli::I(double x) const {          // Vrednost integrala.
  double s = 0;
  for (int i=a.maxInd(); i>=0; i--) (s*=x)+=a[i]/(i+1);
  return s * x;
}

