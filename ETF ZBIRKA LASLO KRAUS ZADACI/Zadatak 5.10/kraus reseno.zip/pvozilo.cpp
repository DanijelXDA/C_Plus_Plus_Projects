// pvozilo.C - Metode klase putnickih vozila.

#include "pvozilo.h"

P_vozilo::P_vozilo(const Osoba* vozac, float sop_tez, int k) // Konstruktor.
    : Vozilo(vozac,sop_tez) {
  osobe = new const Osoba* [kap = k];
  for (int i=0; i<kap; osobe[i++]=nullptr);
}

bool P_vozilo::operator+=(const Osoba* putnik) {     // Ulazak putnika.
  int i = 0; while (i<kap && osobe[i]) i++;
  if (i == kap) return false;
  osobe[i] = putnik; return true;
}

float P_vozilo::tezina() const {                    // Ukupna tezina.
  float t = Vozilo::tezina();
  for (int i=0; i<kap; i++)
    if (osobe[i]) t += osobe[i]->dohv_tez();
  return t;
}

bool P_vozilo::operator-=(const Osoba* putnik) {     // Izlazak putnika.
  int i = 0; while (i<kap && osobe[i]!=putnik) i++;
  if (i == kap) return false;
  osobe [i] = nullptr; return true;
}

void P_vozilo::pisi(ostream& it) const {             // Pisanje.
  Vozilo::pisi(it);
  it << '{';
  bool prvi = true;
  for (int i=0; i<kap; i++)
    if (osobe[i]) {
      if (!prvi) cout << '|';
      it << *osobe[i];
      prvi = false;
    }
  it << '}';
}

