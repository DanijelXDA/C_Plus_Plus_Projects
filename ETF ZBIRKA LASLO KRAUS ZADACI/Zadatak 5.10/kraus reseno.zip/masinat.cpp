// masinat.C - Ispitivanje klasa masina i radnika.

#include "maskvad.h"
#include "massfera.h"
#include "radnik1.h"
using namespace Fabrika;
#include <iostream>
using namespace std;

int main() {
  try {
    Mas_kvad m1(1, 2, 3);
    Mas_sfera m2(2);
    Radnik marko("Marko");
    cout << marko << endl;
    marko += &m1;
    for (int i=0; i<10; i++) delete marko.napravi();
    cout << marko << endl;
    marko += &m2;
    for (int i=0; i<5; i++)  delete marko.napravi();
    cout << marko << endl;
    marko += nullptr;
    for (int i=0; i<12; i++) delete marko.napravi();
    cout << marko << endl;
  } catch (G_nema_masinu g) { cout << g; }
}

