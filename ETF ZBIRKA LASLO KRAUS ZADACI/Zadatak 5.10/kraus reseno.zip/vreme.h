// vreme.h - Klasa vremenskih intervala.

#include <iostream>
using namespace std;

class Vreme {
  long t;                                         // Vreme u sekundama.
  typedef const Vreme CV;                         // Nepromenljivo vreme.
public:
  Vreme(int h, int m, int s)                      // Sastavljanje vremena.
    { t = ((h * 60L + m) * 60 + s); }
  Vreme(long s=0) { t = s; }                      // Sekunde u vremenu.
  friend int  cas(CV& v)  { return v.t / 3600; }  // Casovi u vremenu.
  friend int  min(CV& v)  { return (v.t/60)%60; } // Minute u vremenu.
  friend int  sek(CV& v)  { return v.t % 60; }    // Sekunde u vremenu.
  friend long Sek(CV& v)  { return v.t; }         // Ukupno sekundi.
  Vreme  operator+ ()const{ return  *this; }                  // +t
  Vreme  operator- ()const{ return Vreme(-t); }               // -t
  Vreme& operator++()     { ++t; return *this; }              // ++t
  Vreme& operator--()     { --t; return *this; }              // --t
  Vreme  operator++(int)  { Vreme w(*this); t++; return w; }  // t++
  Vreme  operator--(int)  { Vreme w(*this); t--; return w; }  // t--
  friend Vreme operator+(CV& v, CV& w)                        // v +  w
    { return Vreme(v.t + w.t); }
  friend Vreme operator-(CV& v, CV& w)                        // v -  w
    { return Vreme(v.t - w.t); }
  friend Vreme operator*(CV& v, int k)                        // v *  k
    { return Vreme(v.t * k); }
  friend Vreme operator/(CV& v, int k)                        // v /  k
    { return Vreme(v.t / k); }
  Vreme& operator+=(CV& v)   { t += v.t; return *this; }      // t += v
  Vreme& operator-=(CV& v)   { t -= v.t; return *this; }      // t -= v
  Vreme& operator*=(int k)   { t *= k;   return *this; }      // t *= k
  Vreme& operator/=(int k)   { t /= k;   return *this; }      // t /= k
  friend bool operator< (CV& v, CV& w) { return v.t< w.t; }   // v <  w
  friend bool operator<=(CV& v, CV& w) { return v.t<=w.t; }   // v <= w
  friend bool operator> (CV& v, CV& w) { return v.t> w.t; }   // v >  w
  friend bool operator>=(CV& v, CV& w) { return v.t>=w.t; }   // v >= w
  friend bool operator==(CV& v, CV& w) { return v.t==w.t; }   // v == w
  friend bool operator!=(CV& v, CV& w) { return v.t!=w.t; }   // v != w
 
  friend istream& operator>>(istream& ut, Vreme& v)           // Citanje.
    { int h, m, s; ut >> h >> m >> s; v = Vreme(h, m, s); return ut; }
  friend ostream& operator<<(ostream& it, CV& v) {            // Pisanje.
    Vreme w(v); if (w.t < 0) { it << '-'; w = - w; }
    return it << cas(w) << ':' << min(w) << ':' << sek(w);
  }
};
