// sfera3.h - Klasa sfera.

#ifndef _sfera3_h_
#define _sfera3_h_

#include "proizvod1.h"

namespace Fabrika {
  class Sfera: public Proizvod {
    double r;                                   // Poluprecnik sfere.
    void pisi(ostream& it) const override       // Pisanje sfere.
      { Proizvod::pisi(it); it << '(' << r << ')'; }
  public:
    static const char VR = 'S';                 // Oznaka vrste proizvoda.
    Sfera(double rr) { r = rr; }                // Stvaranje kvadra.
    char vrsta() const override { return VR; }  // Vrsta proizvoda.
    double V() const override                   // Zapremina sfere.
      { return 4 * r*r*r * 3.14159 / 3; }
  }; // class Sfera
} // namespace Fabrika

#endif

