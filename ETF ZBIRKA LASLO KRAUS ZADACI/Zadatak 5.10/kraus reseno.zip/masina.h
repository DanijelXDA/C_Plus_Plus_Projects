// masina.h - Apstraktna klasa masina.

#ifndef _masina_h_
#define _masina_h_

#include "proizvod1.h"

namespace Fabrika {
  class Masina {
    int br;                                // Broj napravljenih proizvoda.
    virtual Proizvod* pravi() const =0;    // Napravi proizvod.
  public:
    Masina() { br = 0; }                   // Stvaranje masine.
    Masina(const Masina&) =delete;         // Ne sme da se kopira.
    void operator=(const Masina&) =delete; // Ne sme da se dodeljuje.
    virtual char vrsta() const =0;         // Vrsta pravljenih proizvoda.
    Proizvod* napravi()                    // Napravi proizvod.
      { br++; return pravi(); }
    int broj() const { return br; }        // Broj napravljenih proizvoda.
  }; // class Masina
} // namespace Fabrika

#endif

