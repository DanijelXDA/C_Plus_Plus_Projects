// red4.C - Metode i funkcije uz klasu redova tacaka pomocu deque<>.

#include "red4.h"

ostream& operator<<(ostream& it, const Red4& r) {          // Pisanje reda.
  for (unsigned i=0; i<r.vel();it <<r.niz[i++]<<' ');
  return it;
}

