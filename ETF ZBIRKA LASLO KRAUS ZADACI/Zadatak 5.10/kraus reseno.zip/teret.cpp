// teret.C - Stati�ko polje klase tereta.

#include "teret.h"

int Teret::pos_id = 0;                  // Poslednji identifikator.

