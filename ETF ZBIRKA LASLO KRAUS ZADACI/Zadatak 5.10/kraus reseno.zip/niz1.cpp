// niz1.C - Metode klase nizova realnih brojeva.

#include "niz1.h"

void Niz::kopiraj(const Niz& niz) {           // Kopiranje u niz.
  a = new double [n = niz.n];
  for (int i=0; i<n; i++) a[i] = niz.a[i];
}
