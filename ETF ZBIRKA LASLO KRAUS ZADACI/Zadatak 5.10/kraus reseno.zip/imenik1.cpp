// imenik1.C - Definicije metoda klase imenika.

#include "imenik1.h"
#include <iostream>
using namespace std;

Imenik::Imenik(const Imenik& im) {        // Kopirajuci konstruktor.
  prvi = nullptr;
  for (Elem *tek=im.prvi, *posl=nullptr; tek; tek=tek->sled)
    posl = (!prvi ? prvi : posl->sled) = new Elem(tek->oso);
}

Imenik::~Imenik() {                       // Destruktor.
  while (prvi) { Elem* stari = prvi; prvi = prvi->sled; delete stari; }
}

Imenik& Imenik::dodaj(const Osoba& oso) { // Dodavanje osobe.
  Elem *tek=prvi, *pret=nullptr;
  while (tek && veci(oso.dohv_JMGB(), tek->oso.dohv_JMGB()))
    { pret = tek; tek = tek->sled; }
  (!pret ? prvi : pret->sled) = new Elem(oso, tek);
  return *this;
}

void Imenik::pisi() const {               // Pisanje imenika.
  for (Elem* tek=prvi; tek; tek=tek->sled)
    { tek->oso.pisi(); cout<<endl; }
}

