// proizvod2.h - Klasa proizvoda.

#ifndef _proizvod2_h_
#define _proizvod2_h_

#include <cstdlib>
#include <iostream>
using namespace std;

class Proizvod {
  int broj;                                            // Sadrzani broj.
public:
  Proizvod() { broj = 1000 * rand() / (RAND_MAX+1); }  // Inicijalizacija.
  friend ostream& operator<<(ostream& it, const Proizvod& p) // Pisanje.
    { return it << p.broj; }
};

#endif

