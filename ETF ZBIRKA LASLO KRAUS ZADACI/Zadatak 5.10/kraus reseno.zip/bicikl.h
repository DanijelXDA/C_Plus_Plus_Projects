// bicikl.h - Definicija klase bicikala.

#ifndef _bicikl_h_
#define _bicikl_h_

#include "vozilo3.h"

class Bicikl: public Vozilo {
public:
  explicit Bicikl(float tez): Vozilo(tez) {}          // Inicijalizacija.
  string vrsta() const override  { return "Bicikl"; } // Naziv vrste vozila.
};

#endif

