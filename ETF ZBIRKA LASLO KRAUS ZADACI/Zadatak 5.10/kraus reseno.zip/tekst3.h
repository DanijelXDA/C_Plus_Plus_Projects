// tekst3.h - Klasa tekstova.

#ifndef _tekst3_h_
#define _tekst3_h_

#include "objekat.h"
#include <cstring>
#include <utility>
using namespace std;

class Tekst: public Obj {
  char* tks;                                   // Sadr�aj objekta.
  bool jednako(const Obj& obj) const           // Da li su jednaki?
    { return strcmp(tks, ((Tekst&)obj).tks) == 0; }
  void pisi (ostream& it) const                // Pisanje objekta.
    { it << '[' << (tks ? tks : "") << ']'; }
  void citaj(istream& ut);                     // �itanje objekta.
  void kopiraj(const char* niz);               // Kopiranje u objekat.
  void premesti(Tekst& t) {                    // Preme�tanje u objekat.
    tks = t.tks; t.tks = nullptr;
  }
public:
  Tekst(const char* niz="") { kopiraj(niz); }  // Inicijalizacija niskom.
  Tekst(const Tekst& t): Obj(t)                // Inicijalizacija tekstom
    { kopiraj(t.tks); }                        //   kopiranjem.
  Tekst(Tekst&& t): Obj(move(t))               // Inicijalizacija tekstom
    { premesti(t); }                           //   preme�tanjem.
  ~Tekst() { delete [] tks; }                  // Uni�tavanje objekta.
  Tekst& operator=(const Tekst& t) {       // Dodela vrednosti kopiranjem.
    if (this != &t) { delete [] tks; Obj::operator=(t); kopiraj(t.tks); }
    return *this;
  }
  Tekst& operator=(Tekst&& t) {            // Dodela vrednosti preme�tanjem.
    if (this != &t) { delete [] tks; Obj::operator=(move(t)); premesti(t); }
    return *this;
  }
  string klasa() const override { return "Tekst"; }           // Ime klase.
  Tekst* kopija() const& override          // Kopija objekta kopiranjem.
    { return new Tekst(*this); }
  Tekst* kopija() && override              // Kopija objekta preme�tanjem.
    { return new Tekst(move(*this)); }
};

#endif
