// razmak.C - Izostavljanje suvisnih razmaka medu recima.

#include <iostream>
using namespace std;

int main() {
  int znak; bool ima = true;

  while ((znak = cin.get()) != EOF)    // while (cin.get(znak))
    if (znak != ' ' && znak != '\t')
      { cout.put(znak); ima = znak == '\n'; }
    else if (!ima) { cout.put(' '); ima = true; }
}
