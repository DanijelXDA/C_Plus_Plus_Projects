// fun1.h - Apstraktna klasa funkcija.

#ifndef _fun1_h_
#define _fun1_h_

#include <iostream>
using namespace std;

class Fun {
public:
  virtual ~Fun() {}                               // Virtuelan destruktor.
  virtual double operator()(double x) const =0;   // Vrednost funkcije.
 
private:
  virtual void pisi(ostream& it) const =0;        // Pisanje funkcije.
  friend ostream& operator<<(ostream& it, const Fun& f)
    { f.pisi(it); return it; }
};

#endif
