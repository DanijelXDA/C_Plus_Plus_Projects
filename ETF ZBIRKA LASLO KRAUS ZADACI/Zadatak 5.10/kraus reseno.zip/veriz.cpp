// veriz.C - Metode klase veri�nih razlomaka.

#include "veriz.h"

Veriz::Veriz(int n): a(n)                     // Stvaranje razlomka.
  { for (int i=0; i<n; i++) a[i] = i+1; }

void Veriz::pisi(ostream& it) const {         // Pisanje razlomka.
  it << "Veriz[";
  for (int i=0; i<a.duz(); i++) { if (i) it << ','; it << a[i]; }
  it << ']';
}

double Veriz::operator()(double x) const {    // Vrednost funkcije.
  double s = 0;
  for (int i=a.duz()-1; i>=0; i--) {
    if (x + s == 0) throw 0;
    s = a[i] / (x + s);
  }
  return s;
}
