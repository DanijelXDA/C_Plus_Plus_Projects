// datum2.C - Definicija statickog polja uz klasu datuma.

#include "datum2.h"

int Datum::dani[2][12] = {
  {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31},
  {31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}
};
