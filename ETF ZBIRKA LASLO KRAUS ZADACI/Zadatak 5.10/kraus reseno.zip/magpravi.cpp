// magpravi.C - Stvaranje pocetne datoteke.

#include <fstream>
using namespace std;

int main() {
  struct Zapis { char naziv[30]; float kolicina, cena; };
  Zapis zapis;
  ifstream pod("magacin.pod");
  ofstream dat("magacin.dat", ios::binary);
  while (pod >> zapis.naziv >> zapis.kolicina >> zapis.cena)
    dat.write((char*)&zapis, sizeof(Zapis));
}

