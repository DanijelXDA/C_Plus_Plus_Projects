// duz1.h - Klasa du�i u ravni.

#ifndef _duz1_h_
#define _duz1_h_

#include "linija.h"
#include "tacka6.h"
#include <cmath>
#include <utility>
using namespace std;

namespace Linije {
  class Duz: public Linija {
    Tacka A, B;                                 // Krajnje ta�ke.
  public:
    explicit Duz(const Tacka& P=Tacka(-1,-1),   // Konstruktor.
                 const Tacka& Q=Tacka(1,1)): A(P), B(Q) {}
    double duzina() const override                   // Du�ina du�i.
      { return sqrt(pow(A.aps()-B.aps(),2) + pow(A.ord()-B.ord(),2)); }
    Duz* kopija() const& override               // Kopija du�i kopiranjem.
      { return new Duz(*this); }
    Duz* kopija() && override                   // Kopija du�i preme�tanjem.
      { return new Duz(move(*this)); }
  private:
    void pisi(ostream& it) const override       // Pisanje du�i.
      { Linija::pisi(it); it << "[duz: A" << A << ", B" << B << ']'; }
  };
}

#endif
