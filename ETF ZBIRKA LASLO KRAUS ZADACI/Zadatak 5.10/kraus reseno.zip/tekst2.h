// tekst2.h - stedljiva
//            klasa tekstova.

#include <iostream>
#include <cstring>
#include <cstdlib>
using namespace std;

class Tekst {
  struct Tks {              // Element liste svih tekstova:
    int   kor;              // - broj koriscenja teksta,
    Tks  *sled, *pret;      // - pokazivaci na sledeci i prethodni tekst,
    char* niz;              // - pokazivac na nisku.
  };
  static Tks *prvi, *posl;  // Pokazivaci na prvi i poslednji tekst.
  static int broj;          // Ukupan broj tekstova.

  Tks* tks;                                   // Pokazivac na tekst.
  void kopiraj(const Tekst& t)                // Kopiranje u tekst.
    { if ((tks = t.tks) != nullptr) tks->kor++; }
  void brisi();                               // Oslobadjanje memorije.
public:                                       // Inicijalizacija:
  Tekst() { tks = nullptr; }                  // - kao prazan tekst,
  Tekst(const char*);                         // - nizom znakova,
  Tekst(const Tekst& t) { kopiraj(t); }       // - drugim tekstom.
  ~Tekst() { brisi(); }                       // Unistavanje.
  Tekst& operator=(const Tekst& t) {          // Dodela vrednosti.
    if (this != &t) { brisi(); kopiraj(t); }
    return *this;
  }
   friend int len(const Tekst& t)          // Duzina teksta.
    { return t.tks ? strlen(t.tks->niz) : 0; }
  friend Tekst operator+                  // Spajanje tekstova.
    (const Tekst&, const Tekst&);
  Tekst& operator+=(const Tekst& t)       // Dodavanje teksta.
    { return *this = *this + t; }
  const char& operator[](int i) const {   // Znak u tekstu
    if (i<0 || len(*this)<=i) exit(1);    //   (ne moze da se promeni).
    return tks->niz[i];
  }
  Tekst operator()(int, int) const;                      // Podniz teksta.
  friend int operator%(const Tekst&, const Tekst&);      // Mesto podniza.
  friend ostream& operator<<(ostream& it, const Tekst& t)// Pisanje teksta.
    { if (t.tks) it << t.tks->niz; return it; }
  friend istream& operator>>(istream&, Tekst&);          // Citanje teksta.
  static int ukupno() { return broj; }    // Ukupan broj tekstova.
  static void spisak();                   // Spisak svih tekstova.
};

