// kvadar3.h - Klasa kvadara.

#ifndef _kvadar3_h_
#define _kvadar3_h_

#include "predmet1.h"

class Kvadar: public Predmet {
  double a, b, c;
public:
  Kvadar(double ss=1, double aa=1, double bb=1, double cc=1) // Konstr.
    : Predmet(ss) { a = aa; b = bb; c = cc; }
  double V() const override { return a * b * c; }            // Zapremina.
private:
  void citaj(istream& ut) override                           // Citanje.
    { Predmet::citaj(ut); ut >> a >> b >> c; }
  void pisi (ostream& it) const override {                   // Pisanje.
    it << "kvadar["; Predmet::pisi(it); 
    it << ',' << a << ',' << b << ',' << c << ']';
  }
};

#endif

