// mnogougao2.h - Klasa obojenih mnogouglova.

#ifndef _mnogougao2_h_
#define _mnogougao2_h_

#include "figura3.h"
#include "niz4.h"
#include <utility>
using namespace std;

namespace Figure {
  class Mnogougao: public Figura {
    Niz<Tacka> temena; // Temena mnogougla.
  public:              // Konstruktor.
    explicit Mnogougao(const Niz<Tacka>& tem, Boja b=Boja())
      : Figura(b), temena(tem) {}
    Mnogougao* kopija() const& override // Kopija mnogougla kopiranjem.
      { return new Mnogougao(*this); }
    Mnogougao* kopija() && override     // Kopija mnogougla preme�tanjem.
      { return new Mnogougao(move(*this)); }
    bool pripada(const Tacka& T) const override; // Da li ta�ka pripada?
  }; // class Mnogougao
} // namespace Figure

#endif

