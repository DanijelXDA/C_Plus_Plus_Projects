// tekst4.h - Klasa tekstova.

#ifndef _tekst4_h_
#define _tekst4_h_

#include "figura4.h"
#include "vektor4.h"
#include "font.h"
#include <string>
#include <iostream>
#include <utility>
using namespace std;

class Tekst: public Figura {
  string tks;                                        // Sadr�ani tekst.
  double vis;                                        // Visina znakova.
  Font fnt;                                          // Kori��eni font.
  Vektor poz;                                        // Polo�aj u ravni.
  void pisi(ostream& it) const override              // Pisanje.
    { it << tks << '[' << poz << ',' << vis << ',' << sirina() << ']'; }
public:
  Tekst(const char* tks, double h, const Font& f,    // Inicijalizacija.
        const Vektor& p): fnt(f), poz(p), tks(tks), vis(h) {}
  double visina() const { return vis; }              // Visina znakova. 
  double sirina() const;                             // �irina teksta.
  Tekst& operator+=(const Vektor& v) override        // Pomeranje teksta.
    { poz += v; return *this; }
  Tekst* kopija() const& override             // Kopija teksta kopiranjem.
    { return new Tekst(*this); }
  Tekst* kopija() && override                 // Kopija teksta preme�tanjem.
    { return new Tekst(move(*this)); }
};

#endif

