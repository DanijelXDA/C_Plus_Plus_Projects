// nizpravoug.C - Definicije paketa za obradu
//                dinamickih nizova pravougaonika u ravni.

#include "nizpravoug.h"

void Geometr::citaj(Niz_prav& niz) {
  cout << "Duzina niza? "; cin >> niz.n;
  if (niz.n > 0) {
    niz.a = new Pravoug [niz.n];
    for (int i=0; i<niz.n; i++) {
      cout << "Pravoug[" << i << "] (xA,yA,xC,yC)? ";
      citaj(niz.a[i]);
    }
  } else { niz.n = 0; niz.a = nullptr; }
}

void Geometr::pisi(const Niz_prav& niz) {
  for (int i=0; i<niz.n; i++) {
    cout << "Pravoug[" << i << "] = "; pisi(niz.a[i]);
    cout << ' ' << P(niz.a[i]) << endl;
  }
}

void Geometr::brisi(Niz_prav& niz)
  { delete [] niz.a; niz.a = nullptr; niz.n = 0; }

void Geometr::kopiraj(Niz_prav& niz1, const Niz_prav& niz2) {
  brisi(niz1);
  if (niz2.n > 0) {
    niz1.a = new Pravoug [niz1.n = niz2.n];
    for (int i=0; i<niz1.n; i++) niz1.a[i] = niz2.a[i];
  }
}

void Geometr::uredi(Niz_prav& niz) {
  for (int i=0; i<niz.n-1; i++)
    for (int j=i+1; j<niz.n; j++)
      if (P(niz.a[j]) < P(niz.a[i]))
        { Pravoug p = niz.a[i]; niz.a[i] = niz.a[j]; niz.a[j] = p; }
}

