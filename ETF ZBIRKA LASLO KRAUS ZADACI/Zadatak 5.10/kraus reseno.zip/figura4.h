// figura4.h - Apstraktna klasa figura u ravni.

#ifndef _figura4_h_
#define _figura4_h_

#include "vektor4.h"
#include <iostream>
using namespace std;
class Figura {
public:
  virtual ~Figura() {}                            // Virtuelan destruktor.
  virtual Figura& operator+=(const Vektor& v) =0; // Pomeranje figure.
  virtual Figura* kopija() const& =0;      // Kopija figure kopiranjem.
  virtual Figura* kopija() && =0;          // Kopija figure preme�tanjem.
private:
  virtual void pisi(ostream& it) const =0;        // Pisanje figure.
  friend ostream& operator<<(ostream& it, const Figura& f)
    { f.pisi(it); return it; }
};

#endif

