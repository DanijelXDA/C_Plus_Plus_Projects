// naredba.C - Stati�ko polje apstraktne klase naredbi.

#include "naredba.h"

int Naredbe::Naredba::nivo = 0;      // Nivo naredbe pri pisanju.
