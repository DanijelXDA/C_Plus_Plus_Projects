// pravoug1t.C - Ispitivanje paketa za obradu pravougaonika u ravni.

#include "nizpravoug.h"
#include <iostream>
using namespace std;
using namespace Geometr;

int main() {
  while (true) {
    Niz_prav niz;
    cout << endl; citaj(niz);
  if (niz.a == nullptr) break;
    uredi(niz);
    cout << endl; pisi(niz);
    brisi(niz);
  }
}

