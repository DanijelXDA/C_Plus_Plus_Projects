// simbol.h - Klasa simbola.

#ifndef _simbol_h_
#define _simbol_h_

class Simbol {
  char zn;                                        // K�d znaka.
  double odnos;                                   // Odnos �irine i visine.
public:
  Simbol(char z, double odn) { zn = z; odnos = odn; }     // Stvaranje.
  char znak() const { return zn; }                // Dohvatanje znaka.
  double sirina(double vis) const { return vis * odnos; } // �irina.
};

#endif

