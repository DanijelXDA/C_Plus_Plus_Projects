// objekat.C - Staticko polje apstraktne klase objekata.

#include "objekat.h"

int Obj::pos_id = 0;

