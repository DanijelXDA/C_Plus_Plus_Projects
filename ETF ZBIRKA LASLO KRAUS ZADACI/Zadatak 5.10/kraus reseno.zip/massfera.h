// massfera.h - Klasa masina za sfere.

#ifndef _massfera_h_
#define _massfera_h_

#include "masina.h"
#include "sfera3.h"

namespace Fabrika {
  class Mas_sfera: public Masina {
    double r;                               // Poluprecnik pravljenih sfera.
    Sfera* pravi() const override              // Napravi sferu.
      { return new Sfera(r); }
  public:
    Mas_sfera(double rr) { r = rr; }           // Stvaranje masine.
    char vrsta() const override                // Vrsta pravljenih proizv.
      { return Sfera::VR; }
    double dohv_r() const { return r; }        // Dohvatanje poluprecnika
  }; // class Mas_sfera                        //   pravljenih sfera.
} // namesapace Fabrika

#endif

