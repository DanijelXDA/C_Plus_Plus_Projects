// radnik2.h - Apstraktna klasa radnika.

#ifndef _radnik2_h_
#define _radnik2_h_

#include <string>
#include <iostream>
using namespace std;

namespace Trgovina {
  class Radnik {
    string ime;                               // Ime radnika.
    double procenat;                          // Procenat za platu.
  public:
    Radnik(string iime, double pproc)         // Inicijalizacija.
      { ime = iime; procenat = pproc; }
    Radnik(const Radnik&) =delete;            // Ne sme da se kopira.
    Radnik& operator=(const Radnik&) =delete; // Ne sme da se dodeljuje.
    virtual ~Radnik() {}                      // Virtuelan destruktor.
    virtual double prihod() const =0;         // Ostvareni prihod.
    double plata() const                      // Iznos plate.
      { return prihod() * procenat / 100; }
    friend ostream& operator<<(ostream& it, const Radnik& r) // Pisanje.
      { return it << r.ime << "/" << r.plata(); }
  }; // class
} // namespace

#endif

