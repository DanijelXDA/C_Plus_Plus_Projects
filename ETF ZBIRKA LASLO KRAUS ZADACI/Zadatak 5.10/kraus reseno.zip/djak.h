// djak.h - Klasa djaka.

#ifndef _djak_h_
#define _djak_h_

#include "osoba4.h"
#include "lista7.h"
#include "ispit.h"
#include <iostream>
using namespace std;

class Djak: public Osoba {
  Lista<Ispit*> ispiti;                    // Lista ispita.
  void pisi(ostream& it) const override    // Pisanje djaka.
    { Osoba::pisi(it); it << ": " << srOce(); }
public:
  Djak(const char* ime, const Datum& rodj) // Konstruktor.
    : Osoba(ime, rodj) {}
  ~Djak();                                 // Destruktor.
  Djak& operator+=(Ispit* isp)             // Dodavanje ispita.
    { ispiti.dodaj(isp); return *this; }
  double srOce() const;                    // Srednja ocena.
};

#endif

