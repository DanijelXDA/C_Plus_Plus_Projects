// radnik1.C - Staticko polje klase radnika.

#include "radnik1.h"

int Fabrika::Radnik::pos_id = 0; // Poslednji identifikator.

