// trkackiauto.C - Metoda klase trkackih automobila.

#include "trkackiauto.h"
#include "voznja.h"

const Voznja& Trkacki_auto::najbrza() const { // Nalazenje najbrze voznje.
  double max = voznje[0].srBrzina();
  int imax = 0;
  for (int i=1; i<voznje.duzina(); i++){
    double m = voznje[i].srBrzina();
    if (m > max) { max = m; imax = i; }
  }
  return voznje[imax];
}

