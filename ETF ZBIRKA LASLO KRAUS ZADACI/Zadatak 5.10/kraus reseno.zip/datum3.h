// datum3.h - Klasa kalendarskih datuma.

#ifndef _datum3_h_
#define _datum3_h_

#include <iostream>
using namespace std;

class Datum {
  short d, m, g;                             // Dan, mesec i godina.
public:
  Datum(short dd, short mm, short gg)        // Stvaranje datuma.
    { d = dd; m = mm; g = gg; }
  Datum() { d = m = g = 0; }                 // Prazan datum.
  short dan() const { return d; }            // Dohvatanje delova datuma.
  short mes() const { return m; }
  short god() const { return g; }
  friend ostream& operator<<(ostream& it, const Datum& dat) // Pisanje.
    { return it << dat.d << '.' << dat.m << '.' << dat.g << '.'; }
};

#endif

