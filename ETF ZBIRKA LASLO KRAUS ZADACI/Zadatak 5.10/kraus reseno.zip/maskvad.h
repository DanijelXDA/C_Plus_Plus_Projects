// maskvad.h - Klasa masina za kvadre.

#ifndef _maskvad_h_
#define _maskvad_h_

#include "masina.h"
#include "kvadar4.h"

namespace Fabrika {
  class Mas_kvad: public Masina {
    double a, b, c;                         // Dimenzije pravljenih kvadara.
    Kvadar* pravi() const override             // Napravi kvadar.
      { return new Kvadar(a, b, c); }
  public:
    Mas_kvad(double aa, double bb, double cc)  // Stvaranje masine.
      { a = aa; b = bb; c = cc; }
    char vrsta() const override                // Vrsta pravljenih proizv.
      { return Kvadar::VR; }
    double dohv_a() const { return a; }        // Dohvatanje dimenzija
    double dohv_b() const { return b; }        //   pravljenih kvadara.
    double dohv_c() const { return c; }
  }; // calss Mas_kvad
} // namespace Fabrika

#endif

