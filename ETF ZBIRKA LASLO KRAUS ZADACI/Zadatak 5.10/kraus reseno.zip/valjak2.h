// valjak2.h - Klasa valjaka.

#ifndef _valjak2_h_
#define _valjak2_h_

#include "telo1.h"
#include <utility>
using namespace std;

class Valjak: public Telo {
  double r, h;                                // Polupre�nik i visina.
public:
  Valjak(double rr=1, double hh=1) { r = rr; h = hh;} // Stvaranje valjka.
  char vrsta() const override { return 'V'; } // Oznaka vrste tela.
  double V() const override                   // Zapremina valjka.
    { return r*r * 3.14159 * h; }
  Valjak* kopija() const& override            // Kopija valjka kopiranjem.
    { return new Valjak(*this); }
  Valjak* kopija() && override                // Kopija valjka preme�tanjem.
    { return new Valjak(*this); }
private:
  void pisi(ostream& it) const override       // Pisanje valjka.
    { it << "V(" << r << ',' << h << ')'; }
};

#endif
