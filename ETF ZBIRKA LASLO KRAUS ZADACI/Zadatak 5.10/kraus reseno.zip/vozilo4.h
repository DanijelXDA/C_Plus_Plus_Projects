// vozilo4.h - Apstraktna klasa vozila.

#ifndef _vozilo4_h_
#define _vozilo4_h_

#include <iostream>
using namespace std;

class Vozilo {
  double sop_tez;                              // Sopstvena te�ina.
public:
  explicit Vozilo(double st) { sop_tez = st; } // Inicijalizacija.
  Vozilo(const Vozilo&) =delete;               // Ne sme da se kopira.
  Vozilo& operator=(const Vozilo&) =delete;    // Ne sme da se dodeljuje.
  virtual ~Vozilo() {}                         // Virtuelan destruktor.
  virtual double uk_tezina() const             // Ukupna te�ina.
    { return sop_tez; }
  virtual double vucna_sila() const =0;        // Vu�na sila.
private:
  virtual void pisi(ostream& it) const =0;     // Pisanje.
  friend ostream& operator<<(ostream& it, const Vozilo& v)
    { v.pisi(it); return it; }
};

#endif

