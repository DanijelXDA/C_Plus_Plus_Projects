// figura3.C - Staticko polje klase figura u ravni.

#include "figura3.h"

int Figure::Figura::pos_id = 0;  // Poslednji identifikator.

