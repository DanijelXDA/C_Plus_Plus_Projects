// nizkompl.h - Klasa nizova 
//              kompleksnih brojeva.

#include "kompl1.h"

class Niz_kompl {
  int n; Kompl* niz;                    // Duzina i pokazivac na elemente.
  void kopiraj(const Niz_kompl&);              // Kopiranje u niz.
  void premesti(Niz_kompl& nk) {               // Premestanje u niz.
    niz = nk.niz; nk.niz = nullptr;
    n = nk.n;
  }
  void brisi() { delete [] niz; }              // Oslobadjanje memorije.
public:                                        // Konstruktori:
  explicit Niz_kompl(int d=10)                 // - podrazumevani,
    { niz = new Kompl [n = d]; }
  Niz_kompl(const Niz_kompl& nk)               // - kopirajuci,
    { kopiraj(nk); }
  Niz_kompl(Niz_kompl&& nk) { premesti(nk); }  // - premestajuci.
  ~Niz_kompl() { brisi(); }                    // Destruktor.
                                               // Dodela vrednosti:
  Niz_kompl& operator=(const Niz_kompl& nk) {  // - kopirajuca,
    if (this != &nk) { brisi(); kopiraj(nk); }
    return *this;
  }
  Niz_kompl& operator=(Niz_kompl&& nk) {       // - premestajuca.
    if (this != &nk) { brisi(); premesti(nk); }
    return *this;
  }
  int duz() const { return n; }                // Duzina niza.
                                               // Element niza:
  Kompl& operator[](int i)                     // - promenljivog,
    { return niz[i]; }
  const Kompl& operator[](int i) const         // - nepromenljivog.
    { return niz[i]; }
};

