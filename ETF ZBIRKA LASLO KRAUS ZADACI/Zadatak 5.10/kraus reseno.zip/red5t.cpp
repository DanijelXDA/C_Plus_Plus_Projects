// red5t.C - Ispitivanje klasa redova tacaka.

#include "red4.h"
#include "red5.h"
#include "tacka4.h"
#include <iostream>
using namespace std;

int main() {
  Red4 r4; Red5 r5;
  for (int i=0; i<5; i++) {
    r4.stavi(Tacka(i, 2*i));
    r5.stavi(Tacka(2*i, i));
  }
  cout << "Napunjeni red4:  " << r4 << endl;
  cout << "Napunjeni red5:  " << r5 << endl;
  cout << "Praznjenje red4: ";
  while (!r4.prazan()) cout << r4.uzmi() << ' '; cout << endl;
  cout << "Praznjenje red5: ";
  while (!r5.prazan()) cout << r5.uzmi() << ' '; cout << endl;
}

