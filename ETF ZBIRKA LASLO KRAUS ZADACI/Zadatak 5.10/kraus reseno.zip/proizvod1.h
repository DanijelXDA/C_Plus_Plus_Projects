// proizvod1.h - Apstraktna klasa proizvoda.

#ifndef _proizvod1_h_
#define _proizvod1_h_

#include <iostream>
using namespace std;

namespace Fabrika {
  class Proizvod {
    static int pos_id;                   // Poslednji identifikator.
    int id = ++pos_id;                   // Identifikator proizvoda.
  public:
    Proizvod() =default;                 // Nov objekat dobija nov identif.
    Proizvod(const Proizvod&) {}         // Kopija dobija nov identifikator.
    virtual ~Proizvod() {}               // Virtuelan destruktor.
    Proizvod& operator=(const Proizvod&) // Levom operandu se ne menja
      { return *this; }                  //   identifikator.
    int dohv_id() const { return id; }   // Dohvatanje identifikatora.
    virtual char vrsta() const =0;       // Oznaka vrste proizvoda.
    virtual double V() const =0;         // Zapremina proizvoda.
  protected:
    virtual void pisi(ostream& it) const { it << vrsta() << id; }// Pisanje.
    friend ostream& operator<<(ostream& it, const Proizvod& p)
      { p.pisi(it); return it; }
  }; // class Proizvod
} // namespace Fabrika

#endif

