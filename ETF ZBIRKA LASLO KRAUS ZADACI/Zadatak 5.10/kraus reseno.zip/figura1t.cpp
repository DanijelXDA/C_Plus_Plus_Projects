// figura1t.C - Ispitivanje klasa geometrijskih figura.

#include "krug2.h"
#include "kvadrat.h"
#include "trougao4.h"
#include <iostream>
using namespace std;

int main() {

  // Element liste figura.
  struct Elem {
    Figura* fig; Elem* sled;
    Elem(Figura* ff, Elem* ss=nullptr) { fig = ff; sled = ss; }
    ~Elem() { delete fig; }
  };

  // Stvaranje liste figura �itaju�i s glavnog ulaza.
  Elem *prvi = nullptr, *posl = nullptr;
  while (true) {
    Figura* pf = nullptr;
    char vrsta; cin >> vrsta;
    switch (vrsta) {
      case 'o': pf = new Krug;    break;
      case 'k': pf = new Kvadrat; break;
      case 't': pf = new Trougao; break;
    }
  if (!pf) break;
    cin >> *pf;
    Elem* novi = new Elem(pf);
    posl = (!prvi ? prvi : posl->sled) = novi;
  }

  // Prikazivanje sadr�aja liste na glavnom izlazu.
  for (Elem* tek=prvi; tek; tek=tek->sled) cout << *tek->fig << endl;

  // �itanje pomeraja za pomeranje figura.
  Real dx, dy; cin >> dx >> dy;
               cout << "\ndx, dy= " << dx << ", " << dy << "\n\n";

  // Stvaranje kopije liste uz pomeranje figura.
  Elem *poc = nullptr, *kraj = nullptr;
  for (Elem* tek=prvi; tek; tek=tek->sled) {
    Elem* novi = new Elem(tek->fig->kopija());
    novi->fig->pomeri(dx,dy);
    kraj = (!poc ? poc : kraj->sled) = novi;
  }

  // Uni�tavanje prve liste.
  while (prvi) { Elem* stari=prvi; prvi=prvi->sled; delete stari; }
  posl = nullptr;

  // Prikazivanje sadr�aja kopirane liste na glavnom izlazu.
  for (Elem* tek=poc; tek; tek=tek->sled) cout << *tek->fig << endl;
}

