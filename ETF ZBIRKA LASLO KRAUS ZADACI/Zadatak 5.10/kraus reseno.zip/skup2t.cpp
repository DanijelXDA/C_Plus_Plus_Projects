// skup2t.C - Ispitivanje klase skupova apstraktnih objekata.

#include "skup2.h"
#include "tekst3.h"
#include "kompl2.h"
#include <iostream>
using namespace std;

Skup citaj() {
  Skup s;
  cout << "Ulaz: ";
  for (bool prvi=true;;){
    char tip; cin >> tip;
  if (tip == '.') break;
    if (!prvi) cout << ", "; prvi = false;
    switch (tip) {
      case 't': case 'T': { Tekst t; cin >> t; cout << t; s += t; break; }
      case 'k': case 'K': { Kompl z; cin >> z; cout << z; s += z; break; }
    }
  }
  cout << endl;
  return s;
}

int main() {
  Skup s1(citaj()), s2(citaj());
  cout << "s1    = " << s1    << endl;
  cout << "s2    = " << s2    << endl;
  cout << "s1+s2 = " << s1+s2 << endl;
  cout << "s1-s2 = " << s1-s2 << endl;
  cout << "s1*s2 = " << s1*s2 << endl;
  cout << "s1-s1 = " << s1-s1 << endl;
  cout << "s1*{} = " << s1*Skup() << endl;
}

