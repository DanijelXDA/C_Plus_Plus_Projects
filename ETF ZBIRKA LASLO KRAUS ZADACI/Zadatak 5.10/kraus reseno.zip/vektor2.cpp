// vektor2.C - Metode klase vektora realnih brojeva.

#include "vektor2.h"

void Vekt::pravi(int poc, int kra) {             // Formiranje vektora.
  if ((min=poc) > (max=kra)) throw OPSEG;
  niz = new double [duz=kra-poc+1];
  for (int i=0; i<duz; niz[i++]=0);
}

void Vekt::kopiraj(const Vekt& v) {              // Kopiranje vektora.
  if (v.niz) {
    niz = new double [duz=(max=v.max)-(min=v.min)+1];
    for (int i=0; i<duz; i++) niz[i] = v.niz[i];
  } else niz = nullptr;
}

double operator*(const Vekt& v, const Vekt& w) { // Skalarni proizvod.
  if (v.niz==nullptr || w.niz==nullptr) throw Vekt::PRAZAN;
  if (v.duz != w.duz)                   throw Vekt::DUZINA;
  double s = 0;
  for (int i=0; i<v.duz; i++) s += v.niz[i] * w.niz[i];
  return s;
}
