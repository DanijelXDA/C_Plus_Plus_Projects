// stek3.h - Klasa stekova tacaka pomocu klase list<>.

#ifndef _stek3_h_
#define _stek3_h_

#include "tacka4.h"
#include "greska.h"
#include <list>
#include <iostream>
using namespace std;

class Stek3 {
  list<Tacka> niz;                             // Sadrzaj steka.
public:
  void stavi(const Tacka& t)                   // Stavljanje na vrh.
    { niz.push_back(t); }
  Tacka uzmi() {                               // Uzimanje sa vrha.
    if (prazan()) throw Usluge::Greska("Stek je prazan!");
    Tacka t = niz.back();
    niz.pop_back();
    return t;
  }
  unsigned vel() const { return niz.size(); }  // Broj elemenata na steku.
  bool prazan() const { return vel() == 0; }   // Da li je stek prazan?
  void prazni() { niz.clear(); }               // Praznjenje steka.
  friend ostream& operator<<(ostream& it, const Stek3& s); // Pisanje steka.
};

#endif

