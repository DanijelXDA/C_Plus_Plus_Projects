// stek3t.C - Ispitivanje klasa stekova tacaka.

#include "stek2.h"
#include "stek3.h"
#include "tacka4.h"
#include <iostream>
using namespace std;

int main() {
  Stek2 s2; Stek3 s3;
  for (int i=0; i<5; i++) {
    s2.stavi(Tacka(i, 2*i));
    s3.stavi(Tacka(2*i, i));
  }
  cout << "Napunjeni stek2:  " << s2 << endl;
  cout << "Napunjeni stek3:  " << s3 << endl;
  cout << "Praznjenje stek2: ";
  while (!s2.prazan()) cout << s2.uzmi() << ' '; cout << endl;
  cout << "Praznjenje stek3: ";
  while (!s3.prazan()) cout << s3.uzmi() << ' '; cout << endl;
}

