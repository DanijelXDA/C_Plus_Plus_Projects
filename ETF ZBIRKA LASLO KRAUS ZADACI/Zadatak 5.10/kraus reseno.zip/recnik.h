// recnik.h - Klasa recnika.

#ifndef _recnik_h_
#define _recnik_h_

#include <string>
#include <set>
#include <map>
#include <iostream>
using namespace std;

class Recnik {
  map<string,set<string> > niz;         // Sadrzaj recnika.
public:
  // Dodavanje prevoda reci.
  Recnik& dodaj(const string& rec, const string& prevod) {
    niz[rec].insert(prevod);
    return *this;
  }
  
  // Brisanje svih prevoda reci.
  Recnik& brisi(const string& rec) {
    niz.erase(rec);
    return *this;
  }
  
  // Brisanje jednog prevoda reci.
  Recnik& brisi(const string& rec, const string& prevod) {
    map<string,set<string> >::iterator i = niz.find(rec);
    if (i != niz.end()) i->second.erase(prevod);
    return *this;
  }
  
  // Dohvatanje svih prevoda reci.
  const set<string>* prevodi(const string& rec) const {
    map<string,set<string> >::const_iterator i = niz.find(rec);
    if (i != niz.end()) return &i->second;
      else              return nullptr;
  }
  
  // Pisanje svih prevoda reci.
  void pisiPrevode(ostream& it, const string& rec) const;
 
  // Pisanje sadrzaja recnika.
  friend ostream& operator<<(ostream& it, const Recnik& recnik);
};

#endif

