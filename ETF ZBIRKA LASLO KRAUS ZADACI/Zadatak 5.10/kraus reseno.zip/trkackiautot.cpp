// trkackiautot.C - Ispitivanje klase trkackih automobila.

#include "trkackiauto.h"
#include "voznja.h"
#include "etapa.h"
#include <iostream>
using namespace std;

int main() {
  try {
    Trkacki_auto ta(800, 10);
    ta.novaVoznja(3)
      .dodaj_etapu(Etapa(100, 50))
      .dodaj_etapu(Etapa(200, 80))
      .dodaj_etapu(Etapa(150, 70))
      .novaVoznja(3)
      .dodaj_etapu(Etapa(300, 70))
      .dodaj_etapu(Etapa(150, 60))
      .dodaj_etapu(Etapa(200, 70)) ;
    cout << ta << endl;
    const Voznja& v = ta.najbrza();
    cout << "Najbrza voznja: " << v << endl;
  } catch (G_niz_pun g) { cout << g << endl;
  } catch (G_indeks  g) { cout << g << endl;
  }
}

