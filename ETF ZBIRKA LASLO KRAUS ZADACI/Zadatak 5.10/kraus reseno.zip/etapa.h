// etapa.h - Klasa etapa voznje.

#ifndef _etapa_h_
#define _etapa_h_

class Etapa {
  float duz, brz;                          // Duzina etape i brzina voznje.
public:
  Etapa () { duz = brz = 0; }                   // "Prazna" etapa.
  Etapa(float d, float b) { duz = d, brz = b; } // Inicijalizacija.
  float duzina() const  { return duz; }         // Duzina etape.
  float brzina() const  { return brz; }         // Brzina voznje.
  float vreme()  const  { return duz / brz; }   // Vreme voznje.
};

#endif

