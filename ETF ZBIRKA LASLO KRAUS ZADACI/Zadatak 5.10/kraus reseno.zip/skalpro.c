// skalpro.c - Skalarni proizvod dva vektora.

double skal_pro(const double *a, const double *b, int n) {
  return n ? (*a) * (*b) + skal_pro(a+1, b+1, n-1) : 0;
}

inline double f(int x) { return x ? x + f(x--) : 0; }

#include <stdio.h>

int main() {
  int n;
  while (scanf("%i", &n) != EOF) {
    double a[100];
    for (int i=0; i<n; scanf("%lf", &a[i++]));
    double b[100];
    for (int i=0; i<n; scanf("%lf", &b[i++]));
    printf("%g\n", skal_pro(a,b,n));
  }
}
