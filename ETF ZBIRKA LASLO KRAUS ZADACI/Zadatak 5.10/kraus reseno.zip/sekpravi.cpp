// sekpravi.C - Formiranje sekvencijalne binarne datoteke.

#include <fstream>
#include <iostream>
using namespace std;

int main(int, const char* varg[]) {
  try {
    ifstream ulaz (varg[1]);              if (!ulaz)  throw 1;
    ofstream izlaz(varg[2], ios::binary); if (!izlaz) throw 2;
    int n;
    while (ulaz >> n) {
      double* x = new double [n];
      for (int i=0; i<n; ulaz >> x[i++]);
      izlaz.write((char*)&n, sizeof(int));
      izlaz.write((char*)x, n*sizeof(double));
      delete [] x;
    }
  } catch (int g) {
    cout << "*** Greska pri otvaranju datoteke " << varg[g] << " ***\a\n";
    return g;
  }
  return 0;
}

