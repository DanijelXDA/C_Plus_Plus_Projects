// tacka2.C - Definicije metoda klase tacaka u ravni.

#include "tacka2.h"
#include <cmath>
using namespace std;

double Tacka::rastojanje(Tacka t) const   // Rastojanje do tacke.
  { return sqrt(pow(x-t.x,2) + pow(y-t.y,2)); }
