// izraz.h - Apstraktna klasa izraza.

#ifndef _izraz_h_
#define _izraz_h_

#include <iostream>
using namespace std;

namespace Izrazi {
  class Izraz {
  public:
    virtual ~Izraz() {}                        // Virtuelan destruktor.
    virtual double vredn() const =0;           // Vrednost izraza.
    virtual Izraz* kopija() const =0;          // Kopija izraza.
  private:
    virtual void pisi(ostream& it) const =0;   // Pisanje izraza.
    friend ostream& operator<<(ostream& it, const Izraz& izr)
      { izr.pisi(it); return it; }
  }; // class Izraz
} // namespace Izrazi

#endif
