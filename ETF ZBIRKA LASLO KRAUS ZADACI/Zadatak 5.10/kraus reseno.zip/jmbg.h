// jmbg.h - Definicija klase jedinstvenih maticnih brojeva gradjana.

#include <cstring>
#include <iostream>
using namespace std;

class JMBG {
  char jmbg[14];                           // Jedinstveni maticni broj.
public:
  JMBG(const char j[]) { strcpy(jmbg, j); }        // Konstruktor.
  const char* dohv_JMBG() const { return jmbg; }   // Dohvatanje broja.
  friend bool veci(const JMBG& j1, const JMBG& j2) // Uporedjivanje.
    { return strcmp(j1.jmbg, j2.jmbg) > 0; }
  void pisi() const { cout << jmbg; }              // Pisanje.
};

