// vektor3.h - Klasa vektora u prostoru.

#ifndef _vektor_h_
#define _vektor_h_

#include <iostream>
#include <cmath>
using namespace std;

class Vektor {
  double x, y, z;        // Komponente vektora.
public:
  explicit Vektor(double xx=0, double yy=0, double zz=0)   // Konstruktor.
    { x = xx; y = yy; z = zz; }
  double intenz() const { return sqrt(x*x+y*y+z*z); }      // Intenzitet.
  Vektor& operator+=(const Vektor& v2)                     // v1 += v2
    { x+=v2.x; y+=v2.y; z+=v2.z; return *this; }
  Vektor& operator*=(double s)                             // v1 *= s
    { x*=s; y*=s; z*=s; return *this; }
  friend ostream& operator<<(ostream& it, const Vektor& v) // Pisanje.
    { return it << '(' << v.x << ',' << v.y << ',' << v.z << ')'; }
};

#endif

