// telo1.h � Apstraktna klasa geometrijskih tela.

#ifndef _telo1_h_
#define _telo1_h_

#include <iostream>
using namespace std;

class Telo {
public:
  virtual ~Telo() {}                    // Virtuelan destruktor.
  virtual char vrsta() const =0;        // Oznaka vrste.
  virtual double V() const =0;          // Zapremina tela.
  virtual Telo* kopija() const& =0;     // Kopija tela kopiranjem.
  virtual Telo* kopija() && =0;         // Kopija tela preme�tanjem.
private:
  virtual void pisi(ostream&) const =0; // Pisanje tela.
  friend ostream& operator<<(ostream& it, const Telo& t)
    { t.pisi(it); return it; }
};

#endif
