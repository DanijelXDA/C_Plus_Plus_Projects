// tacka1.h - Deklaracije paketa za obradu tacaka u ravni.

#include <iostream>
using namespace std;

namespace Geometr {
  struct Tacka { double x, y; };

  inline void pravi(Tacka& T, double x=0, double y=0) { T.x = x; T.y = y; }

  inline void citaj(Tacka& T) { cin >> T.x >> T.y; }

  inline void pisi(const Tacka& T)
    { cout << '(' << T.x << ',' << T.y << ')'; }

  const Tacka ORG = {0, 0}, JED = {1, 1};
}
