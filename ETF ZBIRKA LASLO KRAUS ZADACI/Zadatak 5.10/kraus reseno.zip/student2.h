// student2.h - Klasa studenata.

#ifndef _student2_h_
#define _student2_h_

#include "osoba2.h"
#include <cstdlib>
#include <iostream>
using namespace std;

class Student: public Osoba {
  int* ocene;                           // Niz ocena.
  int kap, n;                           // Kapacitet niza i broj ocena.
public:                                 // Stvaranje objekta.
  Student(string ime, int god, int k=20): Osoba(ime, god)
    { ocene = new int [kap = k]; n = 0; }
  ~Student() { delete [] ocene; }       // Unistavanje objekta.
  Student& operator+=(int oc) {         // Dodavanje ocene.
    if (n == kap) exit(1);
    ocene[n++] = oc;
    return *this;
  }
  int jos() const { return kap - n; }   // Broj slobodnih mesta.
  double sr_ocena() const;              // Srednja ocena.
private:
  void pisi(ostream& it) const override // Pisanje studenta.
    { Osoba::pisi(it); it << '/' << sr_ocena(); }
};

#endif

