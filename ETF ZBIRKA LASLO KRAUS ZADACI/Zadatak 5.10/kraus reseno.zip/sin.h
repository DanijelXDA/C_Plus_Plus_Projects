// sin.h - Klasa sinusoida.

#ifndef _sin_h_
#define _sin_h_

#include "fun2.h"
#include <cmath>
using namespace std;

namespace Funkcije {
  class Sin: public Fun {
  public:
    double operator()(double x) const { return sin(x); }  // Funkcija.
    double I(double x) const { return - cos(x); }         // Integral.
  }; // class Sin
} // namespace Funkcije

#endif

