// voz2t.C - Ispitivanje klase vozova.

#include "voz2.h"
#include "lokomot2.h"
#include "vagon.h"
#include "sanduk.h"
#include "bure.h"
#include <iostream>
using namespace std;

int main() {
  try {
    Voz voz(3);
    voz += new Lokomot(200, 3000);
    Vagon* vag = new Vagon(100, 5);
    *vag += new Sanduk(3, 2, 1, 3);
    *vag += new Bure(2, 2, 4);
    voz += vag;
    vag = new Vagon(150, 10);
    *vag += new Sanduk(4, 2, 10, 3);
    *vag += new Bure(6, 3, 8);
    voz += vag;
    cout << voz;
  } catch (G_preopt g) { cout << g << endl;
  } catch (G_pun    g) { cout << g << endl;
  }
}

