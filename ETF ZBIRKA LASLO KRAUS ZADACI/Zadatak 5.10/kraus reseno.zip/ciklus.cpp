// ciklus.C - Metoda klase ciklusa.

#include "ciklus.h"

void Naredbe::Ciklus:: izvrsi() const                    // Izvr�avanje.
  { while (usl->vredn()) nar->izvrsi(); }
