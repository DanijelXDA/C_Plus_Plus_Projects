// imenik1.h - Definicija klase imenika.

#include "osoba1.h"

class Imenik {
  struct Elem {                           // Element liste:
    Osoba oso;                            // - sadrzana osoba,
    Elem* sled;                           // - pokazivac na sledeci element,
    Elem(const Osoba& o, Elem* s=nullptr) // - konstruktor.
      : oso(o) { sled = s; }
  };
  Elem* prvi;                             // Pokazivac na pocetak liste.
public:
  Imenik() { prvi = nullptr; }            // Stvaranje praznog imenika.
  Imenik(const Imenik& im);               // Kopirajuci konstruktor.
  Imenik(Imenik&& im)                     // Premestajuci konstrukotr.
    { prvi = im.prvi; im.prvi = nullptr; }
  ~Imenik();                              // Destruktor.
  Imenik& dodaj(const Osoba& oso);        // Dodavanje osobe.
  void pisi() const;                      // Pisanje imenika.
};

