// niz3.C - Metode klase nizova apstraktnih predmeta.

#include "niz3.h"

namespace Zbirke {
  void Niz::kopiraj(const Niz& n) {              // Kopiranje u objekat.
    niz = new Predmet* [kap = n.kap]; duz = n.duz;
    for (int i=0; i<duz; i++)
      niz[i] = n.niz[i]->kopija();
  }

  void Niz::povecaj(){                           // Pove�avanje kapaciteta.
    if (duz == kap) {
      kap += kap<100 ? 10 : kap/10;
      Predmet** pom = new Predmet* [kap];
      for (int i=0; i<duz; i++) pom[i] = niz[i];
      delete [] niz; niz = pom;
    }
  }

  Niz& Niz::operator~() {                        // Pra�njenje niza.
    for (int i=0; i<duz; delete niz[i++]);
    duz = 0;
    return *this;
  }
} // namespace

