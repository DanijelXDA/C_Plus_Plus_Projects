// pozdrav.C - Ispisivanje pozdrava.

#include <iostream>
using namespace std;

int main() {
  cout << "Pozdrav svima!" << endl;
  return 0;
}