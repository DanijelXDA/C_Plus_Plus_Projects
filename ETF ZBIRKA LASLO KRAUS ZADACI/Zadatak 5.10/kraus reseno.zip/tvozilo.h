// tvozilo.h - Klasa teretnih vozila.

#ifndef _tvozilo_h_
#define _tvozilo_h_

#include "vozilo1.h"

class T_vozilo: public Vozilo {
  float nosivost, tovar;                       // Nosivost i tezina tovara.
public:
  T_vozilo(const Osoba* vozac, float sop_tez, float nosivost) // Konstr.
    : Vozilo(vozac, sop_tez)
    { this->nosivost = nosivost; tovar = 0; }
  char vrsta() const override { return 'T'; } // Oznaka vrste vozila.
  bool operator+=(float tez) {                // Stavljanje tovara.
    if (tovar+tez > nosivost) return false;
    tovar += tez; return true;
  }
  bool operator-=(float tez) {                // Skidanje tovara.
    if (tovar-tez < 0) return false;
    tovar -= tez;  return true;
  }
  float tezina() const override               // Ukupna tezina vozila.
    { return Vozilo::tezina() + tovar; }
private:
  void pisi(ostream& it) const override {     // Pisanje vozila.
    Vozilo::pisi(it);
    it << '(' << tovar << '/' << nosivost << ')';
  }
};

#endif

