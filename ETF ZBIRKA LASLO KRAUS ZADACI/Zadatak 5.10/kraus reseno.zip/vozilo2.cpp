// vozilo2.C - Stati�ko polje klase vozila.

#include "vozilo2.h"

int Vozovi1::Vozilo::pos_id = 0;        // Poslednji identifikator.

