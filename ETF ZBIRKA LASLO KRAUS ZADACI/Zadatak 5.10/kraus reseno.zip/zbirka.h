// zbirka.h - Apstraktna klasa zbirki apstraktnih predmeta.

#ifndef _zbirka_h_
#define _zbirka_h_

#include "predmet2.h"
#include <iostream>
#include <string>
using namespace std;

namespace Zbirke {
  class G_indeks {};  // GRE�KA: Indeks izvan opsega.
  inline ostream& operator<<(ostream& it, const G_indeks&)
    { return it << "*** Indeks izvan opsega! ***"; }

  class Zbirka {
  public:
    virtual ~Zbirka() {}                        // Virtuelan destruktor.
    virtual string vrsta() const =0;            // Ime vrste zbirke.
    virtual int vel() const =0;                 // Broj predmeta u zbirci.
    virtual Zbirka& operator+=(const Predmet& p)=0; // Dodavanje kopiranjem.
    virtual Zbirka& operator+=(Predmet&& p) =0; // Dodavanje preme�tanjem.
    virtual Predmet*& operator[](int i) =0;     // Dohvatanje elementa
    virtual const Predmet* operator[](int i) const =0; // (pokaziva�!).
    virtual Zbirka& operator~() =0;             // Pra�njenje zbirke.
    virtual Predmet** begin() =0;               // Po�etak zbirke.
    virtual const Predmet*const*const begin() const =0;
    virtual Predmet** end() =0;                 // Kraj zbirke.
    virtual const Predmet*const*const end() const =0;
    friend ostream& operator<<(ostream& it, const Zbirka& z); // Pisanje.
  };
} // namespace
#endif

