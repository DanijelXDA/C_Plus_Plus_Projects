// firma.h - Klasa firmi.

#ifndef _firma_h_
#define _firma_h_

#include "radnik2.h"
#include "firmagr.h"
#include <iostream>
using namespace std;

namespace Trgovina {
  class Firma {
    Radnik** radnici;                         // Niz zaposlenih.
    int kap;                                  // Broj radnih mesta.
    double marza;                             // Iznos marze.
 
  public:
    Firma(double mar, int k=10);              // Inicijalizacija.
    Firma(const Firma&) =delete;              // Ne sme da se kopira.
    Firma& operator=(const Firma&) =delete;   // Ne sme da se dodeljuje.
    ~Firma();                                 // Destruktor.
    Firma& zaposli(Radnik* r);                // Zaposljavanje.
    Firma& otpusti(int i) {                   // Otpustanje.
      if (i<0 || i>=kap || !radnici[i]) throw G_nema();
      delete radnici[i]; radnici[i] = nullptr;
      return *this;
    }
    double dobit() const;                     // Dobit firme.
    friend ostream& operator<<(ostream& it, const Firma& fir); // Pisanje.
  }; // class
} // namespace

#endif

