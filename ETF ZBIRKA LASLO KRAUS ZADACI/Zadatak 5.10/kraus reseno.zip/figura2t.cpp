// figura2t.C - Ispitivanje klasa figura u prostoru.

#include "tacka7.h"
#include "mnogougao1.h"
#include <iostream>
using namespace std;

int main() {
  try {
    cout << "Broj figura? "; int n; cin >> n;
    Figura** niz = new Figura* [n];
    for (int i=0; i<n; ) {
      cout << "Vrsta (T, M)? "; char vrs; cin >> vrs;
      switch (vrs) {
        case 't': case 'T': {
          double x, y, z; cout << "Koordinate tacke? "; cin >> x >> y >> z;
          niz[i++] = new Tacka(Vektor(x, y, z));
          break;
        }
        case 'm': case 'M': {
          cout << "Broj temena? "; int n; cin >> n;
          Mnogougao* m(new Mnogougao(n));
          for (int j=0; j<n; j++) {
            cout << "Koordinate temena " << j << "? ";
            double x, y, z; cin >> x >> y >> z;
            (*m)[j] = Vektor(x, y, z);
          }
          niz[i++] = m;
          break;
        }
        default: cout << "*** Neispravan izbor! ***\n";
      }
    }
    cout << "\nProcitano:\n";
    for (int i=0; i<n; cout<<*niz[i++]<<endl);
    double min = niz[0]->teziste().intenz(); int imin = 0;
    for (int i=1; i<n; i++)
      if (niz[i]->teziste().intenz() < min)
        { min = niz[i]->teziste().intenz(); imin = i; }
    cout << "\nNajblize=" << *niz[imin]
         << " teziste=" << niz[imin]->teziste() << endl;
    Vektor pomak = niz[imin]->teziste() *= -1;
    for (int i=0; i<n; *niz[i++]+=pomak);
    cout << "\nPomereno:\n";
    for (int i=0; i<n; cout<<*niz[i++]<<endl);
  } catch (...) { cout << "*** Neocekivana greska! ***\n"; }
}

