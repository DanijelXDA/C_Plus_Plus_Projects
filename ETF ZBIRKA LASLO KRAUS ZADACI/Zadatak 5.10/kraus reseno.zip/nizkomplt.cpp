// nizkomplt.C - Ispitivanje klase nizova kompleksnih brojeva.

#include "nizkompl.h"
#include <iostream>
using namespace std;

int main() {
  while (true) {
    int n; cout << "n? "; cin >> n;
  if (n <= 0) break;
    Niz_kompl a(n); cout << "a? ";
    for (int i=0; i<n; cin>>a[i++]);     // Ne sme: *(a+i++)
    Kompl s = 0; for (int i=0; i<a.duz(); s+=a[i++]);
    cout << "s= " << s << endl;
  } // Tu se niz unisti destruktorom (na kraju svakog prolaza kroz ciklus).
}

