// teret.h - Apstraktna klasa tereta.

#ifndef _teret_h_
#define _teret_h_

#include <string>
#include <iostream>
using namespace std;

class Teret {
  static int pos_id;                    // Poslednji identifikator.
  int id = ++pos_id;                    // Identifikator tereta.
  double sigma;                         // Specifi�na te�ina.
public:
  explicit Teret(double s=1)            // Nov objekat dobija nov ident.
    { sigma = s; }
  Teret(const Teret& t)                 // Kopija dobija nov identifikator.
    { sigma = t.sigma; }
  virtual ~Teret() {}                   // Virtuelan destruktor.
  Teret& operator=(const Teret& t)      // Levom operandu se ne menja id.
    { sigma = t.sigma; return *this; }
  virtual char vrsta() const =0;        // Oznaka vrste tereta.
  virtual Teret* kopija() const& =0;    // Kopija tereta kopiranjem.
  virtual Teret* kopija() && =0;        // Kopija tereta preme�tanjem.
  virtual double zapr() const =0;       // Zapremina tereta.
  double tezina() const { return zapr() * sigma; }        // Te�ina tereta.
  friend ostream& operator<<(ostream& it, const Teret& t) // Pisanje tereta.
    { return it << t.vrsta() << t.id; }
};

#endif

