// reduk.c - Izostavljanje elemenata niza na osnovu maske.

void redukcija(int niz[], const char maska[], int *n) {
  int i, j, k; char m;
  for (i=j=k=0; i<*n; i++) {
    if (i % 8 == 0) m = maska[k++];
    if (m & 1) niz[j++] = niz[i];
    m >>= 1;
  }
  *n = j;
}

#include <stdio.h>

int main() {
  enum {N = 120};
  while (1) {
    printf("n? "); int n; scanf("%d", &n);
  if (n<=0 || n>N) break;
    printf("niz? "); int niz[120];
    for (int i=0; i<n; scanf("%d", &niz[i++]));
    printf("maska? "); char maska[(N+7)/8];
    for (int i=0; i<(n+7)/8; i++) {
      int m; scanf("%x", &m); maska[i] = m;
    }
    redukcija(niz, maska, &n);
    printf("niz=");
    for (int i=0; i<n;
         printf(" %d", niz[i++]));
    putchar('\n');
  }
}
