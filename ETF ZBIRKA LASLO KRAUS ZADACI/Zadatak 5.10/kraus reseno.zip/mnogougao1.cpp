// mnogougao1.C - Metode klase mnogouglova u prostoru.

#include "mnogougao1.h"

void Mnogougao::pisi(ostream& it) const {          // Pisanje mnogougla.
  it << "M[";
  for (int i=0; i<n; i++) {
    if (i > 0) it << ',';
    it << niz[i];
  }
  it << ']';
}

void Mnogougao::kopiraj(const Mnogougao& m) {      // Kopiranje u mnogougao.
  niz = new Vektor [n = m.n];
  for (int i=0; i<n; i++) niz[i] = m.niz[i];
}

Mnogougao& Mnogougao::operator+=(const Vektor& v){ // Pomeranje mnogougla.
  for (int i=0; i<n; niz[i++]+=v);
  return *this;
}
Vektor Mnogougao::teziste() const {                // Tezi�te mnogougla.
  Vektor t;
  for (int i=0; i<n; t+=niz[i++]);
  return t *= (1. / n);
}

