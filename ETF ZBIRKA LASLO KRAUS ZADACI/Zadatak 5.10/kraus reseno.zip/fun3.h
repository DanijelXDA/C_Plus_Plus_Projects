// fun3.h - Apstraktna klasa
//        funkcija i klasa delegata.

#ifndef _fun3_h_
#define _fun3_h_

#include <iostream>
#include <utility>
using namespace std;

namespace Izvodi {
  class Delegat;  // Deklaracija klase delegata.

  class Fun {                               // DEFINICIJA KLASE FUNKCIJA:
  public:
    ~Fun() {}                               // Virtuelan destruktor.
    virtual double operator()(double x) const =0; // Vrednost funkcije.
    virtual Delegat izvod() const =0;       // Izvod funkcije.
    virtual Fun* kopija() const& =0;        // Kopija funkcije kopiranjem.
    virtual Fun* kopija() && =0;            // Kopija funkcije preme�tanjem.
 
  private:
    virtual void pisi(ostream& it) const =0;  // Pisanje funkcije.
    friend ostream& operator<<(ostream& it, const Fun& f)
      { f.pisi(it); return it; }
  }; // class Fun
  class Delegat: public Fun {                 // DEFINICIJA KLASE DELEGATA:
    Fun* f;                                   // Sadr�ana funkcija.
    void pisi(ostream& it) const override { it << *f; } // Pisanje delegata.
  public:
    Delegat(Fun* ff) { f = ff; }                     // Stvaranje delegata.
    Delegat(const Delegat& d) { f = d.f->kopija(); } // Kopiraju�i konstr.
    Delegat(Delegat&& d) { f = d.f; d.f = nullptr; } // Kopiraju�i konstr.
    ~Delegat() { delete f; }                         // Uni�tavanje deleg.
    Delegat& operator=(const Delegat& d) {           // Kopiraju�a dodela
      if (this != &d) { delete f; f = d.f->kopija(); }     // vrednosti.
      return *this;
    }
    Delegat& operator=(Delegat&& d) {                // Preme�taju�a dodela
      if (this != &d) { delete f; f = d.f; d.f = nullptr;} // vrednosti.
      return *this;
    }
    double operator()(double x) const override       // Vrednost delegata.
      { return (*f)(x); }
    Delegat izvod() const override                   // Izvod delegata.
      { return f->izvod(); }
    Delegat* kopija() const& override       // Kopija delegata kopiranjem.
      { return new Delegat(*this); }
    Delegat* kopija() && override           // Kopija delegata preme�tanjem.
      { return new Delegat(move(*this)); }
  }; // class Delegat
} // namespace Izvodi

#endif

