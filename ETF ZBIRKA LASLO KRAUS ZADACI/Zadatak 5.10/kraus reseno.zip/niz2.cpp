// niz2.C - Metode klase nizova apstraktnih podataka.

#include "niz2.h"

Niz::Niz(int k) {                            // Stvaranje praznog niza.
  niz = new Podatak* [kap = k];
  for (int i=0; i<kap; niz[i++]=nullptr);
}

void Niz::kopiraj(const Niz& n) {            // Inicijalizacija nizom.
  niz = new Podatak* [kap = n.kap];
  for (int i=0; i<kap; i++)
    niz[i] = n.niz[i] ? n.niz[i]->kopija() : nullptr;
}

int Niz::prazno() const {                    // Nala�enje praznog mesta.
  int i = 0; while (i<kap && niz[i]) i++;
  if (i == kap) throw G_pun();
  return i;
}

void Niz::pisi(ostream& it) const {          // Pisanje niza.
  it << '[';
  for (int i=0; i<kap; i++) {
    if (niz[i]) it << *niz[i];
    if (i < kap-1) it << ',';
  }
  it << ']';
}

Niz& Niz::operator~() {                      // Pra�njenje niza.
  for (int i=0; i<kap; i++) { delete niz[i]; niz[i] = nullptr; }
  return *this;
}

