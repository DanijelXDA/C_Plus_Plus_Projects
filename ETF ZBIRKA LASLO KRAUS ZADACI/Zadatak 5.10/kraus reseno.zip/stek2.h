// stek2.h - Klasa stekova tacaka pomocu klase vector<>.

#ifndef _stek2_h_
#define _stek2_h_

#include "tacka4.h"
#include "greska.h"
#include <vector>
#include <iostream>
using namespace std;

class Stek2 {
  vector<Tacka> niz;                           // Sadrzaj steka.
public:
  void stavi(const Tacka& t)                   // Stavljanje na vrh.
    { niz.push_back(t); }
  Tacka uzmi() {                               // Uzimanje sa vrha.
    if (prazan()) throw Usluge::Greska("Stek je prazan!");
    Tacka t = niz.back();
    niz.pop_back();
    return t;
  }
  unsigned vel() const { return niz.size(); }  // Broj elemenata na steku.
  bool prazan() const { return vel() == 0; }   // Da li je stek prazan?
  void prazni() { niz.clear(); }               // Praznjenje steka.
  friend ostream& operator<<(ostream& it, const Stek2& s); // Pisanje steka.
};

#endif

