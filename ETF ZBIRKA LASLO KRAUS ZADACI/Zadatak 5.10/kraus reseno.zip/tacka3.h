// tacka3.h - Klasa tacaka u ravni.

#include <cmath>
#include <iostream>
using namespace std;

class Tacka {
  double x, y;                             // Koordinate tacke.
public:
  explicit Tacka(double xx=0, double yy=0) // Stvaranje tacke.
    { x = xx; y = yy; }
  double dohvX() const { return x; }       // Dohvatanje koordinata.
  double dohvY() const { return y; }
  bool operator==(const Tacka& T2) const   // Da li se poklapaju?
    { return x==T2.x && y==T2.y; }
  bool operator!=(const Tacka& T2) const   // Da li se ne poklapaju?
    { return x!=T2.x || y!=T2.y; }
 
  double operator-(const Tacka& T2) const  // Rastojanje dve tacke.
    { return sqrt(pow(x-T2.x, 2) + pow(y-T2.y, 2)); }
  friend ostream& operator<<(ostream& it, const Tacka& T) // Pisanje.
    { return it << '(' << T.x << ',' << T.y << ')'; }
};

