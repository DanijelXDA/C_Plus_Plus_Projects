// lista6.h - Klasa uredjenih listi celih brojeva.

#ifndef _lista6_h_
#define _lista6_h_

#include "lista5.h"

class U_lista: public N_lista {
public:                                            // Konstruktori:
  U_lista() {}                                     // - prazna lista,
  U_lista(int b): N_lista(b) {}                    // - konverzija.
  U_lista& operator+=(int b) override;             // Dodavanje broja.
  U_lista& operator+=(const N_lista& lst)          // Dodavanje liste.
    { N_lista::operator+=(lst); return *this; }
};

#endif

