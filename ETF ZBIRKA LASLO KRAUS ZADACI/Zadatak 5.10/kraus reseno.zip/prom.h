// prom.h - Klasa promenljivih.

#ifndef _prom_h_
#define _prom_h_

#include "izraz.h"
#include <string>
using namespace std;

namespace Izrazi {
  class Prom: public Izraz {
    struct Elem {                     // Element liste svih promenljivih:
      string ime;                     //  - ime,
      double vr;                      //  - vrednost,
      int br_kor;                      //  - broj kori��enja,
      Elem *pret, *sled;              //  - prethodni i slede�i u listi,
      Elem(string i, double v,        //  - konstruktor.
            Elem* p=nullptr, Elem* s=nullptr)
        { ime = i; vr = v; pret = p; sled = s; br_kor = 1; }
    }; // struct Elem

    static Elem* prvi;                 // Po�etak liste svih promenljivih.
    Elem* ovaj;                        // Element pridru�en ovom objektu.
    void pravi(string ime, double vr); // Stvaranje promenljive.
    void pisi(ostream& it) const override { it << ovaj->ime; } // Pisanje.
  public:                                     // Inicijalizacija:
    Prom(string ime, double vr=0)             // - imenom i vredno��u,
      { pravi(ime, vr); }
    Prom(string ime, const Izraz& i)          // - imenom i izrazom,
      { pravi(ime, i.vredn()); }
    Prom(const Prom& p)                       // - kopijom promenljive.
      { ovaj = p.ovaj; ovaj->br_kor++; }
    ~Prom() {                                 // Uni�tavanje.
      if (--ovaj->br_kor == 0) {
        (ovaj->pret ? ovaj->pret->sled : prvi) = ovaj->sled;
        if (ovaj->sled) ovaj->sled->pret = ovaj->pret;
        delete ovaj;
      }
    }                                         // Dodela vrednosti:
    Prom& operator=(double v)                 // - realnog broja,
      { ovaj->vr = v; return *this; }
    Prom& operator=(const Izraz& i)           // - izraza,
      { ovaj->vr = i.vredn(); return *this; }
    Prom& operator=(const Prom& p)            // - druge promenljive.
      { ovaj->vr = p.vredn(); return *this; }
    double vredn() const override { return ovaj->vr; } // Vrednost prom.
    Prom* kopija() const override { return new Prom(*this); } // Kopija pr.
    friend istream& operator>>(istream& ut, Prom& p)  // �itanje vrednosti.
      { return ut >> p.ovaj->vr; }
    static void pisiSve(ostream& it);          // Spisak svih promenljivih.
  }; // class Prom
} // namespace Izrazi

#endif
