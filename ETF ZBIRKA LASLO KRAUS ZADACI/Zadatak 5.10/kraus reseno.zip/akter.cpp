// akter.C - Staticko polje klase aktera.

#include "akter.h"

int Akter::pos_id = 0;              // Poslednji identifikator.

