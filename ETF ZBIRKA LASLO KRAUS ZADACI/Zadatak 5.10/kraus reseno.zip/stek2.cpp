// stek2.C - Metode i funkcije uz klasu stekova tacaka pomocu vector<>.

#include "stek2.h"

ostream& operator<<(ostream& it, const Stek2& s) {         // Pisanje steka.
  for (unsigned i=s.vel(); i>0; it <<s.niz[--i]<<' ');
  return it;
}

