// student1t.C - Ispitivanje klase studenata.

#include "student1.h"
#include <iostream>
using namespace std;

int main() {
  int n; cin >> n;
  Student** s = new Student* [n];
  for (int i=0; i<n; i++) {

    // Citanje podataka i stvaranje sledeceg studenta.
    string ime; long ind; cin >> ime >> ind;
    Student* t = new Student(ime, ind);
    int br_oc; cin >> br_oc;
    for (int j=0; j<br_oc; j++) { int oc; cin >> oc; *t += oc; }

    // Umetanje u uredjeni niz.
    int k = i;
    while (k>0 && s[k-1]->sr_ocena()<t->sr_ocena()) { s[k] = s[k-1]; k--; }
    s[k] = t;
  }

  // Ispisivanje uredjenog niza.
  for (int i=0; i<n; i++)
    cout << s[i]->dohvati_ime() << '\t' << s[i]->sr_ocena() << endl;
}

