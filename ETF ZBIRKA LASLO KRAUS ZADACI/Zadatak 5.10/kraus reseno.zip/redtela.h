// redtela.h - Klasa redova tela.

#ifndef _redtela_h_
#define _redtela_h_

#include "telo1.h"
#include <iostream>
#include <cstdlib>
using namespace std;

class Red_tela {
  Telo** tela;                              // Niz tela.
  int kap, duz;                             // Kapacitet i du�ina reda.
  int prvo, posl;                           // Prvo i poslednje telo.
  void kopiraj(const Red_tela&);            // Kopiranje u red.
  void premesti(Red_tela& rt) {             // Preme�tanje u red.
    tela = rt.tela; rt.tela = nullptr;
    kap = rt.kap; duz = rt.duz;
    prvo = rt.prvo; posl = rt.posl;
  }
  void brisi();                             // Osloba�anje memorije.
public:
  explicit Red_tela(int k=5);               // Konstruktori.
  Red_tela(const Red_tela& rt) { kopiraj(rt); }
  Red_tela(Red_tela&& rt) { premesti(rt); }
  ~Red_tela() { brisi(); }                  // Destruktor.
  Red_tela& operator=(const Red_tela& rt) { // Dodele vrednosti.
    if (this != &rt) { brisi(); kopiraj(rt); }
    return *this;
  }
  Red_tela& operator=(Red_tela&& rt) {
    if (this != &rt) { brisi(); premesti(rt); }
    return *this;
  }
  bool pun() { return duz == kap; }         // Da li je red pun?
  bool prazan() { return duz == 0; }        // Da li je red prazan?
  Red_tela& operator+=(const Telo& t) {     // Dodavanje tela na kraj reda
    if (duz == kap) exit(1);                //   kopiranjem.
    tela[posl++] = t.kopija(); if (posl == kap) posl = 0;
    duz++;
    return *this;
  }
  Red_tela& operator+=(Telo&& t) {          // Dodavanje tela na kraj reda
    if (duz == kap) exit(1);                //   preme�tanjem.
    tela[posl++] = move(t).kopija(); if (posl == kap) posl = 0;
    duz++;
    return *this;
  }
  Telo* uzmi() {                            // Uzimanje tela s po�etka reda.
    if (duz == 0) exit(2);
    Telo* t = tela[prvo];
    tela[prvo++] = nullptr; if (prvo == kap) prvo = 0;
    duz--;
    return t;
  }
  friend ostream& operator<<(ostream&, const Red_tela&); // Pisanje reda.
};

#endif
