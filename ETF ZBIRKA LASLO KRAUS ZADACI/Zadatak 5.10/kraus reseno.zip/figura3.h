// figura3.h - Apstraktna klasa obojenih figura u ravni.

#ifndef _figura3_h_
#define _figura3_h_

#include "boja.h"
#include "tacka9.h"
#include <iostream>
using namespace std;

namespace Figure {
  class G_ne_pripada {}; // KLASA GRE�AKA: Ta�ka ne pripada figuri.
  inline ostream& operator<<(ostream& it, const G_ne_pripada&)
    { return it << "*** Tacka ne pripada figuri! ***"; }

  class Figura {                              // KLASA FIGURA:
    static int pos_id;                        // Poslednji identifikator
    int id = ++pos_id;                        // Identifikator figure.
    Boja b;                                   // Osnovna boja figure.
  public:
    explicit Figura(Boja bb=Boja())           // Nova figura dobija
      : b(bb) {}                              //   nov identifikator.
    Figura(const Figura& fig)                 // Kopija dobija nov
      : b(fig.b) {}                           //   identifikator.
    Figura& operator=(const Figura& fig)      // Levom operandu se ne
      { b = fig.b; return *this; }            //   menja identifikator.
    virtual ~Figura() {}                      // Virtuelan destruktor.
    virtual Figura* kopija() const& =0;       // Kopija figure kopiranjem.
    virtual Figura* kopija() && =0;           // Kopija figure preme�tanjem.
    int dohv_id() const { return id; }        // Identifikator figure.
    Boja boja() const { return b; }           // Osnovna boja figure.
    virtual bool pripada(const Tacka& T) const=0; // Da li ta�ka pripada?
    virtual Boja boja(const Tacka& T) const { // Boja ta�ke.
      if (!pripada(T)) throw G_ne_pripada();
      return b;
    }
  }; // class Figura
} // namespace Figure

#endif

