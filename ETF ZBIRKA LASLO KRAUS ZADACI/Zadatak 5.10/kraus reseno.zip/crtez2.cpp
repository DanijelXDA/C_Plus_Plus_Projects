// crtez2.C - Metoda klase crte�a.

#include "crtez2.h"

Crtez& Crtez::operator+=(const Vektor& v) {    // Pomeranje crte�a.
  for (int i=0; i<niz.kapac(); i++)
    try { niz[i] += v; } catch(G_prazno) {}
  return *this;
}

