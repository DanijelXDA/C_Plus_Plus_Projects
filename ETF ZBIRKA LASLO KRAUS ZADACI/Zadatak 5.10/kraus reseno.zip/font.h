// font.h - Klasa fontova.

#ifndef _font_h_
#define _font_h_

#include "simbol.h"
#include <iostream>
using namespace std;

class G_nema {};                            // KLASA GRE�AKA: Nema simbola.
inline ostream& operator<<(ostream& it, const G_nema&)
  { return it << "*** Nema simbola! ***"; }

class Font {                               // KLASA FONTOVA:
  struct Elem {                            // Element liste simbola.
    Simbol sim; Elem* sled;
    Elem(const Simbol& s): sim(s) { sled = nullptr; }
  };
  Elem *prvi, *posl;                       // Prvi i poslednji element.
  int br_simb;                             // Du�ina liste.
  void kopiraj(const Font& f);             // Kopiranje u font.
  void premesti(Font& f) {                 // Preme�tanje u font.
    prvi = f.prvi; posl = f.posl; br_simb = f.br_simb;
    f.prvi = f.posl = nullptr;
  }
  void brisi();                            // Osloba�anje memorije.
public:
  Font() { prvi = posl = nullptr; br_simb = 0; } // Inicijalizacija.
  Font(const Font& f) { kopiraj(f); }      // Kopiraju�i konstruktor.
  Font(Font&& f) { premesti(f); }          // Preme�taju�i konstruktor.
  ~Font() { brisi(); }                     // Destruktor.
  Font& operator=(const Font& f) {         // Kopiraju�a dodela vrednosti.
    if (this != &f) { brisi(); kopiraj(f); }
    return *this;
  }
  Font& operator=(Font&& f) {              // Preme�taju�a dodela vrednosti.
    if (this != &f) { brisi(); premesti(f); }
    return *this;
  }
  int br_simbola() const { return br_simb; } // Broj simbola.
  Simbol& operator[](char zn);             // Pristup simbolu promenljivog
  const Simbol& operator[](char zn) const  // ... i nepromenljivog fonta.
    { return const_cast<Font&>(*this)[zn]; }
 
  Font& operator+=(const Simbol& s) {      // Dodavanje simbola:
    try {                                  // - zamena postoje�eg,
      (*this)[s.znak()] = s;
    } catch (G_nema) {                     // - dodavanje novog.
      br_simb++;
      posl = (!prvi ? prvi : posl->sled) = new Elem(s);
    }
    return *this;
  }
};

#endif

