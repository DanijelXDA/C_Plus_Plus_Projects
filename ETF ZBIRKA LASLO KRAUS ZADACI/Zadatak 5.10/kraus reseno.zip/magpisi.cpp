// magpisi.C - Ispisivanje sadrzaja datoteke.

#include <fstream>
#include <iostream>
#include <iomanip>
using namespace std;

int main() {
  struct Zapis { char naziv[30]; float kolicina, cena; };
  Zapis zapis; int sifra = 0;
  ifstream dat("magacin.dat", ios::binary);
  cout << fixed << setprecision(2);
  while (dat.read((char*)&zapis, sizeof(Zapis)))
    cout << setw( 2) << ++sifra        << ' ' << left
         << setw(20) << zapis.naziv    << ' ' << right
         << setw(10) << zapis.kolicina << ' '
         << setw(10) << zapis.cena     << endl;
}

