// lista5.h - Klasa neuredjenih listi celih brojeva.

#ifndef _lista5_h_
#define _lista5_h_

#include <iostream>
using namespace std;

class N_lista {
protected:
  struct Elem {               // Element liste:
    int broj; Elem* sled;     // - sadrzaj i pokazivac na sledeci element,
    Elem(int b, Elem* s=nullptr)   // - konstruktor.
      { broj = b; sled = s; }
  };
  Elem *prvi, *posl;                  // Prvi i poslednji element liste.
  int duz;                            // Duzina liste.
private:
  void kopiraj(const N_lista& lst);   // Kopiranje u objekat.
  void premesti(N_lista& lst) {       // Premestanje u objekat.
    prvi = lst.prvi; posl = lst.posl;
    duz = lst.duz; lst.prvi = lst.posl = nullptr;
  }
  void brisi();                       // Oslobadjanje memorije.
public:                                                 // Konstruktori:
  N_lista() { prvi = posl = nullptr; duz = 0; }         // - prazna lista,
  N_lista(int b)                                        // - konverzija,
    { prvi = posl = new Elem(b); duz = 1; }
  N_lista(const N_lista& lst) { kopiraj(lst); }         // - kopiranje,
  N_lista(N_lista&& lst) { premesti(lst); }             // - premestanje.
  ~N_lista() { brisi(); }                               // Unistavanje.
  N_lista& operator=(const N_lista& lst) {              // Dodela vrednosti
    if (this != &lst) { brisi(); kopiraj(lst); }        //   kopiranjem.
    return *this;
  }
  N_lista& operator=(N_lista&& lst) {                   // Dodela vrednosti
    if (this != &lst) { brisi(); premesti(lst); }       //   premestanjem.
    return *this;
  }
  int duzina() const { return duz; }                    // Duzina liste.
  virtual N_lista& operator+=(int b) {                  // Dodavanje broja.
    Elem* novi = new Elem(b); duz++;
    posl = (!prvi ? prvi : posl->sled) = novi;
    return *this;
  }
  N_lista& operator+=(const N_lista& lst);              // Dodavanje liste.
  friend ostream& operator<<(ostream&, const N_lista&); // Pisanje.
};

#endif

