// osoba4.h - Klasa osoba.

#ifndef _osoba4_h_
#define _osoba4_h_

#include "datum3.h"
#include <string>
#include <iostream>
using namespace std;

class Osoba {
  string ime;                                    // Ime.
  Datum rodj;                                    // Datum rodjenja.
public:
  Osoba(string ii, const Datum& rr)              // Konstruktor.
    { ime = ii; rodj = rr; }
  Osoba(const Osoba&) =delete;                   // Ne sme da se kopira.
  Osoba& operator=(const Osoba&) =delete;        // Ne sme da se dodeljuje.
  virtual ~Osoba() {}                            // Virtuelan destruktor.
  Osoba& staviIme(string ii)                     // Menjanje imena.
    { ime = ii; return *this; }
  Osoba& staviRodj(const Datum& rr)              // Menjanje datuma rodjenja.
    { rodj = rr; return *this; }
  string dohv_ime() const { return ime; }        // Dohvatanje imena.
  const Datum& dohvRodj() const { return rodj; } // Dohvatanje dat. rodj.
protected:
  virtual void pisi(ostream& it) const           // Pisanje osobe.
    { it << ime << " (" << rodj << ')'; }
  friend ostream& operator<<(ostream& it, const Osoba& oso)
    { oso.pisi(it); return it; }
};

#endif

