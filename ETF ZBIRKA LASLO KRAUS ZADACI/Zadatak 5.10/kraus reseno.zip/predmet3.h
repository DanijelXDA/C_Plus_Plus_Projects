// predmet3.h - Apstraktna klasa predmeta.

#ifndef _predmet3_h_
#define _predmet3_h_

#include <iostream>
#include <iomanip>
#include <typeinfo>
#include <string>
using namespace std;

namespace Predmeti {
  class Predmet {
    static int pos_id;                     // Poslednji identifikator.
    int id = ++pos_id;                     // Identifikator predmeta.
  public:
    Predmet() {}                           // Nov predmet dobija nov broj.
    Predmet(const Predmet&) {}             // Kopija dobija nov broj.
    virtual ~Predmet() {}                  // Virtuelan destruktor.
    Predmet& operator=(const Predmet&)     // Levom operandu se ne menja
      { return *this; }                    //   broj.
    virtual Predmet* kopija() const& =0;   // Kopija predmeta kopiranjem.
    virtual Predmet* kopija() && =0;       // Kopija predmeta preme�tanjem.
    virtual double V() const =0;           // Zapremina predmeta.
    virtual double Q() const =0;           // Te�ina predmeta.
    virtual string vrsta() const =0;       // Vrsta predmeta.
  protected:
    static int nivo;                       // Nivo pisanja predmeta.
    virtual void pisi(ostream& it) const   // Pisanje predmeta.
      { it << setw(nivo*2) << "" << vrsta() << '/' << id << ' '; }
    friend ostream& operator<<(ostream& it, const Predmet& p)
      { p.pisi(it); return it; }
  }; // class Predmet
} // namespace Predmeti

#endif

