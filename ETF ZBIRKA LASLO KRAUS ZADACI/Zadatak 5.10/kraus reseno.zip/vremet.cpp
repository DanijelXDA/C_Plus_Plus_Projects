// vremet.C - Ispitivanje klase vremenskih intervala.

#include "vreme.h"
#include <iostream>
using namespace std;

int main() {
  while (true) {
    int k; cin >> k;
  if (!k) break;
    Vreme t1, t2; cin >> t1 >> t2;
    long s1 = Sek(t1), s2 = Sek(t2);
    cout << "k        = " << k << endl;
    cout << "t1, t2   = " << t1 << ", "  << t2 << endl;
    cout << "s1       = " << s1 << "  (" << Vreme(s1) << ")\n";
    cout << "s2       = " << s2 << "  (" << Vreme(s2) << ")\n";
    cout << "-  t1    = " <<  -  t1      << endl;
    cout << "++ t1    = " <<  ++ t1      << endl;
    cout << "t2 --    = " <<  t2 --      << endl;
    cout << "t1       = " << t1 << "  (" << Sek(t1) << ")\n";
    cout << "t2       = " << t2 << "  (" << Sek(t2) << ")\n";
    cout << "t1 +  t2 = " <<  t1 +  t2   << endl;
    cout << "t1 -  t2 = " <<  t1 -  t2   << endl;
    cout << "t1 == t2 = " << (t1 == t2)  << endl;
    cout << "t1 >  t2 = " << (t1 >  t2)  << endl;
    cout << "t1 *  k  = " <<  t1 *  k    << endl;
    cout << "t2 /  k  = " <<  t2 /  k    << endl;
    cout << "s1+t2*k  = " << Vreme(s1) + t2*k << " ("
                          << s1 + Sek(t2*k)   << ")\n";
  }
}
