// akter.h - Apstraktna klasa
//           aktera.

#ifndef _akter_h_
#define _akter_h_

#include <cstdlib>
#include <iostream>
using namespace std;

class Akter {
  static int pos_id;               // Poslednji identifikator.
  int id = ++pos_id;               // Identifikator aktera.
  double minT, maxT;               // Min i max vreme izmedju dve radnje.
  double t;                        // Preostalo vreme do sledece radnje.
  void kopiraj(const Akter& a)     // Kopiranje u objekat (bez ident.!).
    { minT = a.minT; maxT = a.maxT; t = a.t; }
  double slucT()                   // Generisanje slucajnog vremena.
    { return minT + (maxT-minT)*rand()/(RAND_MAX+1); }
  virtual void radnja() =0;        // Radnja aktera.
 
public:
  Akter(double tMin=0, double tMax=1)             // Inicijalizacija.
    { minT = tMin; maxT = tMax; t = 0; }
  Akter(const Akter& a) { kopiraj(a); }           // Kopirajuci konstruktor.
  virtual ~Akter() {}                             // Virtuelan destruktor.
  Akter& operator=(const Akter& a) {              // Dodela vrednosti.
    kopiraj(a);
    return *this;
  }
  void proteklo(double dt) {       // Saopstavanje proteklog vremena.
    if ((t -= dt) <= 0) { radnja(); t = slucT(); }
  }
  friend ostream& operator<<(ostream& it, const Akter& a) // Pisanje.
    { return it << "    " << a.id; }
};

#endif

