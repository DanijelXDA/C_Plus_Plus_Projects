// vozilo1t.C - Ispitivanje klasa vozila.

#include "tvozilo.h"
#include "pvozilo.h"
#include <iostream>
using namespace std;

int main() {
  Vozilo* vozila[100]; int br_vozila = 0;
  Osoba*  osobe[100];  int br_osoba  = 0;
  while (true) {
    cout << "\nVrsta vozila (T,P,*)? "; char vrs; cin >> vrs;
  if (vrs == '*') break;
    cout << "Ime vozaca?           "; string ime; cin >> ime;
    cout << "Tezina vozaca?        "; float tezina ; cin >> tezina;
    Osoba* vozac = osobe[br_osoba++] = new Osoba(ime, tezina);
    cout << "Tezina vozila?        "; float tez_vozila; cin >> tez_vozila;
    switch (vrs) {
      case 't': case 'T': {
        cout << "Nosivost vozila?      "; float nosivost; cin >> nosivost;
        T_vozilo* tv = new T_vozilo(vozac, tez_vozila, nosivost);
        cout << "Tezina tereta?        "; float teret; cin >> teret;
        *tv += teret;
        vozila[br_vozila++] = tv;
        break;
      }
      case 'p': case 'P': {
        cout << "Broj mesta?           ";   int br_mesta; cin >> br_mesta;
        P_vozilo* pv = new P_vozilo(vozac, tez_vozila, br_mesta);
        while (true) {
          cout << "Ime putnika?          "; string ime;   cin >> ime;
        if (ime == "*") break;
          cout << "Tezina putnika?       "; float tezina; cin >> tezina;
          *pv += osobe[br_osoba++] = new Osoba(ime, tezina);
        }
        vozila[br_vozila++] = pv;
        break;
      }
      default:
        cout << "*** Nepoznata vrsta vozila! ***\n";
    }
  }
  cout << "\nNosivost mosta?       "; double nosivost; cin >> nosivost;
  cout << "\nMogu da predju most:\n";
  for (int i=0; i<br_vozila; i++)
    if (vozila[i]->tezina() <= nosivost)
      cout << *vozila[i] << " - " << vozila[i]->tezina() << endl;
  for (int i=0; i<br_vozila; delete vozila[i++]);
  for (int i=0; i<br_osoba;  delete osobe [i++]);
}

