// ciklus.h - Klasa ciklusa.

#ifndef _ciklus_h_
#define _ciklus_h_

#include "izraz.h"
using namespace Izrazi;
#include "naredba.h"

namespace Naredbe {
  class Ciklus: public Naredba {
    Izraz*   usl;                            // Uslov ciklusa.
    Naredba* nar;                            // Sadr�aj ciklusa.
    void kopiraj(const Ciklus& c)            // Kopiranje u ciklus.
      { usl = c.usl->kopija(); nar = c.nar->kopija(); }
    void brisi() { delete usl; delete nar; } // Osloba�anje memorije.
    void pisi(ostream& it) const {           // Pisanje.
      Naredba::pisi(it); it << "while(" << *usl << ")\n";
      nivo++; it << *nar; nivo--;
    }
  public:
    Ciklus(const Izraz& u, const Naredba& n)  // Inicijalizacija.
      { usl = u.kopija(); nar = n.kopija(); }
    Ciklus(const Ciklus& s) { kopiraj(s); }   // Kopiraju�i konstruktor.
    ~Ciklus() { brisi(); }                 // Uni�tavanje ciklusa.
    Ciklus& operator=(const Ciklus& s) {   // Kopiraju�a dodela vrednosti.
      if (this != &s) { brisi(); kopiraj(s); }
      return *this;
    }
    void izvrsi() const;                                 // Izvr�avanje.
    Ciklus* kopija() const { return new Ciklus(*this); } // Kopija.
  }; // class Ciklus
} // namespace Naredbe

#endif
