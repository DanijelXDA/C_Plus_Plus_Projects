// veriz.h - Klasa veri�nih razlomaka.

#ifndef _veriz_h_
#define _veriz_h_

#include "fun1.h"
#include "niz1.h"

class Veriz: public Fun {
  Niz a;                                      // Koeficijenti razlomka.
  void pisi(ostream& it) const override;      // Pisanje razlomka.
public:
  explicit Veriz(int n);                      // Stvaranje razlomka.
  double& operator[](int i) { return a[i]; }  // Dohvatanje koeficijenta.
  const double& operator[](int i) const { return a[i]; }
  int red() const { return a.duz(); }         // Red razlomka.
  double operator()(double x) const override; // Vrednost razlomka.
};

#endif
