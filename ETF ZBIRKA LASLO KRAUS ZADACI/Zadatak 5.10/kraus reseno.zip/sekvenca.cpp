// sekvenca.C - Metode klase sekvenci.

#include "sekvenca.h"

namespace Naredbe {
  void Sekvenca::kopiraj(const Sekvenca& s) {    // Kopiranje u objekat.
    prva = nullptr; Elem* posl = nullptr;
    for (Elem* tek=s.prva; tek; tek=tek->sled)
      posl = (!prva ? prva : posl->sled) = new Elem(tek->nar->kopija());
  }

  void Sekvenca::pisi(ostream& it) const {       // Pisanje sekvence.
    Naredba::pisi(it); it << "{\n";
    nivo++;
    for (Elem* tek=prva; tek; tek=tek->sled) it << *tek->nar;
    nivo--;
    Naredba::pisi(it); it << "}\n";
  }

  void Sekvenca::izvrsi() const {                // Izvr�avanje sekvence.
    for (Elem* tek=prva; tek; tek=tek->sled) tek->nar->izvrsi();
  }
} // namespace Naredbe
