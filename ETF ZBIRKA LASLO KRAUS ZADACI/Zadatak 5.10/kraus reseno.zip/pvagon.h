// pvagon.h - Klasa putni�kih vagona.

#ifndef _pvagon_h_
#define _pvagon_h_

#include "vozilo2.h"
#include <iostream>
#include <utility>
using namespace std;

namespace Vozovi1 {
  class G_previse_putnika {};      // KLASA GRE�AKA: Previ�e putnika.
  inline ostream& operator<<(ostream& it, const G_previse_putnika&)
    { return it << "*** Previse putnika! ***"; }

  class P_vagon: public Vozilo {   // KLASA PUTNI�KIH VAGONA:
    static float sr_tez_put;         // Srednja te�ina putnika.
    int kap, br_put;                // Kapac. vagona i trenutni broj putn.
    void pisi(ostream& it) const override { // Pisanje vagona.
      Vozilo::pisi(it); it << '(' << br_put << ','
                           << br_put*sr_tez_put << ')';
    }
  public:
    static const char VR = 'P';              // Oznaka za putni�ke vagone.
    static void post_sr_tez_put(float stp)   // Postavljanje sr. te�. putn.
      { sr_tez_put = stp; }
    static float dohv_sr_tez_put()           // Dohvatanje sr. te�. putn.
      { return sr_tez_put; }
    P_vagon(float sop_tez, int k=50): Vozilo(sop_tez)   // Konstruktor.
      { kap = k; br_put = 0; }
    char vrsta() const override { return VR; }          // Oznaka vrste.
    float uk_tezina() const override                    // Ukupna te�ina.
      { return sop_tezina() + br_put*sr_tez_put; }
    P_vagon* kopija() const& override        // Kopija vagona kopiranjem.
      { return new P_vagon(*this); }
    P_vagon* kopija() && override            // Kopija vagona preme�tanjem.
      { return new P_vagon(move(*this)); }
    P_vagon& ulazePutnici(int broj) {        // Ulazak putnika.
      if (br_put+broj > kap) throw G_previse_putnika();
      br_put += broj; return *this;
    }
    P_vagon& izlazePutnici(int broj) {       // Izlazak putnika.
      br_put = (broj <= br_put) ? br_put-broj : 0;
      return *this;
    }
  }; // class
} // namespace

#endif

