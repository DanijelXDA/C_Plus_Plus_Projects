// voz2.C - Metode i funkcije uz klasu vozova.

#include "voz2.h"

bool Voz::preopt(Vozilo* v) const {           // Da li bi se preopteretio?
  double teret = 0, snaga = 0;
  for (int i=0; i<vozila.duzina(); i++) {
    teret += vozila[i].uk_tezina();
    snaga += vozila[i].vucna_sila();
  }
  return teret + v->uk_tezina() > snaga + v->vucna_sila();
}

ostream& operator<<(ostream& it, const Voz& v) { // Pisanje voza.
  for (int i=0; i<v.vozila.duzina(); i++) it << v.vozila[i] << endl;
  return it;
}

