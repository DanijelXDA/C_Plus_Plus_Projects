// vagon.h - Klasa vagona.

#ifndef _vagon_h_
#define _vagon_h_

#include "vozilo4.h"
#include "niz6.h"
#include "teret.h"

class Vagon: public Vozilo {
  Niz<Teret> tereti;                                // Niz tereta.
  void pisi(ostream& it) const override;            // Pisanje vagona.
public:
  Vagon(double st, int k): Vozilo(st), tereti(k) {} // Stvaranje.
  Vagon& operator+=(Teret* t)           // Preuzimanje tereta po adresi.
    { tereti += t; return *this; }
  double uk_tezina() const override;                // Ukupna te�ina vagona.
  double vucna_sila() const override { return 0; }  // Vu�na sila.
};

#endif

