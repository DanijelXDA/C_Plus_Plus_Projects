// osoba3.h - Klasa osoba.

#ifndef _osoba3_h_
#define _osoba3_h_

#include <string>
#include <iostream>
using namespace std;

class Osoba {
  string ime;                                     // Ime osobe.
  float tez;                                      // Tezina osobe.
public:                                          
  explicit Osoba(string iime, float ttez)         // Konstruktor. 
    { ime = iime; tez = ttez; }
  Osoba(const Osoba&) =delete;                    // Ne sme da se kopira.
  Osoba& operator=(const Osoba&) =delete;         // Ne sme da se dodeljuje.
  string dohv_ime() const { return ime; }         // Dohvatanje imena.
  float dohv_tez() const { return tez; }          // Dohvatanje tezine.
  friend ostream& operator<<(ostream& it, const Osoba& osoba) // Pisanje.
    { return it << osoba.ime << '(' << osoba.tez << ')'; }
};

#endif

