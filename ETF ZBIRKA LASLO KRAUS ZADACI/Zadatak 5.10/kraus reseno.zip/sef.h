// sef.h - Klasa sefova.

#ifndef _sef_h_
#define _sef_h_

#include "radnik2.h"
#include "firmagr.h"

namespace Trgovina {
  class Sef: public Radnik {
    Radnik** podredjeni;        // Niz podredjenih radnika.
    int max_pot, br_pot;        // Najveci i trenutni broj podredjenih.
  public:
    Sef(string ime, double procenat, int k=3): // Inicijalizacija.
        Radnik(ime, procenat) {
      podredjeni = new Radnik* [max_pot = k];
      br_pot = 0;
    }
    ~Sef() { delete [] podredjeni; }          // Destruktor.
    Sef& dodeli(Radnik* r) {                  // Dodeljivanje podredjenog.
      if (br_pot == max_pot) throw G_previse();
      podredjeni[br_pot++] = r;
      return *this;
    }
    double prihod() const override;           // Ostvareni prihod.
  }; // class
} // namespace

#endif

