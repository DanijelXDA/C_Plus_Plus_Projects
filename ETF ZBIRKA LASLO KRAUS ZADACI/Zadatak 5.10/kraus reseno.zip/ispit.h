// ispit.h - Klasa ispita.

#ifndef _ispit_h_
#define _ispit_h_

class Ispit {
  char sif;                               // sifra ispita.
  short oce;                              // Ocena.
  Datum pol;                              // Datum polaganja.
public:
  Ispit(char si, short oc, Datum po)      // Konstruktor.
    { sif = si; oce = oc; pol = po; }
  Ispit(const Ispit&) =delete;            // Ne sme da se kopira.
  Ispit& operator=(const Ispit&) =delete; // Ne sme da se dodeljuje.
  char  dohvSif() const { return sif; }   // Dohvatanje sifre.
  short dohvOce() const { return oce; }   // Dohvatanje ocene.
  Datum dohvPol() const { return pol; }   // Dohvatanje datuma polaganja.
};

#endif

