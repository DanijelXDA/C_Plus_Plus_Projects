// zbirfun.C - Metode klase zbirova funkcija.

#include "zbirfun.h"

namespace Izvodi {
  void Zbir_fun::pisi(ostream& it) const {     // Pisanje zbira funkcija.
    for (int i=0; i<duz; i++) {
      if (i) it << '+';
      it << '(' << *niz[i] << ')';
    }
  }

  void Zbir_fun::kopiraj(const Zbir_fun& zf) { // Kopiranje u zbir funkcija.
    niz = new Fun* [kap = zf.kap];
    duz = zf.duz;
    for (int i=0; i<duz; i++) niz[i] = zf.niz[i]->kopija();
  }
 
  void Zbir_fun::brisi() {                     // Osloba�anje memorije.
    for (int i=0; i<duz; delete niz[i++]);
    delete [] niz;
  }

  double Zbir_fun::operator()(double x) const {// Vrednost zbira funkcija.
    double s = 0;
    for (int i=0; i<duz; s+=(*niz[i++])(x));
    return s;
  }

  Delegat Zbir_fun::izvod() const {            // Izvod zbira funkcija.
    Zbir_fun* zf = new Zbir_fun(kap);
    for (int i=0; i<duz; *zf += niz[i++]->izvod());
    return Delegat(zf);
  }
} // namespace Izvodi

