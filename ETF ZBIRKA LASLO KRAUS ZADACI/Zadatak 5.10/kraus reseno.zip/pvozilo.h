// pvozilo.h - Klasa putnickih vozila.

#ifndef _pvozilo_h_
#define _pvozilo_h_

#include "vozilo1.h"

class P_vozilo: public Vozilo {
  const Osoba** osobe;                              // Niz osoba.
  int kap;                                          // Kapacitet vozila.
public:
  P_vozilo(const Osoba* vozac, float sop_tez, int k);  // Konstruktor.
  ~P_vozilo() { delete [] osobe; }                  // Destruktor.
  char vrsta() const override { return 'P'; }       // Oznaka vrste vozila.
  bool operator+=(const Osoba* putnik);             // Ulazak putnika.
  bool operator-=(const Osoba* putnik);             // Izlazak putnika.
  float tezina() const override;                    // Ukupna tezina vozila.
private:
  void pisi(ostream& it) const override;            // Pisanje vozila.
};

#endif

