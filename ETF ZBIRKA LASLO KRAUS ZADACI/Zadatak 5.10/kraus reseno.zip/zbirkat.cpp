// zbirkat.C - Ispitivanje klasa zbirki.

#include "niz3.h"
#include "ceo.h"
#include <iostream>
using namespace Zbirke;
using namespace std;

int main() {
  Niz niz(20); cout << "Niz? ";
  while (true) {
    int k; cin >> k;
  if (k == 9999) break;
    niz += Ceo(k);
  }

  int s = 0;
  for (Predmet* pp: niz) s += ((Ceo*)pp)->vredn();
  cout << niz << " = " << s << endl;
  while (true) {
    int i; cout << "Indeks? "; cin >> i;
  if (i == 9999) break;
    try {
      cout << "id=" << niz[i]->id_br() <<
            ", vr=" << *niz[i] << endl;
    } catch (G_indeks g) { cout << g << endl; }
  }
}

