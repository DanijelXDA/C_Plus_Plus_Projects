// integ.C - Definicija funkcije za ra�unanje odre�enog integrala.

#include "integ.h"

double Funkcije::integral(const Fun& f, double a, double b) {
  const int BR_INTERVALA = 30;
  try {                                        // Poku�aj ta�nog ra�unanja.
    return f.I(b) - f.I(a);
  } catch (G_nema_int) {                       // Pribli�no ra�unanje.
    double dx = (b - a) / BR_INTERVALA, s = 0;
    for (int i=0; i<BR_INTERVALA; i++) s += f(a+i*dx);
    return s * dx;
  }
}

