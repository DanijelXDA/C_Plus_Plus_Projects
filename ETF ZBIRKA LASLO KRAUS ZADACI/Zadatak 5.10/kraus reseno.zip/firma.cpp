// firma.C - Metode i funkcije uz klasu firmi.

#include "prodavac.h"
#include "firma.h"
#include <typeinfo>
using namespace std;

namespace Trgovina {
  Firma::Firma(double mar, int k) {           // Inicijalizacija.
    marza = mar;
    radnici = new Radnik* [kap = k];
    for (int i=0; i<kap; radnici[i++]=nullptr);
  }

  Firma::~Firma() {                           // Destruktor.
    for (int i=0; i<kap; delete radnici[i++]);
    delete [] radnici;
  }

  Firma& Firma::zaposli(Radnik* r) {          // Zaposljavanje.
    int i=0; while (i<kap && radnici[i]) i++;
    if (i == kap) throw G_previse();
    radnici[i] = r;
    return *this;
  }

  double Firma::dobit() const {               // Dobit firme.
    double d = 0, p = 0;
    for (int i=0; i<kap; i++)
      if (radnici[i]) {
        if (typeid(*radnici[i]) == typeid(Prodavac))
          d += radnici[i]->prihod();
        p += radnici[i]->plata();
      }
    return d * marza / 100 - p;
  }

  ostream& operator<<(ostream& it, const Firma& fir) { // Pisanje.
    for (int i=0; i<fir.kap; i++)
      if (fir.radnici[i])
        it << *fir.radnici[i] << endl;
    return it << "Dobit firme: " << fir.dobit() << endl;
  }
} // namespace

