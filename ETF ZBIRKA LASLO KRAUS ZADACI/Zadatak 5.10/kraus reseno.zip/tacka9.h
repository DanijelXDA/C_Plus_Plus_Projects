// tacka9.h - Klasa ta�aka u ravni.

#ifndef _tacka9_h_
#define _tacka9_h_

#include <cmath>
using namespace std;

namespace Figure {
  class Tacka {
    double xx, yy;                                  // Koordinate ta�ke.
  public:
    Tacka(double x=0, double y=0)                   // Konstruktor.
      { xx = x; yy = y; }
    double x() const { return xx; }                 // Apscisa ta�ke.
    double y() const { return yy; }                 // Ordinata ta�ke.
    double rastojanje(Tacka t=Tacka()) const {      // Rastojanje do
      return sqrt(pow(xx-t.xx,2) + pow(yy-t.yy,2)); //   zadate ta�ke.
    }
  }; // class Tacka
} // namespace Figure

#endif

