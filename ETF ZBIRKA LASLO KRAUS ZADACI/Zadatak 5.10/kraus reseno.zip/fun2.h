// fun2.h - Apstraktna klasa funkcija.

#ifndef _fun_h_
#define _fun_h_

#include "greska.h"
using Usluge::Greska;

namespace Funkcije {
  class G_nema_int: public Greska {                   // KLASA GRE�AKA:
  public:
    G_nema_int(): Greska("Funkcija nema integral") {} // Konstruktor.
  }; // class G_nema_int

  class Fun {                                      // KLASA FUNKCIJA:
  public:
    virtual ~Fun() {}                              // Virtuelan destr.
    virtual double operator()(double x) const =0;  // Ra�unanje funkcije.
    virtual double I(double x) const               // Ra�unanje integrala.
      { throw G_nema_int(); }
  }; // class Fun
} // namespace Funkcije

#endif

