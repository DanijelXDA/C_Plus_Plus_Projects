// prosta.h - Klasa prostih naredbi.

#ifndef _prosta_h_
#define _prosta_h_

#include "naredba.h"
#include "izraz.h"
using namespace Izrazi;

namespace Naredbe {
  class Prosta: public Naredba {
    Izraz* izr;                                 // Izraz koji se izra�unava.
    void kopiraj(const Prosta& p)               // Kopiranje u objekat.
      { izr = p.izr ? p.izr->kopija() : nullptr; }
    void brisi() { delete izr; }                // Osloba�anje memorije.
    void pisi(ostream& it) const override {     // Pisanje proste naredbe.
      Naredba::pisi(it);
      if (izr) it << *izr;
      it << ";\n";
    }
 
  public:
    Prosta() { izr = nullptr; }                 // Prazna naredba.
    Prosta(const Izraz& i) { izr = i.kopija(); }// Inic. izrazom.
    Prosta(const Prosta& p) { kopiraj(p); }     // Kopiraju�i konstruktor.
    ~Prosta() { brisi(); }                      // Uni�tavanje proste nar.
    Prosta& operator=(const Prosta& p) {        // Kopiraju�a dodela
      if (this != &p) { brisi(); kopiraj(p); }  //    vrednosti.
      return *this;
    }
    void izvrsi() const override { if (izr) izr->vredn(); } // Izvr�avanje.
    Prosta* kopija() const override{ return new Prosta(*this); } // Kopija. 
  }; // class Prosta
} // namespace Naredbe

#endif
