// gradovi2.C - Uredivanje imena gradova smestenih u dinamicki niz niski (u stilu C++).

#include <string>
#include <iostream>
using namespace std;

const int MAX_GRAD = 100;

int main() {

  // Citanje i obrada pojedinacnih imena:
  cout << "\nNeuredjeni niz imena gradova:\n\n";
  string* gradovi = new string [MAX_GRAD];
  int  br_grad=0;
  do {
    string grad;
    getline(cin, grad);              // Citanje sledeceg imena.

  // Kraj ako je prazan red:
  if (grad == "") break;

    cout << grad << endl;            // Ispisivanje imena.

    // Uvrstavanje novog imena u uredjeni niz starih imena:
    int i;
    for (i=br_grad-1; i>=0; i--)
      if (gradovi[i] > grad)
        gradovi[i+1] = gradovi[i];
      else break;
    gradovi[i+1] = grad;

    // Nastavak rada ako ima jos slobodnih mesta u nizu:
  } while (++br_grad < MAX_GRAD);

  // Skracivanje niza:
  string* pom = new string [br_grad];
  for (int i=0; i<br_grad; i++)
    pom[i] = gradovi[i];
  delete [] gradovi; gradovi = pom;

  // Ispisivanje uredjenog niza imena:
  cout << "\nUredjeni niz imena gradova:\n\n";
  for (int i=0; i<br_grad; cout<<gradovi[i++]<<endl);

  // Unistavanje niza.
  delete [] gradovi;
}
