// racmatrt.C - Ispitivanje klase matrica racionalnih brojeva.

#include "racmatr.h"
using namespace Aritmetika;
#include <iostream>
#include <iomanip>
using namespace std;

int main() {
  while (true) {
    try {
      cout << "\nm,n? "; int m, n; cin >> m >> n;
  if (m<=0 || n<=0) break;
      Rac_matr a(m, n); cout << "Matrica? "; cin >> a;
      cout << "\nMatrica:\n"       << setw(7) << a;
      cout << "\nInverzna:\n"      << setw(7) << inv(a);
      cout << "\nA * inv(A):\n"    << setw(7) << a * inv(a);
      cout << "\nDterminanta: "    << det(a)  << endl;
      cout << "\nTransponovana:\n" << setw(7) << T(a);
      cout << "\nA + T(A):\n"      << setw(7) << a + T(a);
    } catch (G_rac_mat_ind) { cout << "\nGreska: Indeks izvan opsega.\n";
    } catch (G_rac_mat_dim) { cout << "\nGreska: Neusaglasene dimenzije.\n";
    } catch (G_rac_mat_inv) {
                      cout << "\nGreska: Ne postoji inverzna matrica.\n";
    } catch (G_rac_mat_kvd) { cout << "\nGreska: Matrica nije kvadratna.\n";
    } catch (G_rac_broj  ) { cout << "\nGreska: Imenilac jednak nuli.\n";
    }
  }
}
