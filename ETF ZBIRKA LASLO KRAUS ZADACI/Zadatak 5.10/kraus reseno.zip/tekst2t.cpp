// tekst2t.C - Ispitivanje stedljive klase tekstova.

#include "tekst2.h"
#include <iostream>
using namespace std;

int main() {
  struct Elem { Tekst tekst; Elem* sled; };
  Elem *prvi = nullptr, *posl = nullptr, *novi;
  Tekst t;
  while (true) {
    cin >> t;
  if (!cin) break;
    novi = new Elem; novi->tekst = t; novi->sled = nullptr;
    posl = (!prvi ? prvi : posl->sled) = novi;
  }
  Tekst::spisak();
}

