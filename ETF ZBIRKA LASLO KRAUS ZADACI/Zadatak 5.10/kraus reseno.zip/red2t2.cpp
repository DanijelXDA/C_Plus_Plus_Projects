// red2t2.C - Inicijalizacija reda premestanjem drugog reda.

#include "red2.h"

Red f(Red r) { return r; }

int main() { Red rd = f(Red()); }
