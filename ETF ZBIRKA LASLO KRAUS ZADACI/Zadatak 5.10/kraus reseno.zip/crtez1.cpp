// crtez1.C - Metode klase crteza.

#include "crtez1.h"

// Kopiranje crte�a.
void Figure::Crtez::kopiraj
    (const Crtez& crt) {
  for (int i=0; i<crt.figure.vel(); i++)
    figure.dodaj(crt.figure[i]->kopija());
}

// Uni�tavanje crte�a.
void Figure::Crtez::brisi() {
  for (int i=0; i<figure.vel();
       delete figure[i++]);
  figure.isprazni();
}

// Boja ta�ke.
Figure::Boja Figure::Crtez::boja(const Tacka& T) const {
  if (!pripada(T)) throw G_ne_pripada();
  Tacka T1(T.x()-A.x(), T.y()-A.y());
  for (int i=figure.vel()-1; i>=0; i--)
    try { return figure[i]->boja(T1); } catch (G_ne_pripada) {}
  return Figura::boja();
}

