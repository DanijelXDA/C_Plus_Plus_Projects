// pvagon.C - Stati�ko polje klase putni�kih vagona.

#include "pvagon.h"

float Vozovi1::P_vagon::sr_tez_put = 70; // Srednja te�ina putnika.

