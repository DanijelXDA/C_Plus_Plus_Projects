// sklop.h - Klasa sklopova predmeta.

#ifndef _sklop_h_
#define _sklop_h_

#include "predmet3.h"
#include <vector>
#include <utility>
using namespace std;

namespace Predmeti {
  class Sklop: public Predmet {
    vector<Predmet*> niz;                // Sadr�ani predmeti.
    void kopiraj(const Sklop&);          // Kopiranje u sklop.
    void brisi();                        // Osloba�anje memorije.
    void pisi(ostream&) const override;  // Pisanje sklopa.
  public:                                // Inicijalizacija:
    Sklop() {}                           // - kao prazan sklop,
    Sklop(const Sklop& s)                // - kopiranjem drugog sklopa,
      : Predmet(s) { kopiraj(s); }
    Sklop(Sklop&& s) =default;           // - preme�tanjem drugog sklopa,
    Sklop(const Predmet& p)              // - kopiranjem predmeta,
      : Predmet() { niz.push_back(p.kopija()); }
    Sklop(Predmet* p)                    // - preuzimanjem predmeta.
      : Predmet() { niz.push_back(p); }
    ~Sklop() { brisi(); }                // Uni�tavanje.
    Sklop& operator=(const Sklop& s) {   // Dodela vrednosti kopiranjem.
      if (this != &s) { brisi(); Predmet::operator=(s); kopiraj(s); }
      return *this;
    }
    Sklop& operator=(Sklop&& s) =default;// Dodela vrednosti preme�tanjem.
    Sklop& operator+=(const Predmet& p)  // Dodavanje predmeta kopiranjem.
      { niz.push_back(p.kopija()); return *this; }
    Sklop& operator+=(Predmet&& p)       // Dodavanje predmeta preme�tanjem.
      { niz.push_back(move(p).kopija()); return *this; }
    Sklop& operator+=(Predmet* p)        // Dodavanje predmeta preuzimanjem.
      { niz.push_back(p); return *this; }
    Sklop* kopija() const& override      // Kopija sklopa kopiranjem.
      { return new Sklop(*this); }
    Sklop* kopija() && override          // Kopija sklopa preme�tanjem.
      { return new Sklop(move(*this)); }
    double V() const override;           // Zapremina sklopa.
    double Q() const override;           // Te�ina sklopa.
    string vrsta() const override { return "Sklop"; } // Vrsta predmeta.
  }; // class Sklop
} // namespace Predmeti

#endif

