// predmet2.h - Apstraktna klasa predmeta.

#ifndef _predmet2_h_
#define _predmet2_h_

#include <iostream>
using namespace std;

namespace Zbirke {
  class Predmet {
    static int pos_id;                     // Poslednji identifikator.
    int id = ++pos_id;                     // Identifikator predmeta.
  public:
    Predmet() =default;                    // Nov predmet dobija nov broj.
    Predmet(const Predmet&) {}             // Kopija dobija nov broj.
    virtual ~Predmet() {}                  // Virtuelan destruktor.
    Predmet& operator=(const Predmet&)     // Levom operandu se
      { return *this; }                    //   ne menja broj.
    int id_br() const { return id; }       // Identifikator predmeta.
    virtual Predmet* kopija() const& =0;   // Kopija predmeta kopiranjem.
    virtual Predmet* kopija() && =0;       // Kopija predmeta preme�tanjem.
  private:
    virtual void pisi(ostream& it) const =0; // Pisanje predmeta.
    friend ostream& operator<<(ostream& it, const Predmet& p)
      { p.pisi(it); return it; }
  };
} // namespace

#endif

