// voz1.h - Klasa vozova.

#ifndef _voz1_h_
#define _voz1_h_

#include "vozilo2.h"
#include "lokomot1.h"
#include "pvagon.h"
#include <iostream>
#include <string>
using namespace std;

namespace Vozovi1 {
  class G_ima_lok {};   // KLASA GRE�AKA: Ve� postoji lokomotiva.
  inline ostream& operator<<(ostream& it, const G_ima_lok)
    { return it << "*** Vec ima lokomotive! ***"; }

  class G_nema_lok {};  // KLASA GRE�AKA: Jo� nema lokomotive.
  inline ostream& operator<<(ostream& it, const G_nema_lok)
    { return it << "*** Jos nema lokomotive! ***"; }

  class G_tezak_voz {}; // KLASA GRE�AKA: Lokomotiva je preoptere�ena.
  inline ostream& operator<<(ostream& it, const G_tezak_voz)
    { return it << "*** Pretezak voz! ***"; }

  class Voz {                             // KLASA VOZOVA:
    string ime;                           // Ime voza.
    struct Elem {                         // Element liste vozila.
      Vozilo* vozilo; Elem* sled;
      Elem(Vozilo* v) { vozilo = v; sled = 0; }
      ~Elem(){ delete vozilo; }
    };
    Elem *prvi, *posl;                    // Prvi i poslednji element liste.
    void kopiraj(const Voz& v);           // Kopiranje u objekat.
    void premesti(Voz& v) {               // Preme�tanje u objekat.
      ime = v.ime; prvi = v.prvi; posl = v.posl;
      v.prvi = v.posl = nullptr;
    }
    void brisi();                         // Osloba�anje memorije.
  public:
    Voz(const char* im)                      // Inicijalizacija.
      { prvi = posl = nullptr; ime = im; }
    Voz(const Voz& v) { kopiraj(v); }        // Kopiraju�i konstruktor.
    Voz(Voz&& v) { premesti(v); }            // Preme�taju�i konstruktor.
    ~Voz() { brisi(); }                      // Destruktor.
    Voz& operator=(const Voz& v) {           // Kopiraju�a dodela vrednosti.
      if (this != &v) { brisi(); kopiraj(v); }
      return *this;
    }
    Voz& operator=(Voz&& v) {                // Preme�taju�a dodela vredn.
      if (this != &v) { brisi(); premesti(v); }
      return *this;
    }
    Voz& operator+=(const Lokomot& lok);     // Dodavanje lokomotive.
    Voz& operator+=(Lokomot&& lok);
    Voz& operator+=(const P_vagon& pvag);    // Dodavanje putni�kog vagona.
    Voz& operator+=(P_vagon&& pvag);
    float uk_tez_voza() const;               // Ukupna te�ina voza.
    friend ostream& operator<<(ostream& it,const Voz& v); // Pisanje voza.
  }; // class
} // namespace
#endif

