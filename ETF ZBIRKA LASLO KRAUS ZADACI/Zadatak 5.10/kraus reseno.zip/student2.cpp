// student2.C - Metoda klase studenata.

#include "student2.h"

double Student::sr_ocena() const {      // Srednja ocena.
  double s = 0; int k = 0;
  for (int i=0; i<n; i++)
    if (ocene[i] > 5) { s += ocene[i]; k++; }
  if (k) s /= k;
  return s;
}

