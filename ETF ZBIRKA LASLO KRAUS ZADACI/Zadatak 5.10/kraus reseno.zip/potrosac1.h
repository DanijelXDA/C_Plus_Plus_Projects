// potrosac1.h - Klasa elektri�nih potro�a�a.

#ifndef _potrosac1_h_
#define _potrosac1_h_

#include <iostream>
using namespace std;

namespace Potrosaci {
  class Potrosac {
  public:
    virtual ~Potrosac() {}                // Virtuelan destruktor.
    virtual double snaga() const =0;      // Snaga potro�a�a.
    virtual Potrosac* kopija() const& =0; // Kopija potro�a�a kopiranjem.
    virtual Potrosac* kopija() && =0;     // Kopija potro�a�a preme�tanjem.
  private:
    virtual void pisi(ostream& it) const =0; // Pisanje potro�a�a.
    friend ostream& operator<<(ostream& it, const Potrosac& p)
      { p.pisi(it); return it; }
  }; // class
} // namespace

#endif

