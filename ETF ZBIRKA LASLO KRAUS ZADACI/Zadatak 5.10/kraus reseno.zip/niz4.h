// niz4.h - Generi�ka klasa nizova.

#ifndef _niz4_h_
#define _niz4_h_

#include <iostream>
using namespace std;

class G_indeks {};          // KLASA GRE�AKA: Nedozvoljen indeks.
inline ostream& operator<<(ostream& it, const G_indeks&)
  { return it << "*** Nedozvoljen indeks! ***"; }

class G_prazan {};          // KLASA GRE�AKA: Niz je prazan.
inline ostream& operator<<(ostream& it, const G_prazan&)
  { return it << "*** Niz je prazan! ***"; }

template <typename T>                          // GENERI�KA KLASA NIZOVA:
  class Niz {
    T* niz;                                    // Elementi niza.
    int kap, duz;                              // Kapacitet i du�ina niza.
    void kopiraj(const Niz& n);                // Kopiranje u niz.
    void premesti(Niz& n) {                    // Preme�tanje u niz.
      niz = n.niz; n.niz = nullptr;
      kap = n.kap; duz = n.duz;
    }
    void brisi() { delete [] niz; }            // Osloba�anje memorije.
  public:
    explicit Niz(int k=10)                     // Stvaranje praznog niza.
      { niz = new T [kap = k]; duz = 0; }
    Niz(const Niz& n) { kopiraj(n); }          // Kopiraju�i konstruktor.
    Niz(Niz&& n) { premesti(n); }              // Preme�taju�i konstruktor.
    ~Niz() { delete [] niz; }                  // Destruktor.
    Niz& operator=(const Niz& n) {                    // Kopiraju�a dodela
      if (this != &n) { delete [] niz; kopiraj(n); }  //   vrednosti.
      return *this;
    }
    Niz& operator=(Niz&& n) {                         // Preme�taju�a dodela
      if (this != &n) { delete [] niz; premesti(n); } //   vrednosti.
      return *this;
    }
    int vel() const { return duz; }            // Du�ina niza.
    Niz& dodaj(const T& t);                    // Dodavanje na kraj.
    T uzmi();                                  // Uzimanje s kraja.
    T& operator[](int i) {                     // Dohvatanje elementa
      if (i<0 || i>=duz) throw G_indeks();     // - promenljivog niza,
      return niz[i];
    }
    const T& operator[](int i) const {         // - nepromenljivog niza.
      if (i<0 || i>=duz) throw G_indeks();
      return niz[i];
    }
    Niz& isprazni() { duz = 0; return *this; } // Pra�njenje niza.
  }; // class Niz<T>

template <typename T>                          // METODE KLASE NIZOVA:
  void Niz<T>::kopiraj(const Niz& n) {         // Kopiranje u objekat.
    niz = new T [kap = n.kap];
    duz = n.duz;
    for (int i=0; i<duz; i++)
      niz[i] = n.niz[i];
  }

template <typename T>
  Niz<T>& Niz<T>::dodaj(const T& t) {          // Dodavanje na kraj.
    if (duz == kap) {
      T* pom = new T [kap+=5];
      for (int i=0; i<duz; i++) pom[i] = niz[i];
      delete [] niz; niz = pom;
    }
    niz[duz++] = t;
    return *this;
  }

template <typename T>  
  T Niz<T>::uzmi() {                           // Uzimanje s kraja.
    if (!duz) throw G_prazan();
    T t = niz[--duz];
    if (kap-duz>10) {
      T* pom = new T [kap-=5];
      for (int i=0; i<duz; i++) pom[i] = niz[i];
      delete [] niz; niz = pom;
    }
    return t;
  }

#endif

