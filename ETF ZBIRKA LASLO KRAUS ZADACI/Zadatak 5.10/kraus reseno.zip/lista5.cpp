// lista5.C - Metode i funkcije uz klasu neuredjenih listi.

#include "lista5.h"

void N_lista::kopiraj(const N_lista& lst) {        // Kopiranje druge liste.
  prvi = posl = nullptr; duz = 0;
  for (Elem* tek=lst.prvi; tek; tek=tek->sled) *this += tek->broj;
}

void N_lista::brisi() {                            // Praznjenje liste.
  while (prvi) { Elem* stari = prvi; prvi = prvi->sled; delete stari; }
  posl = nullptr; duz = 0;
}

N_lista& N_lista::operator+=(const N_lista& lst) { // Dodavanje liste.
  if (this != &lst)
    for (Elem* tek=lst.prvi; tek; tek=tek->sled) *this += tek->broj;
  else 
    *this += N_lista(lst);   // lst += lst
  return *this;
}

ostream& operator<<(ostream& it, const N_lista& lst) { // Pisanje.
  it << '(';
  for (N_lista::Elem* tek=lst.prvi; tek; tek=tek->sled)
    { it << tek->broj; if (tek->sled) it << ','; }
  return it << ')';
}

