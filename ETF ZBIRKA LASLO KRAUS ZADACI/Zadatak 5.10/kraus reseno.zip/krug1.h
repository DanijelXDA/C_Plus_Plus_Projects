// krug1.h - Definicija klase krugova
//           u ravni.

#include "tacka2.h"
#include <cstdlib>
#include <cmath>
#include <iostream>
using namespace std;

class Krug {
  Tacka c; double r;          // Centar i poluprecnik kruga.
  Krug *pret, *sled;          // Pokazivaci na prethodni i na sledeci krug.
  static Krug* prvi;          // Pocetak zajednicke liste svih krugova.
  Krug() { r = -1; }          // Stvaranje "praznog" kruga:
                              //   - SAMO za interne potrebe!
  Krug(const Krug&) =delete;  // Kpirajuci konstruktor:
                              //   - NE SME da se pravi kopija!
public:
  static bool moze(double r, double x, double y); // Moze li postojati?
  Krug(double rr, double x, double y);            // Stvaranje kruga.
  ~Krug();                                        // Unistavanje kruga.
  friend double rastojanje(const Krug& k1, const Krug& k2);
                                                  // Rastojanje dva kruga.
  bool premesti(double  x, double  y);            // Premestanje kruga.
  bool pomeri  (double dx, double dy);            // Pomeranje kruga.
  void pisi() const;                              // Pisanje kruga.
  static void pisiSve();                          // Pisanje svih krugova.
};

// Definicije ugradjenih funkcija izvan klase.

inline double rastojanje(const Krug& k1, const Krug& k2)
  { return k1.c.rastojanje(k2.c) - k1.r - k2.r; } // Rastojanje dva kruga.

inline void Krug::pisi() const                    // Pisanje kruga.
  { cout << "K[" << r << ','; c.pisi(); cout << ']'; }
