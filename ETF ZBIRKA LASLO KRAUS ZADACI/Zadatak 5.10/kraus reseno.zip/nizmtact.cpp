// nizmtact.C - Ispitivanje klase nizova materijalnih tacaka.

#include "nizmtac.h"
#include <iostream>
using namespace std;

int main() {
  while (true) {
    Niz_mat_tac niz;
    while (true) {
      cout << "m,x,y,z? "; double m, x, y, z; cin >> m >> x >> y >> z;
    if (m < 0) break;
      niz.dodaj(Mat_tacka(m,x,y,z));
    }
  if (niz.vel() == 0) break;
    cout << "Niz tacaka:\n"; niz.pisi();
    cout << "Najvise privlaci: ";
    niz.max_F(Mat_tacka()).pisi(); cout << endl;
  }
}
