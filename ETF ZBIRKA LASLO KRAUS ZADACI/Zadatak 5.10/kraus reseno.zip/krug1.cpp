// krug1.C - Definicije metoda i statickih polja klase krugova.

#include "krug1.h"

Krug* Krug::prvi = nullptr;                    // Pocetak zajednicke liste.

bool Krug::moze(double r, double x, double y){ // Moze li postojati?
  Krug k; k.r = r; k.c.postavi(x, y);
  Krug* tek = prvi;
  while (tek && rastojanje(k,*tek)>=0) tek=tek->sled;
  k.r = -1;
  return tek == nullptr;
}

Krug::Krug(double rr, double x, double y) {   // Stvaranje kruga.
  if (!moze(rr, x, y)) exit(1);
  r = rr; c.postavi(x, y);
  sled = prvi; pret = nullptr;
  if (prvi) prvi->pret = this;
  prvi = this;
}

Krug::~Krug() {         // Unistavanje kruga (izbacivanje iz liste).
  if (r > 0) {
    if (pret) pret->sled = sled;
      else prvi = sled;
    if (sled) sled->pret = pret;
  }
}

bool Krug::premesti(double x, double y) {     // Premestanje kruga.
  if (!moze(r, x, y)) return false;
  c.postavi(x, y);
  return true;
}

bool Krug::pomeri(double dx, double dy) {     // Pomeranje kruga.
  if (!moze(r, c.aps()+dx, c.ord()+dy)) return false;
  c.postavi(c.aps()+dx, c.ord()+dy);
  return true;
}

void Krug::pisiSve() {                        // Pisanje svih krugova.
  cout << "\nSvi krugovi u memoriji:\n";
  for (Krug* tek=prvi; tek; tek=tek->sled)
    { tek->pisi(); cout << endl; }
}
