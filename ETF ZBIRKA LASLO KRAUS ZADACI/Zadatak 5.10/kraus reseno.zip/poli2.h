// poli2.h - Klasa polinoma.

#ifndef _poli2_h_
#define _poli2_h_

#include "fun2.h"
#include "vektor2.h"

namespace Funkcije {
  class Poli: public Fun {
    Vekt a;                                    // Vektor koeficijenata.
  public:
    Poli(): a(0, 5) {}                         // Konstruktori.
    explicit Poli(int n): a(0, n) {}
    double& operator[](int i) { return a[i]; } // Dohvatanje koeficijenta.
    double  operator[](int i) const { return a[i]; }
    int red() const { return a.maxInd(); }     // Red polinoma.
    double operator()(double x) const;         // Vrednost polinoma.
    double I(double x) const;                  // Vrednost integrala.
  }; // class Poli
} // namespace Funkcije

#endif

