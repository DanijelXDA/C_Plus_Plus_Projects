// voz2.h - Klasa vozova.

#ifndef _voz2_h_
#define _voz2_h_

#include "niz6.h"
#include "vozilo4.h"
#include <iostream>
using namespace std;

class G_preopt {};             // KLASA GRE�AKA: Voz je preoptere�en.
inline ostream& operator<<(ostream& it, const G_preopt&)
  { return it << "*** Voz je preopterecen! ***"; }

class Voz {                             // KLASA VOZOVA:
  Niz<Vozilo> vozila;                   // Niz vozila.
public:
  explicit Voz(int k): vozila(k) {}     // Stvaranje praznog voza.
  Voz(const Voz&) =delete;              // Ne sme da se kopira.
  Voz& operator=(const Voz&) =delete;   // Ne sme da se dodeljuje.
  int duzina() const                    // Du�ina voza.
    { return vozila.duzina(); }
  bool preopt(Vozilo* v) const;         // Da li bi se preopteretio?
  Voz& operator+=(Vozilo* v) {          // Preuzimanje vozila po adresi.
    if (preopt(v)) throw G_preopt();
    vozila += v;
    return *this;
  }
  friend ostream& operator<<(ostream& it, const Voz& v); // Pisanje voza.
};

#endif

