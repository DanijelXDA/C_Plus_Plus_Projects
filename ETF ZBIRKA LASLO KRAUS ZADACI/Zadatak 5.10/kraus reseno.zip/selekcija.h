// selekcija.h - Klasa selekcija.

#ifndef _selekcija_h_
#define _selekcija_h_

#include "izraz.h"
using namespace Izrazi;
#include "naredba.h"

namespace Naredbe {
  class Selekcija: public Naredba {
    Izraz* usl;                             // Uslov selekcije.
    Naredba *nar1, *nar2;                   // Uslovno izvr�avane naredbe.
    void kopiraj(const Selekcija& s) {      // Kopiranje u selekciju.
      usl  = s.usl ->kopija();
      nar1 = s.nar1->kopija();
      nar2 = s.nar2->kopija();
    }
    void brisi()                            // Osloba�anje memorije.
      { delete usl; delete nar1; delete nar2; }
    void pisi(ostream& it) const override { // Pisanje selekcije.
      Naredba::pisi(it); it << "if(" << *usl << ")\n";
      nivo++; it << *nar1; nivo--;
      Naredba::pisi(it); it << "else\n";
      nivo++; it << *nar2; nivo--;
    }
  public:                                          // Inicijalizacija.
    Selekcija(const Izraz& u, const Naredba& n1, const Naredba& n2)
      { usl = u.kopija(); nar1 = n1.kopija(); nar2 = n2.kopija(); }
    Selekcija(const Selekcija& s) { kopiraj(s); } // Kopiraju�i konstruktor.
    ~Selekcija() { brisi(); }                     // Uni�tavanje selekcije.
    Selekcija& operator=(const Selekcija& s) {    // Kopiraju�a dodela
      if (this != &s) { brisi(); kopiraj(s); }    //   vrednosti.
      return *this;
    }
    void izvrsi() const override                  // Izvr�avanje selekcije.
      { if (usl->vredn()) nar1->izvrsi(); else nar2->izvrsi(); }
    Selekcija* kopija() const override            // Kopija selekcije.
      { return new Selekcija(*this); }
  }; // class Selekcija
} // namespace Naredbe

#endif
