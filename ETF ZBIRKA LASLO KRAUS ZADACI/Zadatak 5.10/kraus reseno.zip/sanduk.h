// sanduk.h - Klasa sanduka.

#ifndef _sanduk_h_
#define _sanduk_h_

#include "teret.h"
#include <utility>
using namespace std;

class Sanduk: public Teret {
  double a, b, c;                                // Du�ine ivica kvadra.
public:
  explicit Sanduk(double s=1, double             // Inicijalizacija.
     aa=1, double bb=1, double cc=1):
     Teret(s), a(aa), b(bb), c(cc) {}
  char vrsta() const override { return 'S'; }    // Oznaka vrste tereta.
  double zapr() const override { return a*b*c; } // Zapremina sanduka.
  Sanduk* kopija() const& override           // Kopija sanduka kopiranjem.
    { return new Sanduk(*this); }
  Sanduk* kopija() && override               // Kopija sanduka preme�tanjem.
    { return new Sanduk(move(*this)); }
};

#endif
