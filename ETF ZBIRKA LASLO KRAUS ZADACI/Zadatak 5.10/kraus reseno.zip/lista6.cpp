// lista6.C - Metode klase uredjenih listi celih brojeva.

#include "lista6.h"

U_lista& U_lista::operator+=(int b) {              // Dodavanje broja.
  Elem *tek = prvi, *pret = nullptr;
  while (tek && tek->broj < b) { pret = tek; tek = tek->sled; }
  Elem* novi = new Elem(b, tek);
  (!pret ? prvi : pret->sled) = novi;
  if (!tek) posl = novi;
  duz++;
  return *this;
}

