// imenik2.C - Metode i funkcije uz klasu imenika osoba.

#include "imenik2.h"

Imenik::~Imenik() {                         // Unistavanje imenika.
  for (int i=n; i>0; delete ljudi[--i]);
  delete [] ljudi;
}

Imenik& Imenik::uredi() {                   // Uredjivanje imenika.
  for (int i=0; i<n-1; i++)
    for (int j=i+1; j<n; j++)
      if (*ljudi[j] > *ljudi[i])
        { Osoba* pom = ljudi[i]; ljudi[i] = ljudi[j]; ljudi[j] = pom; }
  return *this;
}

ostream& operator<<(ostream& it, const Imenik& imen) { // Pisanje imenika.
  for (int i=0; i<imen.n; i++) it << *imen.ljudi[i] << endl;
  return it;
}

