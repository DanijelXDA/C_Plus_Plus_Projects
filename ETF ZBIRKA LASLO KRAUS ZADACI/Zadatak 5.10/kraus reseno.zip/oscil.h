// oscil.h - Klasa prigu�enih oscilacija.

#ifndef _oscil_h_
#define _oscil_h_

#include "fun2.h"
#include <cmath>
using namespace std;

namespace Funkcije {
  class Oscil: public Fun {
  public:                                    // Ra�unanje funkcije.
    double operator()(double x) const { return exp(-0.1*x)*sin(x); }
  }; // class Oscil
} // namespace Funkcije

#endif

