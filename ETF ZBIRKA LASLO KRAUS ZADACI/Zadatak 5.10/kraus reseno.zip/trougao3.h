// trougao3.h - Klasa trouglova u ravni.

#include "tacka3.h"
#include <iostream>
using namespace std;

class Trougao {
  Tacka A, B, C;                           // Temena trougla.
public:
  explicit Trougao(                        // Stvaranje trougla.
    const Tacka& AA=Tacka(),
    const Tacka& BB=Tacka(1,0),
    const Tacka& CC=Tacka(0,1)
  ): A(AA), B(BB), C(CC) {}
  Tacka dohv_a() const { return A; }       // Dohvatanje temena.
  Tacka dohv_b() const { return B; }
  Tacka dohv_c() const { return C; }
  double P() const {                       // Racunanje povrsine.
    double a = B-C, b = C-A, c = A-B;
    double s = (a + b + c) / 2;
    return sqrt(s * (s-a) * (s-b) * (s-c));
  }
  bool operator==(const Trougao& t2) const // Da li su podudarni?
    { return A == t2.A && B == t2.B && C == t2.C; }
  bool operator!=(const Trougao& t2) const // Da li su nepodudarni?
    { return !(*this == t2); }
  friend ostream& operator<<(ostream& it, const Trougao& t) // Pisanje.
    { return it << '[' << t.A << ',' << t.B << ',' << t.C << ']'; }
};

