// niz6.h - Generi�ka klasa nizova pokaziva�a na elemente.

#ifndef _niz6_h_
#define _niz6_h_

#include <iostream>
using namespace std;

class G_indeks {};             // KLASA GRE�AKA: Nedozvoljen indeks.
inline ostream& operator<<(ostream& it, const G_indeks&)
  { return it << "*** Nedozvoljen indeks! ***"; }

class G_pun {};                // KLASA GRE�AKA: Niz je pun.
inline ostream& operator<<(ostream& it, const G_pun&)
  { return it << "*** Niz je pun! ***"; }

template <typename T>                    // GENERI�KA KLASA NIZOVA:
class Niz {
  T** niz;                               // Niz pokaziva�a na elemente.
  int kap, duz;                          // Kapacitet i du�ina niza.
  void kopiraj(const Niz& n);            // Kopiranje u niz.
  void premesti(Niz& n) {                // Preme�tanje u niz.
    niz = n.niz; n.niz = nullptr;
    kap = n.kap; duz = n.duz;
  }
  void brisi();                          // Osloba�anje memorije.
public:
  explicit Niz(int k=10)                 // Stvaranje praznog niza.
    { niz = new T* [kap = k]; duz = 0; }
  Niz(const Niz& n) { kopiraj(n); }      // Kopiraju�i konstruktor.
  Niz(Niz&& n) { premsti(n); }           // Preme�taju�i konstruktor.
  ~Niz() { brisi(); }                    // Destruktor.
  Niz& operator=(const Niz& n) {         // Kopiraju�a dodela vrednosti.
    if (this != &n) { brisi(); kopiraj(n); }
    return *this;
  }
  Niz& operator=(Niz&& n) {              // Preme�taju�a dodela vrednosti.
    if (this != &n) { brisi(); premesti(n); }
    return *this;
  }
  int duzina() const { return duz; }     // Du�ina niza.
  Niz& operator+=(T* t) {                // Preuzimanje elementa po adresi.
    if (duz == kap) throw G_pun();
    niz[duz++] = t;
    return *this;
  }
  T& operator[](int i) {                 // Pristup elementu
    if (i<0 || i>=duz) throw G_indeks(); // - promenljivog niza,
    return *niz[i];
  }
  const T& operator[](int i) const {     // - nepromenljivog niza.
    if (i<0 || i>=duz) throw G_indeks();
    return *niz[i];
  }
};

template <typename T>                    // METODE KLASE NIZOVA:
void Niz<T>::kopiraj(const Niz& n) {     // Kopiranje u niz.
  niz = new T* [kap = n.kap];
  duz = n.duz;
  for (int i=0; i<duz; i++) niz[i] = n.niz[i]->kopija();
}

template <typename T>
void Niz<T>::brisi() {                   // Brisanje osloba�anje memorije.
  for (int i=0; i<duz; delete niz[i++]);
  delete [] niz;
}

#endif

