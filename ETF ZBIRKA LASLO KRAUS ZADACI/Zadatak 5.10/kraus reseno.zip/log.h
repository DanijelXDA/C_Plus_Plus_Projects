// log.h - Klasa logaritama.

#ifndef _log_h_
#define _log_h_

#include "fun2.h"
#include <cmath>
using namespace std;
#include "greska.h"
using Usluge::Greska;

namespace Funkcije {
  class G_nema_log: public Greska {          // KLASA GRE�AKA:
    double x;                                // Nedozvoljena vrednost.
  public:                                    // Konstruktori.
    G_nema_log(): Greska("Logaritam negativnog broja") {}
    G_nema_log(double x): Greska() { this->x = x; }
    double dohv_x() const                    // Uzimanje nedozvoljene
      { return imaPoruke() ? 1 : x; }        //   vrednosti.
  private:
    void pisi(ostream& it) const {           // Pisanje poruke.
      if (imaPoruke()) Greska::pisi(it);
      else it << "\n*** Ne postoji logaritam od " << x << " ***\a\n";
    }
  }; // class G_nema_log

  class Log: public Fun {                    // KLASA LOGARITAMA:
  public:
    double operator()(double x) const {      // Ra�unanje funkcije.
      if (x <= 0) throw G_nema_log(x);
      return log(x);
    }
  }; // class Log
} // namespace Funkcije

#endif

