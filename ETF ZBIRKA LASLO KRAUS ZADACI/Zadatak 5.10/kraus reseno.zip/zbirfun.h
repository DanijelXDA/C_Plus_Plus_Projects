// zbirfun.h - Klasa zbirova funkcija.

#ifndef _zbirfun_h_
#define _zbirfun_h_

#include "fun3.h"
#include <cmath>
#include <utility>
using namespace std;

namespace Izvodi {
  class G_zbir_fun_pun {};          // KLASA GRE�AKA: Zbir funkcija je pun.
  inline ostream& operator<<(ostream& it, const G_zbir_fun_pun&)
    { return it << "*** Zbir funkcija je pun! ***\n"; }

  class Zbir_fun: public Fun {      // KLASA ZBIROVA FUNKCIJA:
    Fun** niz;                      // Niz funkcija.
    int kap, duz;                   // Kapacitet i broj popunjenih mesta.
    void pisi(ostream& it) const override;     // Pisanje zbira funkcija.
    void kopiraj(const Zbir_fun&);             // Kopiranje u zbir funkcija.
    void premesti(Zbir_fun zf) {               // Preme�tanje u zbir funkc.
      niz = zf.niz; kap = zf.kap; duz = zf.duz;
      zf.niz = nullptr;
    }
    void brisi();                              // Osloba�anje memorije.
  public:
    explicit Zbir_fun(int n=2)                 // Stvaranje zbira funkcija.
      { niz = new Fun* [kap = n]; duz = 0; }
    Zbir_fun(const Zbir_fun& zf) { kopiraj(zf); } // Kopiraju�i konstruktor.
    Zbir_fun(Zbir_fun&& zf) { premesti(zf); }     // Preme�taju�i konstr.
    ~Zbir_fun() { brisi(); }                      // Uni�tavanje zbira funk.
    Zbir_fun& operator=(const Zbir_fun& zf){      // Kopiraju�a dodela
      if (this != &zf) { brisi(); kopiraj(zf); }  //   vrednosti.
      return *this;
    }
    Zbir_fun& operator=(Zbir_fun&& zf){           // Preme�taju�a dodela
      if (this != &zf) { brisi(); premesti(zf); } //   vrednosti.
      return *this;
    }
    Zbir_fun& operator+=(const Fun& f) {          // Dodavanje funkcije
      if (duz == kap) throw G_zbir_fun_pun();     //   po vrednosti.
      niz[duz++] = f.kopija();
      return *this;
    }
    Zbir_fun& operator+=(Fun* f) {                // Dodavanje funkcije
      if (duz == kap) throw G_zbir_fun_pun();     //   po adresi.
      niz[duz++] = f;
      return *this;
    }
    double operator()(double x) const override;   // Vrednost zbira funkc.
    Delegat izvod() const override;               // Izvod zbira funkcija.
    Zbir_fun* kopija() const& override  // Kopija zbira funkc. kopiranjem.
      { return new Zbir_fun(*this); }
    Zbir_fun* kopija() && override      // Kopija zbira funkc. preme�tanjem.
      { return new Zbir_fun(move(*this)); }
  }; // class Zbir_fun
} // namespace Izvodi

#endif

