// red1.h - Deklaracija paketa za obradu redova celih brojeva.

struct Elem { int broj; Elem* sled; };
struct Red { Elem *prvi, *posl; };

inline Red pravi()                     // Stvaranje praznog reda.
  { Red r; r.prvi = r.posl = nullptr; return r; }
inline bool prazan(const Red& r)       // Da li je prazan?
  { return r.prvi == nullptr; }
void dodaj(Red& r, int b);             // Dodavanje broja na kraj reda.
int uzmi(Red& r);                      // Uzimanje broja s pocetka reda.
int duz(const Red& r);                 // Odredjivanje duzine reda.
void pisi(const Red& r);               // Ispisivanje reda.
void brisi(Red& r);                    // Praznjenje reda.
