// student1.C - Metode klase studenata.

#include "student1.h"
#include <cstring>
#include <cstdlib>
using namespace std;
 
Student::Student(string iime, long iind, int kkap) { // Konstruktor.
  ime = iime;
  ind = iind;
  ocene = new int [kap = kkap];
  br_oc = 0;
}

Student& Student::operator+=(int ocena) {            // Dodavanje ocene.
  if (br_oc == kap) exit(1);
  ocene[br_oc++] = ocena;
  return *this;
}

int& Student::operator[](int i) {                    // Dohvatanje ocene.
  if (i<0 || i>=br_oc) exit(2);
  return ocene[i];
}

int Student::operator[](int i) const {
  if (i<0 || i>=br_oc) exit(2);
  return ocene[i];
}

double Student::sr_ocena() const {                   // Srednja ocena.
  double s = 0;
  for (int i=0; i<br_oc; s+=ocene[i++]);
  return br_oc ? s/br_oc : 0;
}

