// firmagr.h - Klase gresaka.

#ifndef _firmagr_h_
#define _firmagr_h_

#include <iostream>
using namespace std;

namespace Trgovina {
  class G_previse {};          // GRESKA: Previse radnika.
  inline ostream& operator<<(ostream& it, const G_previse&)
    { return it << "*** Previse radnika! ***"; }
 
  class G_nema {};             // GRESKA: Nema trazenog radnika.
  inline ostream& operator<<(ostream& it, const G_nema&)
    { return it << "*** Nema radnika! ***"; }
} // namespace

#endif

