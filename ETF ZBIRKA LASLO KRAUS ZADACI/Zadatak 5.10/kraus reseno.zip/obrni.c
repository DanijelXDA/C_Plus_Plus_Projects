// obrni.c � Obrtanje redosleda elemenata liste.

#include <stdio.h>

typedef struct elem { float broj; struct elem *sled; } Elem;

Elem *obrni(Elem *niz) {
  Elem *tek = niz, *pret = NULL, *sled;
  while (tek) { sled = tek->sled; tek->sled = pret; pret = tek; tek = sled; }
  return pret;
}

Elem *citaj_niz(void);

void brisi_niz(Elem *);

int main() {
  Elem *niz;
  while ((niz = citaj_niz()) != NULL) {
    niz = obrni(niz);
    for (Elem *tek=niz; tek; tek=tek->sled) printf("%g ", tek->broj);
    putchar('\n');
    brisi_niz(niz);
  }
}
