// recenice.C - Sredjivanje recenica.

#include <fstream>
#include <iostream>
#include <cctype>
#include <string>
using namespace std;

void recenice(istream& ul, ostream& izl) {
  int zn; bool prvi = true;
  while ((zn = ul.get()) != EOF) {
    if (isupper(zn))
      { if (!prvi) zn = tolower(zn); else prvi = false; }
    else if (islower(zn))
      { if (prvi) { zn = toupper(zn); prvi = false; } }
    else if (zn=='.' || zn=='!' || zn=='?')
      prvi = true;
    izl.put(zn);
  }
}

int main() {
  ifstream ul; ofstream izl; string ulaz, izlaz;
  while (true) {
    printf("Ime ulazne datoteke?  "); cin >> ulaz;
  if (ulaz == "***") break;
    printf("Ime izlazne datoteke? "); cin >> izlaz;
  if (izlaz == "***") break;
    ul.open(ulaz.c_str()); izl.open(izlaz.c_str());
    recenice(ul, izl);
    izl.close(); ul.close();
  }
}

